<?php return array (
  'broadcasting' => 
  array (
    'default' => 'log',
    'connections' => 
    array (
      'reverb' => 
      array (
        'driver' => 'reverb',
        'key' => NULL,
        'secret' => NULL,
        'app_id' => NULL,
        'options' => 
        array (
          'host' => NULL,
          'port' => 443,
          'scheme' => 'https',
          'useTLS' => true,
        ),
        'client_options' => 
        array (
        ),
      ),
      'pusher' => 
      array (
        'driver' => 'pusher',
        'key' => NULL,
        'secret' => NULL,
        'app_id' => NULL,
        'options' => 
        array (
          'cluster' => NULL,
          'host' => 'api-mt1.pusher.com',
          'port' => 443,
          'scheme' => 'https',
          'encrypted' => true,
          'useTLS' => true,
        ),
        'client_options' => 
        array (
        ),
      ),
      'ably' => 
      array (
        'driver' => 'ably',
        'key' => NULL,
      ),
      'log' => 
      array (
        'driver' => 'log',
      ),
      'null' => 
      array (
        'driver' => 'null',
      ),
    ),
  ),
  'concurrency' => 
  array (
    'default' => 'process',
  ),
  'cors' => 
  array (
    'paths' => 
    array (
      0 => 'api/*',
      1 => 'sanctum/csrf-cookie',
    ),
    'allowed_methods' => 
    array (
      0 => '*',
    ),
    'allowed_origins' => 
    array (
      0 => '*',
    ),
    'allowed_origins_patterns' => 
    array (
    ),
    'allowed_headers' => 
    array (
      0 => '*',
    ),
    'exposed_headers' => 
    array (
    ),
    'max_age' => 0,
    'supports_credentials' => false,
  ),
  'hashing' => 
  array (
    'driver' => 'bcrypt',
    'bcrypt' => 
    array (
      'rounds' => '12',
      'verify' => true,
      'limit' => NULL,
    ),
    'argon' => 
    array (
      'memory' => 65536,
      'threads' => 1,
      'time' => 4,
      'verify' => true,
    ),
    'rehash_on_login' => true,
  ),
  'view' => 
  array (
    'paths' => 
    array (
      0 => 'C:\\xampp\\htdocs\\generallink\\resources\\views',
    ),
    'compiled' => 'C:\\xampp\\htdocs\\generallink\\storage\\framework\\views',
  ),
  'accounting' => 
  array (
    'base_currency' => 'MYR',
    'drivers' => 
    array (
      'database' => 
      array (
        'connection' => NULL,
      ),
    ),
    'table_prefix' => 'acct_',
    'web_middleware' => 
    array (
      0 => 'web',
      1 => 'auth',
    ),
    'web_prefix' => 'accounting',
    'api_middleware' => 
    array (
      0 => 'api',
      1 => 'auth:sanctum',
    ),
    'api_prefix' => 'api/accounting',
    'fiscal_year' => 
    array (
      'start_month' => 1,
      'auto_create' => true,
    ),
    'per_page' => 
    array (
      'accounts' => 50,
      'journal_entries' => 15,
      'invoices' => 15,
      'bills' => 15,
      'expenses' => 15,
      'customers' => 20,
      'vendors' => 20,
      'loans' => 15,
      'equity_entries' => 15,
      'owners' => 20,
      'fixed_assets' => 15,
      'tax_rates' => 20,
      'bank_reconciliations' => 15,
    ),
    'rounding_tolerance' => 0.005,
    'enforce_period_lock' => true,
    'integrations' => 
    array (
      'inventory' => 
      array (
        'snapshot_provider' => 'Centrex\\Inventory\\Support\\AccountingInventorySnapshotProvider',
        'forecast_service' => 'Centrex\\Inventory\\Inventory',
      ),
    ),
    'number_format' => 
    array (
      'decimals' => 2,
      'decimal_point' => '.',
      'thousands_sep' => ',',
    ),
    'admin_roles' => 'accountant,admin',
    'admin_role_attribute' => NULL,
    'user_foreign_keys' => false,
    'accounts' => 
    array (
      'cash' => '1000',
      'bank' => '1100',
      'accounts_receivable' => '1200',
      'inventory' => '1300',
      'accounts_payable' => '2000',
      'goods_received_clearing' => '2050',
      'tax_payable' => '2300',
      'retained_earnings' => '3100',
      'capital' => '3000',
      'owner_drawings' => '3200',
      'sales_revenue' => '4000',
      'cogs' => '5000',
      'purchase_discount' => '5500',
      'purchase_returns' => '5504',
      'sales_discount' => '6130',
      'sales_returns' => '6134',
      'delivery_charge' => '6310',
      'shipping' => '6320',
      'local_delivery' => '6330',
      'return_charge' => '6340',
      'financing_interest' => '6710',
      'depreciation_expense' => '6600',
      'gain_loss_on_disposal' => '4910',
      'bank_fees_expense' => '6800',
      'interest_income' => '4900',
    ),
  ),
  'ai_navigation' => 
  array (
    'affiliate' => 
    array (
      'module' => 'affiliate',
      'pages' => 
      array (
        'auth.register' => 
        array (
          'label' => 'Affiliate Registration',
          'roles' => 
          array (
            0 => 'guest',
          ),
          'elements' => 
          array (
            'upline-type-dropdown' => 
            array (
              'type' => 'dropdown',
              'destructive' => false,
            ),
            'affiliate-search-input' => 
            array (
              'type' => 'input',
              'destructive' => false,
            ),
            'upline-agent-id-hidden' => 
            array (
              'type' => 'hidden',
              'destructive' => false,
            ),
            'admin-assign-notice' => 
            array (
              'type' => 'notice',
              'destructive' => false,
            ),
            'full-name-input' => 
            array (
              'type' => 'input',
              'destructive' => false,
            ),
            'phone-input' => 
            array (
              'type' => 'input',
              'destructive' => false,
            ),
            'email-input' => 
            array (
              'type' => 'input',
              'destructive' => false,
            ),
            'address-input' => 
            array (
              'type' => 'input',
              'destructive' => false,
            ),
            'postcode-input' => 
            array (
              'type' => 'input',
              'destructive' => false,
            ),
            'city-input' => 
            array (
              'type' => 'input',
              'destructive' => false,
            ),
            'state-dropdown' => 
            array (
              'type' => 'dropdown',
              'destructive' => false,
            ),
            'register-submit-btn' => 
            array (
              'type' => 'button',
              'destructive' => true,
            ),
          ),
        ),
        'auth.verify-pending' => 
        array (
          'label' => 'Verification Pending',
          'roles' => 
          array (
            0 => 'guest',
          ),
          'elements' => 
          array (
          ),
        ),
      ),
      'workflows' => 
      array (
        'affiliate_registration' => 
        array (
          'label' => 'Register as an affiliate',
          'roles' => 
          array (
            0 => 'guest',
          ),
          'steps' => 
          array (
            0 => 
            array (
              'page' => 'auth.register',
              'element' => NULL,
              'action' => 'open_page',
              'message' => 'Let\'s get you registered as an affiliate! I\'ll walk you through this form step by step — just follow along and click or type where I point.',
              'wait' => NULL,
            ),
            1 => 
            array (
              'page' => 'auth.register',
              'element' => 'upline-type-dropdown',
              'action' => 'highlight_element',
              'message' => 'First, choose who you\'re joining under — Group Leader, Team Leader, Introducer, or let our Admin team assign one for you.',
              'wait' => 'field_filled',
            ),
            2 => 
            array (
              'page' => 'auth.register',
              'element' => 'affiliate-search-input',
              'action' => 'highlight_element',
              'message' => 'Now search your sponsor by name or code and pick them from the list. If you chose Admin Assign instead, you can skip this — just carry on to the next step.',
              'wait' => 'sponsor_selected',
            ),
            3 => 
            array (
              'page' => 'auth.register',
              'element' => 'full-name-input',
              'action' => 'focus_input',
              'message' => 'Type your full legal name here, exactly as it appears on your NRIC or MyKad.',
              'wait' => 'field_filled',
            ),
            4 => 
            array (
              'page' => 'auth.register',
              'element' => 'phone-input',
              'action' => 'focus_input',
              'message' => 'Enter your mobile number, e.g. 012-3456789.',
              'wait' => 'field_filled',
            ),
            5 => 
            array (
              'page' => 'auth.register',
              'element' => 'email-input',
              'action' => 'focus_input',
              'message' => 'Enter your email address — your verification link will be sent here, so make sure it\'s correct.',
              'wait' => 'field_filled',
            ),
            6 => 
            array (
              'page' => 'auth.register',
              'element' => 'address-input',
              'action' => 'focus_input',
              'message' => 'Enter your street address — unit or house number, street name, and area.',
              'wait' => 'field_filled',
            ),
            7 => 
            array (
              'page' => 'auth.register',
              'element' => 'postcode-input',
              'action' => 'focus_input',
              'message' => 'Enter your postcode — city and state can auto-fill from this, so type it first.',
              'wait' => 'field_filled',
            ),
            8 => 
            array (
              'page' => 'auth.register',
              'element' => 'city-input',
              'action' => 'highlight_element',
              'message' => 'Check that your city filled in correctly, or type it in yourself.',
              'wait' => 'field_filled',
            ),
            9 => 
            array (
              'page' => 'auth.register',
              'element' => 'state-dropdown',
              'action' => 'highlight_element',
              'message' => 'Check that your state is correct.',
              'wait' => 'field_filled',
            ),
            10 => 
            array (
              'page' => 'auth.register',
              'element' => 'register-submit-btn',
              'action' => 'highlight_element',
              'message' => 'You\'re all set! Have a quick look over your details, then click Submit Registration yourself when you\'re ready — I won\'t click it for you.',
              'wait' => 'page_arrived:auth.verify-pending',
            ),
            11 => 
            array (
              'page' => 'auth.verify-pending',
              'element' => NULL,
              'action' => 'end_workflow',
              'message' => 'You\'re registered! Please check your email for the verification link to finish setting up your account.',
              'wait' => NULL,
            ),
          ),
        ),
      ),
    ),
    'integrations' => 
    array (
      'module' => 'integrations',
      'pages' => 
      array (
        'integrations.index' => 
        array (
          'label' => 'Integration Hub',
          'roles' => 
          array (
            0 => 'ADMIN',
            1 => 'GROUP_LEADER',
            2 => 'TEAM_LEADER',
            3 => 'INTRODUCER',
          ),
          'elements' => 
          array (
            'category-tile-ai_services' => 
            array (
              'type' => 'button',
              'destructive' => false,
            ),
            'category-tile-communication' => 
            array (
              'type' => 'button',
              'destructive' => false,
            ),
            'category-tile-ocr' => 
            array (
              'type' => 'button',
              'destructive' => false,
            ),
            'category-tile-social_media' => 
            array (
              'type' => 'button',
              'destructive' => false,
            ),
            'category-tile-email_services' => 
            array (
              'type' => 'button',
              'destructive' => false,
            ),
            'category-tile-cloud_storage' => 
            array (
              'type' => 'button',
              'destructive' => false,
            ),
            'category-tile-payment_gateways' => 
            array (
              'type' => 'button',
              'destructive' => false,
            ),
            'category-tile-erp_systems' => 
            array (
              'type' => 'button',
              'destructive' => false,
            ),
            'category-tile-pos_systems' => 
            array (
              'type' => 'button',
              'destructive' => false,
            ),
            'category-tile-crm_systems' => 
            array (
              'type' => 'button',
              'destructive' => false,
            ),
            'category-tile-accounting_systems' => 
            array (
              'type' => 'button',
              'destructive' => false,
            ),
            'category-tile-ecommerce_platforms' => 
            array (
              'type' => 'button',
              'destructive' => false,
            ),
            'category-tile-marketplaces' => 
            array (
              'type' => 'button',
              'destructive' => false,
            ),
            'category-tile-hospitality' => 
            array (
              'type' => 'button',
              'destructive' => false,
            ),
            'category-tile-logistics_delivery' => 
            array (
              'type' => 'button',
              'destructive' => false,
            ),
            'category-tile-government_tax' => 
            array (
              'type' => 'button',
              'destructive' => false,
            ),
            'category-tile-developer_apis' => 
            array (
              'type' => 'button',
              'destructive' => false,
            ),
          ),
        ),
        'integrations.category' => 
        array (
          'label' => 'Integration Hub — Category',
          'roles' => 
          array (
            0 => 'ADMIN',
            1 => 'GROUP_LEADER',
            2 => 'TEAM_LEADER',
            3 => 'INTRODUCER',
          ),
          'elements' => 
          array (
          ),
        ),
      ),
      'workflows' => 
      array (
        'connect_ai_services' => 
        array (
          'label' => 'Connect a AI Services provider',
          'roles' => 
          array (
            0 => 'ADMIN',
            1 => 'GROUP_LEADER',
            2 => 'TEAM_LEADER',
            3 => 'INTRODUCER',
          ),
          'steps' => 
          array (
            0 => 
            array (
              'page' => 'integrations.index',
              'element' => NULL,
              'action' => 'open_page',
              'message' => 'Let\'s get your AI Services connected! I\'ll take you to your Integration Hub.',
              'wait' => NULL,
            ),
            1 => 
            array (
              'page' => 'integrations.index',
              'element' => 'category-tile-ai_services',
              'action' => 'highlight_element',
              'message' => 'Click this AI Services tile — that\'s where OpenAI, Google Gemini, Anthropic (Claude), ElevenLabs live.',
              'wait' => 'page_arrived:integrations.category',
            ),
            2 => 
            array (
              'page' => 'integrations.category',
              'element' => NULL,
              'action' => 'end_workflow',
              'message' => 'Find the provider you want in the list, paste your own API key (or the fields it asks for) next to it, click Save, then Test Connection if that provider supports it yet. I\'m here if you get stuck!',
              'wait' => NULL,
            ),
          ),
        ),
        'connect_communication' => 
        array (
          'label' => 'Connect a Communication provider',
          'roles' => 
          array (
            0 => 'ADMIN',
            1 => 'GROUP_LEADER',
            2 => 'TEAM_LEADER',
            3 => 'INTRODUCER',
          ),
          'steps' => 
          array (
            0 => 
            array (
              'page' => 'integrations.index',
              'element' => NULL,
              'action' => 'open_page',
              'message' => 'Let\'s get your Communication connected! I\'ll take you to your Integration Hub.',
              'wait' => NULL,
            ),
            1 => 
            array (
              'page' => 'integrations.index',
              'element' => 'category-tile-communication',
              'action' => 'highlight_element',
              'message' => 'Click this Communication tile — that\'s where WhatsApp Business API, Telegram Bot, LINE Messaging API, WeChat Official Account, Twilio (SMS), Vonage (SMS) live.',
              'wait' => 'page_arrived:integrations.category',
            ),
            2 => 
            array (
              'page' => 'integrations.category',
              'element' => NULL,
              'action' => 'end_workflow',
              'message' => 'Find the provider you want in the list, paste your own API key (or the fields it asks for) next to it, click Save, then Test Connection if that provider supports it yet. I\'m here if you get stuck!',
              'wait' => NULL,
            ),
          ),
        ),
        'connect_ocr' => 
        array (
          'label' => 'Connect a Document OCR provider',
          'roles' => 
          array (
            0 => 'ADMIN',
            1 => 'GROUP_LEADER',
            2 => 'TEAM_LEADER',
            3 => 'INTRODUCER',
          ),
          'steps' => 
          array (
            0 => 
            array (
              'page' => 'integrations.index',
              'element' => NULL,
              'action' => 'open_page',
              'message' => 'Let\'s get your Document OCR connected! I\'ll take you to your Integration Hub.',
              'wait' => NULL,
            ),
            1 => 
            array (
              'page' => 'integrations.index',
              'element' => 'category-tile-ocr',
              'action' => 'highlight_element',
              'message' => 'Click this Document OCR tile — that\'s where Google Cloud Vision, AWS Textract, Azure Form Recognizer live.',
              'wait' => 'page_arrived:integrations.category',
            ),
            2 => 
            array (
              'page' => 'integrations.category',
              'element' => NULL,
              'action' => 'end_workflow',
              'message' => 'Find the provider you want in the list, paste your own API key (or the fields it asks for) next to it, click Save, then Test Connection if that provider supports it yet. I\'m here if you get stuck!',
              'wait' => NULL,
            ),
          ),
        ),
        'connect_social_media' => 
        array (
          'label' => 'Connect a Social Media provider',
          'roles' => 
          array (
            0 => 'ADMIN',
            1 => 'GROUP_LEADER',
            2 => 'TEAM_LEADER',
            3 => 'INTRODUCER',
          ),
          'steps' => 
          array (
            0 => 
            array (
              'page' => 'integrations.index',
              'element' => NULL,
              'action' => 'open_page',
              'message' => 'Let\'s get your Social Media connected! I\'ll take you to your Integration Hub.',
              'wait' => NULL,
            ),
            1 => 
            array (
              'page' => 'integrations.index',
              'element' => 'category-tile-social_media',
              'action' => 'highlight_element',
              'message' => 'Click this Social Media tile — that\'s where Facebook, Instagram, X (Twitter), LinkedIn, TikTok, YouTube live.',
              'wait' => 'page_arrived:integrations.category',
            ),
            2 => 
            array (
              'page' => 'integrations.category',
              'element' => NULL,
              'action' => 'end_workflow',
              'message' => 'Find the provider you want in the list, paste your own API key (or the fields it asks for) next to it, click Save, then Test Connection if that provider supports it yet. I\'m here if you get stuck!',
              'wait' => NULL,
            ),
          ),
        ),
        'connect_email_services' => 
        array (
          'label' => 'Connect a Email Services provider',
          'roles' => 
          array (
            0 => 'ADMIN',
            1 => 'GROUP_LEADER',
            2 => 'TEAM_LEADER',
            3 => 'INTRODUCER',
          ),
          'steps' => 
          array (
            0 => 
            array (
              'page' => 'integrations.index',
              'element' => NULL,
              'action' => 'open_page',
              'message' => 'Let\'s get your Email Services connected! I\'ll take you to your Integration Hub.',
              'wait' => NULL,
            ),
            1 => 
            array (
              'page' => 'integrations.index',
              'element' => 'category-tile-email_services',
              'action' => 'highlight_element',
              'message' => 'Click this Email Services tile — that\'s where Gmail, Microsoft Outlook, SMTP, SendGrid, Mailgun, Amazon SES live.',
              'wait' => 'page_arrived:integrations.category',
            ),
            2 => 
            array (
              'page' => 'integrations.category',
              'element' => NULL,
              'action' => 'end_workflow',
              'message' => 'Find the provider you want in the list, paste your own API key (or the fields it asks for) next to it, click Save, then Test Connection if that provider supports it yet. I\'m here if you get stuck!',
              'wait' => NULL,
            ),
          ),
        ),
        'connect_cloud_storage' => 
        array (
          'label' => 'Connect a Cloud Storage provider',
          'roles' => 
          array (
            0 => 'ADMIN',
            1 => 'GROUP_LEADER',
            2 => 'TEAM_LEADER',
            3 => 'INTRODUCER',
          ),
          'steps' => 
          array (
            0 => 
            array (
              'page' => 'integrations.index',
              'element' => NULL,
              'action' => 'open_page',
              'message' => 'Let\'s get your Cloud Storage connected! I\'ll take you to your Integration Hub.',
              'wait' => NULL,
            ),
            1 => 
            array (
              'page' => 'integrations.index',
              'element' => 'category-tile-cloud_storage',
              'action' => 'highlight_element',
              'message' => 'Click this Cloud Storage tile — that\'s where Google Drive, OneDrive, Dropbox, AWS S3, Azure Blob Storage live.',
              'wait' => 'page_arrived:integrations.category',
            ),
            2 => 
            array (
              'page' => 'integrations.category',
              'element' => NULL,
              'action' => 'end_workflow',
              'message' => 'Find the provider you want in the list, paste your own API key (or the fields it asks for) next to it, click Save, then Test Connection if that provider supports it yet. I\'m here if you get stuck!',
              'wait' => NULL,
            ),
          ),
        ),
        'connect_payment_gateways' => 
        array (
          'label' => 'Connect a Payment Gateways provider',
          'roles' => 
          array (
            0 => 'ADMIN',
            1 => 'GROUP_LEADER',
            2 => 'TEAM_LEADER',
            3 => 'INTRODUCER',
          ),
          'steps' => 
          array (
            0 => 
            array (
              'page' => 'integrations.index',
              'element' => NULL,
              'action' => 'open_page',
              'message' => 'Let\'s get your Payment Gateways connected! I\'ll take you to your Integration Hub.',
              'wait' => NULL,
            ),
            1 => 
            array (
              'page' => 'integrations.index',
              'element' => 'category-tile-payment_gateways',
              'action' => 'highlight_element',
              'message' => 'Click this Payment Gateways tile — that\'s where Stripe, PayPal, Billplz, ToyyibPay, iPay88, HitPay, Razorpay live.',
              'wait' => 'page_arrived:integrations.category',
            ),
            2 => 
            array (
              'page' => 'integrations.category',
              'element' => NULL,
              'action' => 'end_workflow',
              'message' => 'Find the provider you want in the list, paste your own API key (or the fields it asks for) next to it, click Save, then Test Connection if that provider supports it yet. I\'m here if you get stuck!',
              'wait' => NULL,
            ),
          ),
        ),
        'connect_erp_systems' => 
        array (
          'label' => 'Connect a ERP Systems provider',
          'roles' => 
          array (
            0 => 'ADMIN',
            1 => 'GROUP_LEADER',
            2 => 'TEAM_LEADER',
            3 => 'INTRODUCER',
          ),
          'steps' => 
          array (
            0 => 
            array (
              'page' => 'integrations.index',
              'element' => NULL,
              'action' => 'open_page',
              'message' => 'Let\'s get your ERP Systems connected! I\'ll take you to your Integration Hub.',
              'wait' => NULL,
            ),
            1 => 
            array (
              'page' => 'integrations.index',
              'element' => 'category-tile-erp_systems',
              'action' => 'highlight_element',
              'message' => 'Click this ERP Systems tile — that\'s where SAP, Oracle ERP, Microsoft Dynamics 365, Odoo, NetSuite, Epicor, Custom ERP live.',
              'wait' => 'page_arrived:integrations.category',
            ),
            2 => 
            array (
              'page' => 'integrations.category',
              'element' => NULL,
              'action' => 'end_workflow',
              'message' => 'Find the provider you want in the list, paste your own API key (or the fields it asks for) next to it, click Save, then Test Connection if that provider supports it yet. I\'m here if you get stuck!',
              'wait' => NULL,
            ),
          ),
        ),
        'connect_pos_systems' => 
        array (
          'label' => 'Connect a POS Systems provider',
          'roles' => 
          array (
            0 => 'ADMIN',
            1 => 'GROUP_LEADER',
            2 => 'TEAM_LEADER',
            3 => 'INTRODUCER',
          ),
          'steps' => 
          array (
            0 => 
            array (
              'page' => 'integrations.index',
              'element' => NULL,
              'action' => 'open_page',
              'message' => 'Let\'s get your POS Systems connected! I\'ll take you to your Integration Hub.',
              'wait' => NULL,
            ),
            1 => 
            array (
              'page' => 'integrations.index',
              'element' => 'category-tile-pos_systems',
              'action' => 'highlight_element',
              'message' => 'Click this POS Systems tile — that\'s where Square, Clover, Toast, Cloud POS (generic), Custom POS live.',
              'wait' => 'page_arrived:integrations.category',
            ),
            2 => 
            array (
              'page' => 'integrations.category',
              'element' => NULL,
              'action' => 'end_workflow',
              'message' => 'Find the provider you want in the list, paste your own API key (or the fields it asks for) next to it, click Save, then Test Connection if that provider supports it yet. I\'m here if you get stuck!',
              'wait' => NULL,
            ),
          ),
        ),
        'connect_crm_systems' => 
        array (
          'label' => 'Connect a CRM Systems provider',
          'roles' => 
          array (
            0 => 'ADMIN',
            1 => 'GROUP_LEADER',
            2 => 'TEAM_LEADER',
            3 => 'INTRODUCER',
          ),
          'steps' => 
          array (
            0 => 
            array (
              'page' => 'integrations.index',
              'element' => NULL,
              'action' => 'open_page',
              'message' => 'Let\'s get your CRM Systems connected! I\'ll take you to your Integration Hub.',
              'wait' => NULL,
            ),
            1 => 
            array (
              'page' => 'integrations.index',
              'element' => 'category-tile-crm_systems',
              'action' => 'highlight_element',
              'message' => 'Click this CRM Systems tile — that\'s where Salesforce, HubSpot, Zoho CRM, Microsoft Dynamics CRM, Custom CRM live.',
              'wait' => 'page_arrived:integrations.category',
            ),
            2 => 
            array (
              'page' => 'integrations.category',
              'element' => NULL,
              'action' => 'end_workflow',
              'message' => 'Find the provider you want in the list, paste your own API key (or the fields it asks for) next to it, click Save, then Test Connection if that provider supports it yet. I\'m here if you get stuck!',
              'wait' => NULL,
            ),
          ),
        ),
        'connect_accounting_systems' => 
        array (
          'label' => 'Connect a Accounting Systems provider',
          'roles' => 
          array (
            0 => 'ADMIN',
            1 => 'GROUP_LEADER',
            2 => 'TEAM_LEADER',
            3 => 'INTRODUCER',
          ),
          'steps' => 
          array (
            0 => 
            array (
              'page' => 'integrations.index',
              'element' => NULL,
              'action' => 'open_page',
              'message' => 'Let\'s get your Accounting Systems connected! I\'ll take you to your Integration Hub.',
              'wait' => NULL,
            ),
            1 => 
            array (
              'page' => 'integrations.index',
              'element' => 'category-tile-accounting_systems',
              'action' => 'highlight_element',
              'message' => 'Click this Accounting Systems tile — that\'s where QuickBooks, Xero, Sage, AutoCount, SQL Accounting, Million Accounting live.',
              'wait' => 'page_arrived:integrations.category',
            ),
            2 => 
            array (
              'page' => 'integrations.category',
              'element' => NULL,
              'action' => 'end_workflow',
              'message' => 'Find the provider you want in the list, paste your own API key (or the fields it asks for) next to it, click Save, then Test Connection if that provider supports it yet. I\'m here if you get stuck!',
              'wait' => NULL,
            ),
          ),
        ),
        'connect_ecommerce_platforms' => 
        array (
          'label' => 'Connect a E-Commerce Platforms provider',
          'roles' => 
          array (
            0 => 'ADMIN',
            1 => 'GROUP_LEADER',
            2 => 'TEAM_LEADER',
            3 => 'INTRODUCER',
          ),
          'steps' => 
          array (
            0 => 
            array (
              'page' => 'integrations.index',
              'element' => NULL,
              'action' => 'open_page',
              'message' => 'Let\'s get your E-Commerce Platforms connected! I\'ll take you to your Integration Hub.',
              'wait' => NULL,
            ),
            1 => 
            array (
              'page' => 'integrations.index',
              'element' => 'category-tile-ecommerce_platforms',
              'action' => 'highlight_element',
              'message' => 'Click this E-Commerce Platforms tile — that\'s where Shopify, WooCommerce, Magento, BigCommerce, OpenCart, PrestaShop live.',
              'wait' => 'page_arrived:integrations.category',
            ),
            2 => 
            array (
              'page' => 'integrations.category',
              'element' => NULL,
              'action' => 'end_workflow',
              'message' => 'Find the provider you want in the list, paste your own API key (or the fields it asks for) next to it, click Save, then Test Connection if that provider supports it yet. I\'m here if you get stuck!',
              'wait' => NULL,
            ),
          ),
        ),
        'connect_marketplaces' => 
        array (
          'label' => 'Connect a Online Marketplaces provider',
          'roles' => 
          array (
            0 => 'ADMIN',
            1 => 'GROUP_LEADER',
            2 => 'TEAM_LEADER',
            3 => 'INTRODUCER',
          ),
          'steps' => 
          array (
            0 => 
            array (
              'page' => 'integrations.index',
              'element' => NULL,
              'action' => 'open_page',
              'message' => 'Let\'s get your Online Marketplaces connected! I\'ll take you to your Integration Hub.',
              'wait' => NULL,
            ),
            1 => 
            array (
              'page' => 'integrations.index',
              'element' => 'category-tile-marketplaces',
              'action' => 'highlight_element',
              'message' => 'Click this Online Marketplaces tile — that\'s where Shopee, Lazada, Alibaba, AliExpress, Taobao, Tmall, eBay, Amazon Marketplace, Etsy live.',
              'wait' => 'page_arrived:integrations.category',
            ),
            2 => 
            array (
              'page' => 'integrations.category',
              'element' => NULL,
              'action' => 'end_workflow',
              'message' => 'Find the provider you want in the list, paste your own API key (or the fields it asks for) next to it, click Save, then Test Connection if that provider supports it yet. I\'m here if you get stuck!',
              'wait' => NULL,
            ),
          ),
        ),
        'connect_hospitality' => 
        array (
          'label' => 'Connect a Hotel & Hospitality provider',
          'roles' => 
          array (
            0 => 'ADMIN',
            1 => 'GROUP_LEADER',
            2 => 'TEAM_LEADER',
            3 => 'INTRODUCER',
          ),
          'steps' => 
          array (
            0 => 
            array (
              'page' => 'integrations.index',
              'element' => NULL,
              'action' => 'open_page',
              'message' => 'Let\'s get your Hotel & Hospitality connected! I\'ll take you to your Integration Hub.',
              'wait' => NULL,
            ),
            1 => 
            array (
              'page' => 'integrations.index',
              'element' => 'category-tile-hospitality',
              'action' => 'highlight_element',
              'message' => 'Click this Hotel & Hospitality tile — that\'s where Property Management System, Central Reservation System, Channel Manager, Booking Engine, Online Travel Agencies (OTA) live.',
              'wait' => 'page_arrived:integrations.category',
            ),
            2 => 
            array (
              'page' => 'integrations.category',
              'element' => NULL,
              'action' => 'end_workflow',
              'message' => 'Find the provider you want in the list, paste your own API key (or the fields it asks for) next to it, click Save, then Test Connection if that provider supports it yet. I\'m here if you get stuck!',
              'wait' => NULL,
            ),
          ),
        ),
        'connect_logistics_delivery' => 
        array (
          'label' => 'Connect a Logistics & Delivery provider',
          'roles' => 
          array (
            0 => 'ADMIN',
            1 => 'GROUP_LEADER',
            2 => 'TEAM_LEADER',
            3 => 'INTRODUCER',
          ),
          'steps' => 
          array (
            0 => 
            array (
              'page' => 'integrations.index',
              'element' => NULL,
              'action' => 'open_page',
              'message' => 'Let\'s get your Logistics & Delivery connected! I\'ll take you to your Integration Hub.',
              'wait' => NULL,
            ),
            1 => 
            array (
              'page' => 'integrations.index',
              'element' => 'category-tile-logistics_delivery',
              'action' => 'highlight_element',
              'message' => 'Click this Logistics & Delivery tile — that\'s where DHL, FedEx, UPS, Ninja Van, J&T Express, EasyParcel, Lalamove, GrabExpress live.',
              'wait' => 'page_arrived:integrations.category',
            ),
            2 => 
            array (
              'page' => 'integrations.category',
              'element' => NULL,
              'action' => 'end_workflow',
              'message' => 'Find the provider you want in the list, paste your own API key (or the fields it asks for) next to it, click Save, then Test Connection if that provider supports it yet. I\'m here if you get stuck!',
              'wait' => NULL,
            ),
          ),
        ),
        'connect_government_tax' => 
        array (
          'label' => 'Connect a Government & Tax provider',
          'roles' => 
          array (
            0 => 'ADMIN',
            1 => 'GROUP_LEADER',
            2 => 'TEAM_LEADER',
            3 => 'INTRODUCER',
          ),
          'steps' => 
          array (
            0 => 
            array (
              'page' => 'integrations.index',
              'element' => NULL,
              'action' => 'open_page',
              'message' => 'Let\'s get your Government & Tax connected! I\'ll take you to your Integration Hub.',
              'wait' => NULL,
            ),
            1 => 
            array (
              'page' => 'integrations.index',
              'element' => 'category-tile-government_tax',
              'action' => 'highlight_element',
              'message' => 'Click this Government & Tax tile — that\'s where e-Invoicing, Tax APIs, Customs APIs, Government Digital Services live.',
              'wait' => 'page_arrived:integrations.category',
            ),
            2 => 
            array (
              'page' => 'integrations.category',
              'element' => NULL,
              'action' => 'end_workflow',
              'message' => 'Find the provider you want in the list, paste your own API key (or the fields it asks for) next to it, click Save, then Test Connection if that provider supports it yet. I\'m here if you get stuck!',
              'wait' => NULL,
            ),
          ),
        ),
        'connect_developer_apis' => 
        array (
          'label' => 'Connect a Developer APIs provider',
          'roles' => 
          array (
            0 => 'ADMIN',
            1 => 'GROUP_LEADER',
            2 => 'TEAM_LEADER',
            3 => 'INTRODUCER',
          ),
          'steps' => 
          array (
            0 => 
            array (
              'page' => 'integrations.index',
              'element' => NULL,
              'action' => 'open_page',
              'message' => 'Let\'s get your Developer APIs connected! I\'ll take you to your Integration Hub.',
              'wait' => NULL,
            ),
            1 => 
            array (
              'page' => 'integrations.index',
              'element' => 'category-tile-developer_apis',
              'action' => 'highlight_element',
              'message' => 'Click this Developer APIs tile — that\'s where REST API, GraphQL API, Webhooks, MQTT, WebSocket, Custom Connector live.',
              'wait' => 'page_arrived:integrations.category',
            ),
            2 => 
            array (
              'page' => 'integrations.category',
              'element' => NULL,
              'action' => 'end_workflow',
              'message' => 'Find the provider you want in the list, paste your own API key (or the fields it asks for) next to it, click Save, then Test Connection if that provider supports it yet. I\'m here if you get stuck!',
              'wait' => NULL,
            ),
          ),
        ),
      ),
    ),
  ),
  'app' => 
  array (
    'name' => 'Laravel',
    'env' => 'local',
    'debug' => true,
    'url' => 'http://localhost/generallink/public',
    'frontend_url' => 'http://localhost:3000',
    'asset_url' => NULL,
    'timezone' => 'UTC',
    'locale' => 'en',
    'fallback_locale' => 'en',
    'faker_locale' => 'en_US',
    'cipher' => 'AES-256-CBC',
    'key' => 'base64:F+IykLL+KaConWCxXz13tZBlB7eLJKeeHIQ4j3D+W2k=',
    'previous_keys' => 
    array (
    ),
    'maintenance' => 
    array (
      'driver' => 'file',
      'store' => 'database',
    ),
    'providers' => 
    array (
      0 => 'Illuminate\\Auth\\AuthServiceProvider',
      1 => 'Illuminate\\Broadcasting\\BroadcastServiceProvider',
      2 => 'Illuminate\\Bus\\BusServiceProvider',
      3 => 'Illuminate\\Cache\\CacheServiceProvider',
      4 => 'Illuminate\\Foundation\\Providers\\ConsoleSupportServiceProvider',
      5 => 'Illuminate\\Concurrency\\ConcurrencyServiceProvider',
      6 => 'Illuminate\\Cookie\\CookieServiceProvider',
      7 => 'Illuminate\\Database\\DatabaseServiceProvider',
      8 => 'Illuminate\\Encryption\\EncryptionServiceProvider',
      9 => 'Illuminate\\Filesystem\\FilesystemServiceProvider',
      10 => 'Illuminate\\Foundation\\Providers\\FoundationServiceProvider',
      11 => 'Illuminate\\Hashing\\HashServiceProvider',
      12 => 'Illuminate\\Mail\\MailServiceProvider',
      13 => 'Illuminate\\Notifications\\NotificationServiceProvider',
      14 => 'Illuminate\\Pagination\\PaginationServiceProvider',
      15 => 'Illuminate\\Auth\\Passwords\\PasswordResetServiceProvider',
      16 => 'Illuminate\\Pipeline\\PipelineServiceProvider',
      17 => 'Illuminate\\Queue\\QueueServiceProvider',
      18 => 'Illuminate\\Redis\\RedisServiceProvider',
      19 => 'Illuminate\\Session\\SessionServiceProvider',
      20 => 'Illuminate\\Translation\\TranslationServiceProvider',
      21 => 'Illuminate\\Validation\\ValidationServiceProvider',
      22 => 'Illuminate\\View\\ViewServiceProvider',
      23 => 'App\\Providers\\AppServiceProvider',
    ),
    'aliases' => 
    array (
      'App' => 'Illuminate\\Support\\Facades\\App',
      'Arr' => 'Illuminate\\Support\\Arr',
      'Artisan' => 'Illuminate\\Support\\Facades\\Artisan',
      'Auth' => 'Illuminate\\Support\\Facades\\Auth',
      'Benchmark' => 'Illuminate\\Support\\Benchmark',
      'Blade' => 'Illuminate\\Support\\Facades\\Blade',
      'Broadcast' => 'Illuminate\\Support\\Facades\\Broadcast',
      'Bus' => 'Illuminate\\Support\\Facades\\Bus',
      'Cache' => 'Illuminate\\Support\\Facades\\Cache',
      'Concurrency' => 'Illuminate\\Support\\Facades\\Concurrency',
      'Config' => 'Illuminate\\Support\\Facades\\Config',
      'Context' => 'Illuminate\\Support\\Facades\\Context',
      'Cookie' => 'Illuminate\\Support\\Facades\\Cookie',
      'Crypt' => 'Illuminate\\Support\\Facades\\Crypt',
      'Date' => 'Illuminate\\Support\\Facades\\Date',
      'DB' => 'Illuminate\\Support\\Facades\\DB',
      'Eloquent' => 'Illuminate\\Database\\Eloquent\\Model',
      'Event' => 'Illuminate\\Support\\Facades\\Event',
      'File' => 'Illuminate\\Support\\Facades\\File',
      'Gate' => 'Illuminate\\Support\\Facades\\Gate',
      'Hash' => 'Illuminate\\Support\\Facades\\Hash',
      'Http' => 'Illuminate\\Support\\Facades\\Http',
      'Js' => 'Illuminate\\Support\\Js',
      'Lang' => 'Illuminate\\Support\\Facades\\Lang',
      'Log' => 'Illuminate\\Support\\Facades\\Log',
      'Mail' => 'Illuminate\\Support\\Facades\\Mail',
      'Notification' => 'Illuminate\\Support\\Facades\\Notification',
      'Number' => 'Illuminate\\Support\\Number',
      'Password' => 'Illuminate\\Support\\Facades\\Password',
      'Process' => 'Illuminate\\Support\\Facades\\Process',
      'Queue' => 'Illuminate\\Support\\Facades\\Queue',
      'RateLimiter' => 'Illuminate\\Support\\Facades\\RateLimiter',
      'Redirect' => 'Illuminate\\Support\\Facades\\Redirect',
      'Request' => 'Illuminate\\Support\\Facades\\Request',
      'Response' => 'Illuminate\\Support\\Facades\\Response',
      'Route' => 'Illuminate\\Support\\Facades\\Route',
      'Schedule' => 'Illuminate\\Support\\Facades\\Schedule',
      'Schema' => 'Illuminate\\Support\\Facades\\Schema',
      'Session' => 'Illuminate\\Support\\Facades\\Session',
      'Storage' => 'Illuminate\\Support\\Facades\\Storage',
      'Str' => 'Illuminate\\Support\\Str',
      'Uri' => 'Illuminate\\Support\\Uri',
      'URL' => 'Illuminate\\Support\\Facades\\URL',
      'Validator' => 'Illuminate\\Support\\Facades\\Validator',
      'View' => 'Illuminate\\Support\\Facades\\View',
      'Vite' => 'Illuminate\\Support\\Facades\\Vite',
    ),
  ),
  'auth' => 
  array (
    'defaults' => 
    array (
      'guard' => 'agent',
      'passwords' => 'agents',
    ),
    'guards' => 
    array (
      'web' => 
      array (
        'driver' => 'session',
        'provider' => 'users',
      ),
      'agent' => 
      array (
        'driver' => 'session',
        'provider' => 'agents',
      ),
      'vendor' => 
      array (
        'driver' => 'session',
        'provider' => 'vendors',
      ),
    ),
    'providers' => 
    array (
      'users' => 
      array (
        'driver' => 'eloquent',
        'model' => 'App\\Models\\User',
      ),
      'agents' => 
      array (
        'driver' => 'eloquent',
        'model' => 'App\\Models\\Agent',
      ),
      'vendors' => 
      array (
        'driver' => 'eloquent',
        'model' => 'App\\Models\\Vendor',
      ),
    ),
    'passwords' => 
    array (
      'users' => 
      array (
        'provider' => 'users',
        'table' => 'password_reset_tokens',
        'expire' => 60,
        'throttle' => 60,
      ),
      'agents' => 
      array (
        'provider' => 'agents',
        'table' => 'password_reset_tokens',
        'expire' => 60,
        'throttle' => 60,
      ),
    ),
    'password_timeout' => 10800,
  ),
  'cache' => 
  array (
    'default' => 'database',
    'stores' => 
    array (
      'array' => 
      array (
        'driver' => 'array',
        'serialize' => false,
      ),
      'session' => 
      array (
        'driver' => 'session',
        'key' => '_cache',
      ),
      'database' => 
      array (
        'driver' => 'database',
        'connection' => NULL,
        'table' => 'cache',
        'lock_connection' => NULL,
        'lock_table' => NULL,
      ),
      'file' => 
      array (
        'driver' => 'file',
        'path' => 'C:\\xampp\\htdocs\\generallink\\storage\\framework/cache/data',
        'lock_path' => 'C:\\xampp\\htdocs\\generallink\\storage\\framework/cache/data',
      ),
      'memcached' => 
      array (
        'driver' => 'memcached',
        'persistent_id' => NULL,
        'sasl' => 
        array (
          0 => NULL,
          1 => NULL,
        ),
        'options' => 
        array (
        ),
        'servers' => 
        array (
          0 => 
          array (
            'host' => '127.0.0.1',
            'port' => 11211,
            'weight' => 100,
          ),
        ),
      ),
      'redis' => 
      array (
        'driver' => 'redis',
        'connection' => 'cache',
        'lock_connection' => 'default',
      ),
      'dynamodb' => 
      array (
        'driver' => 'dynamodb',
        'key' => '',
        'secret' => '',
        'region' => 'us-east-1',
        'table' => 'cache',
        'endpoint' => NULL,
      ),
      'octane' => 
      array (
        'driver' => 'octane',
      ),
      'failover' => 
      array (
        'driver' => 'failover',
        'stores' => 
        array (
          0 => 'database',
          1 => 'array',
        ),
      ),
    ),
    'prefix' => 'laravel-cache-',
  ),
  'database' => 
  array (
    'default' => 'mysql',
    'connections' => 
    array (
      'sqlite' => 
      array (
        'driver' => 'sqlite',
        'url' => NULL,
        'database' => 'generallink',
        'prefix' => '',
        'foreign_key_constraints' => true,
        'busy_timeout' => NULL,
        'journal_mode' => NULL,
        'synchronous' => NULL,
        'transaction_mode' => 'DEFERRED',
      ),
      'mysql' => 
      array (
        'driver' => 'mysql',
        'url' => NULL,
        'host' => '127.0.0.1',
        'port' => '3306',
        'database' => 'generallink',
        'username' => 'root',
        'password' => '',
        'unix_socket' => '',
        'charset' => 'utf8mb4',
        'collation' => 'utf8mb4_unicode_ci',
        'prefix' => '',
        'prefix_indexes' => true,
        'strict' => true,
        'engine' => NULL,
        'options' => 
        array (
        ),
      ),
      'mariadb' => 
      array (
        'driver' => 'mariadb',
        'url' => NULL,
        'host' => '127.0.0.1',
        'port' => '3306',
        'database' => 'generallink',
        'username' => 'root',
        'password' => '',
        'unix_socket' => '',
        'charset' => 'utf8mb4',
        'collation' => 'utf8mb4_unicode_ci',
        'prefix' => '',
        'prefix_indexes' => true,
        'strict' => true,
        'engine' => NULL,
        'options' => 
        array (
        ),
      ),
      'pgsql' => 
      array (
        'driver' => 'pgsql',
        'url' => NULL,
        'host' => '127.0.0.1',
        'port' => '3306',
        'database' => 'generallink',
        'username' => 'root',
        'password' => '',
        'charset' => 'utf8',
        'prefix' => '',
        'prefix_indexes' => true,
        'search_path' => 'public',
        'sslmode' => 'prefer',
      ),
      'sqlsrv' => 
      array (
        'driver' => 'sqlsrv',
        'url' => NULL,
        'host' => '127.0.0.1',
        'port' => '3306',
        'database' => 'generallink',
        'username' => 'root',
        'password' => '',
        'charset' => 'utf8',
        'prefix' => '',
        'prefix_indexes' => true,
      ),
    ),
    'migrations' => 
    array (
      'table' => 'migrations',
      'update_date_on_publish' => true,
    ),
    'redis' => 
    array (
      'client' => 'phpredis',
      'options' => 
      array (
        'cluster' => 'redis',
        'prefix' => 'laravel-database-',
        'persistent' => false,
      ),
      'default' => 
      array (
        'url' => NULL,
        'host' => '127.0.0.1',
        'username' => NULL,
        'password' => NULL,
        'port' => '6379',
        'database' => '0',
        'max_retries' => 3,
        'backoff_algorithm' => 'decorrelated_jitter',
        'backoff_base' => 100,
        'backoff_cap' => 1000,
      ),
      'cache' => 
      array (
        'url' => NULL,
        'host' => '127.0.0.1',
        'username' => NULL,
        'password' => NULL,
        'port' => '6379',
        'database' => '1',
        'max_retries' => 3,
        'backoff_algorithm' => 'decorrelated_jitter',
        'backoff_base' => 100,
        'backoff_cap' => 1000,
      ),
    ),
  ),
  'filesystems' => 
  array (
    'default' => 'local',
    'disks' => 
    array (
      'local' => 
      array (
        'driver' => 'local',
        'root' => 'C:\\xampp\\htdocs\\generallink\\storage\\app/private',
        'serve' => true,
        'throw' => false,
        'report' => false,
      ),
      'public' => 
      array (
        'driver' => 'local',
        'root' => 'C:\\xampp\\htdocs\\generallink\\storage\\app/public',
        'url' => 'http://localhost/generallink/public/storage',
        'visibility' => 'public',
        'throw' => false,
        'report' => false,
      ),
      's3' => 
      array (
        'driver' => 's3',
        'key' => '',
        'secret' => '',
        'region' => 'us-east-1',
        'bucket' => '',
        'url' => NULL,
        'endpoint' => NULL,
        'use_path_style_endpoint' => false,
        'throw' => false,
        'report' => false,
      ),
    ),
    'links' => 
    array (
      'C:\\xampp\\htdocs\\generallink\\public\\storage' => 'C:\\xampp\\htdocs\\generallink\\storage\\app/public',
    ),
  ),
  'logging' => 
  array (
    'default' => 'stack',
    'deprecations' => 
    array (
      'channel' => NULL,
      'trace' => false,
    ),
    'channels' => 
    array (
      'stack' => 
      array (
        'driver' => 'stack',
        'channels' => 
        array (
          0 => 'single',
        ),
        'ignore_exceptions' => false,
      ),
      'single' => 
      array (
        'driver' => 'single',
        'path' => 'C:\\xampp\\htdocs\\generallink\\storage\\logs/laravel.log',
        'level' => 'debug',
        'replace_placeholders' => true,
      ),
      'daily' => 
      array (
        'driver' => 'daily',
        'path' => 'C:\\xampp\\htdocs\\generallink\\storage\\logs/laravel.log',
        'level' => 'debug',
        'days' => 14,
        'replace_placeholders' => true,
      ),
      'slack' => 
      array (
        'driver' => 'slack',
        'url' => NULL,
        'username' => 'Laravel',
        'emoji' => ':boom:',
        'level' => 'debug',
        'replace_placeholders' => true,
      ),
      'papertrail' => 
      array (
        'driver' => 'monolog',
        'level' => 'debug',
        'handler' => 'Monolog\\Handler\\SyslogUdpHandler',
        'handler_with' => 
        array (
          'host' => NULL,
          'port' => NULL,
          'connectionString' => 'tls://:',
        ),
        'processors' => 
        array (
          0 => 'Monolog\\Processor\\PsrLogMessageProcessor',
        ),
      ),
      'stderr' => 
      array (
        'driver' => 'monolog',
        'level' => 'debug',
        'handler' => 'Monolog\\Handler\\StreamHandler',
        'handler_with' => 
        array (
          'stream' => 'php://stderr',
        ),
        'formatter' => NULL,
        'processors' => 
        array (
          0 => 'Monolog\\Processor\\PsrLogMessageProcessor',
        ),
      ),
      'syslog' => 
      array (
        'driver' => 'syslog',
        'level' => 'debug',
        'facility' => 8,
        'replace_placeholders' => true,
      ),
      'errorlog' => 
      array (
        'driver' => 'errorlog',
        'level' => 'debug',
        'replace_placeholders' => true,
      ),
      'null' => 
      array (
        'driver' => 'monolog',
        'handler' => 'Monolog\\Handler\\NullHandler',
      ),
      'emergency' => 
      array (
        'path' => 'C:\\xampp\\htdocs\\generallink\\storage\\logs/laravel.log',
      ),
    ),
  ),
  'mail' => 
  array (
    'default' => 'smtp',
    'mailers' => 
    array (
      'smtp' => 
      array (
        'transport' => 'smtp',
        'scheme' => NULL,
        'url' => NULL,
        'host' => 'smtp.gmail.com',
        'port' => '587',
        'username' => 'chrisyapywj88@gmail.com',
        'password' => 'jqtcjtbhvnqoqgyk',
        'timeout' => NULL,
        'local_domain' => 'localhost',
      ),
      'ses' => 
      array (
        'transport' => 'ses',
      ),
      'postmark' => 
      array (
        'transport' => 'postmark',
      ),
      'resend' => 
      array (
        'transport' => 'resend',
      ),
      'sendmail' => 
      array (
        'transport' => 'sendmail',
        'path' => '/usr/sbin/sendmail -bs -i',
      ),
      'log' => 
      array (
        'transport' => 'log',
        'channel' => NULL,
      ),
      'array' => 
      array (
        'transport' => 'array',
      ),
      'failover' => 
      array (
        'transport' => 'failover',
        'mailers' => 
        array (
          0 => 'smtp',
          1 => 'log',
        ),
        'retry_after' => 60,
      ),
      'roundrobin' => 
      array (
        'transport' => 'roundrobin',
        'mailers' => 
        array (
          0 => 'ses',
          1 => 'postmark',
        ),
        'retry_after' => 60,
      ),
    ),
    'from' => 
    array (
      'address' => 'chrisyapywj88@gmail.com',
      'name' => 'GeneralLink Digital Ecosystem',
    ),
    'markdown' => 
    array (
      'theme' => 'default',
      'paths' => 
      array (
        0 => 'C:\\xampp\\htdocs\\generallink\\resources\\views/vendor/mail',
      ),
      'extensions' => 
      array (
      ),
    ),
  ),
  'queue' => 
  array (
    'default' => 'database',
    'connections' => 
    array (
      'sync' => 
      array (
        'driver' => 'sync',
      ),
      'database' => 
      array (
        'driver' => 'database',
        'connection' => NULL,
        'table' => 'jobs',
        'queue' => 'default',
        'retry_after' => 90,
        'after_commit' => false,
      ),
      'beanstalkd' => 
      array (
        'driver' => 'beanstalkd',
        'host' => 'localhost',
        'queue' => 'default',
        'retry_after' => 90,
        'block_for' => 0,
        'after_commit' => false,
      ),
      'sqs' => 
      array (
        'driver' => 'sqs',
        'key' => '',
        'secret' => '',
        'prefix' => 'https://sqs.us-east-1.amazonaws.com/your-account-id',
        'queue' => 'default',
        'suffix' => NULL,
        'region' => 'us-east-1',
        'after_commit' => false,
      ),
      'redis' => 
      array (
        'driver' => 'redis',
        'connection' => 'default',
        'queue' => 'default',
        'retry_after' => 90,
        'block_for' => NULL,
        'after_commit' => false,
      ),
      'deferred' => 
      array (
        'driver' => 'deferred',
      ),
      'failover' => 
      array (
        'driver' => 'failover',
        'connections' => 
        array (
          0 => 'database',
          1 => 'deferred',
        ),
      ),
      'background' => 
      array (
        'driver' => 'background',
      ),
    ),
    'batching' => 
    array (
      'database' => 'mysql',
      'table' => 'job_batches',
    ),
    'failed' => 
    array (
      'driver' => 'database-uuids',
      'database' => 'mysql',
      'table' => 'failed_jobs',
    ),
  ),
  'services' => 
  array (
    'postmark' => 
    array (
      'key' => NULL,
    ),
    'resend' => 
    array (
      'key' => NULL,
    ),
    'ses' => 
    array (
      'key' => '',
      'secret' => '',
      'region' => 'us-east-1',
    ),
    'slack' => 
    array (
      'notifications' => 
      array (
        'bot_user_oauth_token' => NULL,
        'channel' => NULL,
      ),
    ),
    'anthropic' => 
    array (
      'key' => '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',
    ),
    'email_ingestion' => 
    array (
      'webhook_secret' => 'gl-email-hook-8f3k2m9p7q1x5v6b4n0z',
    ),
    'google' => 
    array (
      'client_id' => '483968628370-gv8kbvobo6viq3gpgj3vrj336va7k7kh.apps.googleusercontent.com',
      'client_secret' => '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',
      'redirect_uri' => 'http://localhost/generallink/public/google/oauth/callback',
    ),
    'espocrm' => 
    array (
      'base_url' => 'http://localhost/espocrm/EspoCRM-9.2.7',
      'api_key' => 'ec9d185d20e9b49ef6f6532be00b373d',
    ),
    'elevenlabs' => 
    array (
      'key' => 'sk_383af8a5c0041d978259cbe654fade7587deccb35139ba35',
    ),
    'qpdf' => 
    array (
      'binary' => 'C:\\Program Files\\qpdf 12.4.1\\bin\\qpdf.exe',
    ),
  ),
  'session' => 
  array (
    'driver' => 'file',
    'lifetime' => 120,
    'expire_on_close' => false,
    'encrypt' => false,
    'files' => 'C:\\xampp\\htdocs\\generallink\\storage\\framework/sessions',
    'connection' => NULL,
    'table' => 'sessions',
    'store' => NULL,
    'lottery' => 
    array (
      0 => 2,
      1 => 100,
    ),
    'cookie' => 'laravel-session',
    'path' => '/',
    'domain' => NULL,
    'secure' => NULL,
    'http_only' => true,
    'same_site' => 'lax',
    'partitioned' => false,
  ),
  'dompdf' => 
  array (
    'show_warnings' => false,
    'public_path' => NULL,
    'convert_entities' => true,
    'options' => 
    array (
      'font_dir' => 'C:\\xampp\\htdocs\\generallink\\storage\\fonts',
      'font_cache' => 'C:\\xampp\\htdocs\\generallink\\storage\\fonts',
      'temp_dir' => 'C:\\Users\\chris\\AppData\\Local\\Temp',
      'chroot' => 'C:\\xampp\\htdocs\\generallink',
      'allowed_protocols' => 
      array (
        'data://' => 
        array (
          'rules' => 
          array (
          ),
        ),
        'file://' => 
        array (
          'rules' => 
          array (
          ),
        ),
        'http://' => 
        array (
          'rules' => 
          array (
          ),
        ),
        'https://' => 
        array (
          'rules' => 
          array (
          ),
        ),
      ),
      'artifactPathValidation' => NULL,
      'log_output_file' => NULL,
      'enable_font_subsetting' => false,
      'pdf_backend' => 'CPDF',
      'default_media_type' => 'screen',
      'default_paper_size' => 'a4',
      'default_paper_orientation' => 'portrait',
      'default_font' => 'serif',
      'dpi' => 96,
      'enable_php' => false,
      'enable_javascript' => true,
      'enable_remote' => false,
      'allowed_remote_hosts' => NULL,
      'font_height_ratio' => 1.1,
      'enable_html5_parser' => true,
    ),
  ),
  'blade-heroicons' => 
  array (
    'prefix' => 'heroicon',
    'fallback' => '',
    'class' => '',
    'attributes' => 
    array (
    ),
  ),
  'blade-icons' => 
  array (
    'sets' => 
    array (
    ),
    'class' => '',
    'attributes' => 
    array (
    ),
    'fallback' => '',
    'components' => 
    array (
      'disabled' => false,
      'default' => 'icon',
    ),
  ),
  'tallui' => 
  array (
    'prefix' => 'tallui',
    'route_prefix' => '',
    'datatable' => 
    array (
      'per_page' => 15,
      'per_page_options' => 
      array (
        0 => 10,
        1 => 15,
        2 => 25,
        3 => 50,
        4 => 100,
      ),
      'striped' => true,
      'header_style' => 'default',
      'persist_column_preferences' => true,
    ),
    'charts' => 
    array (
      'apexcharts_cdn' => 'https://cdn.jsdelivr.net/npm/apexcharts',
      'default_height' => 350,
      'default_poll' => 0,
      'theme' => 'light',
      'cache_ttl' => 0,
    ),
    'cache' => 
    array (
      'store' => NULL,
    ),
    'forms' => 
    array (
      'size' => 'md',
      'search_source_ttl' => 1800,
      'searchable_models' => 
      array (
        'user' => 
        array (
          'model' => 'App\\Models\\User',
          'label' => 'name',
          'value' => 'id',
          'search_columns' => 
          array (
            0 => 'name',
            1 => 'email',
          ),
          'order_by' => 'name',
          'order_direction' => 'asc',
          'limit' => 25,
        ),
      ),
    ),
    'components' => 
    array (
      'spotlight' => 
      array (
        'class' => 'App\\Support\\Spotlight',
      ),
    ),
  ),
  'livewire' => 
  array (
    'component_locations' => 
    array (
      0 => 'C:\\xampp\\htdocs\\generallink\\resources\\views/components',
      1 => 'C:\\xampp\\htdocs\\generallink\\resources\\views/livewire',
    ),
    'component_namespaces' => 
    array (
      'layouts' => 'C:\\xampp\\htdocs\\generallink\\resources\\views/layouts',
      'pages' => 'C:\\xampp\\htdocs\\generallink\\resources\\views/pages',
    ),
    'component_layout' => 'layouts::app',
    'component_placeholder' => NULL,
    'make_command' => 
    array (
      'type' => 'sfc',
      'emoji' => true,
      'with' => 
      array (
        'js' => false,
        'css' => false,
        'test' => false,
      ),
    ),
    'class_namespace' => 'App\\Livewire',
    'class_path' => 'C:\\xampp\\htdocs\\generallink\\app\\Livewire',
    'view_path' => 'C:\\xampp\\htdocs\\generallink\\resources\\views/livewire',
    'temporary_file_upload' => 
    array (
      'disk' => NULL,
      'rules' => NULL,
      'directory' => NULL,
      'middleware' => NULL,
      'preview_mimes' => 
      array (
        0 => 'png',
        1 => 'gif',
        2 => 'bmp',
        3 => 'svg',
        4 => 'wav',
        5 => 'mp4',
        6 => 'mov',
        7 => 'avi',
        8 => 'wmv',
        9 => 'mp3',
        10 => 'm4a',
        11 => 'jpg',
        12 => 'jpeg',
        13 => 'mpga',
        14 => 'webp',
        15 => 'wma',
      ),
      'max_upload_time' => 5,
      'cleanup' => true,
    ),
    'render_on_redirect' => false,
    'legacy_model_binding' => false,
    'inject_assets' => true,
    'navigate' => 
    array (
      'show_progress_bar' => true,
      'progress_bar_color' => '#2299dd',
    ),
    'inject_morph_markers' => true,
    'smart_wire_keys' => true,
    'pagination_theme' => 'tailwind',
    'release_token' => 'a',
    'csp_safe' => false,
    'payload' => 
    array (
      'max_size' => 1048576,
      'max_nesting_depth' => 10,
      'max_calls' => 50,
      'max_components' => 200,
    ),
  ),
  'media-library' => 
  array (
    'disk_name' => 'public',
    'conversions_disk_name' => NULL,
    'max_file_size' => 10485760,
    'disallowed_extensions' => 
    array (
      0 => 'php',
      1 => 'php3',
      2 => 'php4',
      3 => 'php5',
      4 => 'php6',
      5 => 'php7',
      6 => 'php8',
      7 => 'phtml',
      8 => 'phtm',
      9 => 'pht',
      10 => 'phps',
      11 => 'phar',
      12 => 'shtml',
      13 => 'shtm',
      14 => 'stm',
      15 => 'htaccess',
      16 => 'htpasswd',
      17 => 'cgi',
      18 => 'pl',
      19 => 'asp',
      20 => 'aspx',
      21 => 'jsp',
      22 => 'jspx',
    ),
    'allowed_extensions' => NULL,
    'queue_connection_name' => 'database',
    'queue_name' => '',
    'queue_conversions_by_default' => true,
    'queue_conversions_after_database_commit' => true,
    'media_model' => 'Spatie\\MediaLibrary\\MediaCollections\\Models\\Media',
    'media_observer' => 'Spatie\\MediaLibrary\\MediaCollections\\Models\\Observers\\MediaObserver',
    'use_default_collection_serialization' => false,
    'temporary_upload_model' => 'Spatie\\MediaLibraryPro\\Models\\TemporaryUpload',
    'enable_temporary_uploads_session_affinity' => true,
    'generate_thumbnails_for_temporary_uploads' => true,
    'file_namer' => 'Spatie\\MediaLibrary\\Support\\FileNamer\\DefaultFileNamer',
    'path_generator' => 'Spatie\\MediaLibrary\\Support\\PathGenerator\\DefaultPathGenerator',
    'file_remover_class' => 'Spatie\\MediaLibrary\\Support\\FileRemover\\DefaultFileRemover',
    'custom_path_generators' => 
    array (
    ),
    'url_generator' => 'Spatie\\MediaLibrary\\Support\\UrlGenerator\\DefaultUrlGenerator',
    'moves_media_on_update' => false,
    'version_urls' => false,
    'image_optimizers' => 
    array (
      'Spatie\\ImageOptimizer\\Optimizers\\Jpegoptim' => 
      array (
        0 => '-m85',
        1 => '--force',
        2 => '--strip-all',
        3 => '--all-progressive',
      ),
      'Spatie\\ImageOptimizer\\Optimizers\\Pngquant' => 
      array (
        0 => '--force',
      ),
      'Spatie\\ImageOptimizer\\Optimizers\\Optipng' => 
      array (
        0 => '-i0',
        1 => '-o2',
        2 => '-quiet',
      ),
      'Spatie\\ImageOptimizer\\Optimizers\\Svgo' => 
      array (
        0 => '--disable=cleanupIDs',
      ),
      'Spatie\\ImageOptimizer\\Optimizers\\Gifsicle' => 
      array (
        0 => '-b',
        1 => '-O3',
      ),
      'Spatie\\ImageOptimizer\\Optimizers\\Cwebp' => 
      array (
        0 => '-m 6',
        1 => '-pass 10',
        2 => '-mt',
        3 => '-q 90',
      ),
      'Spatie\\ImageOptimizer\\Optimizers\\Avifenc' => 
      array (
        0 => '-a cq-level=23',
        1 => '-j all',
        2 => '--min 0',
        3 => '--max 63',
        4 => '--minalpha 0',
        5 => '--maxalpha 63',
        6 => '-a end-usage=q',
        7 => '-a tune=ssim',
      ),
    ),
    'image_generators' => 
    array (
      0 => 'Spatie\\MediaLibrary\\Conversions\\ImageGenerators\\Image',
      1 => 'Spatie\\MediaLibrary\\Conversions\\ImageGenerators\\Webp',
      2 => 'Spatie\\MediaLibrary\\Conversions\\ImageGenerators\\Avif',
      3 => 'Spatie\\MediaLibrary\\Conversions\\ImageGenerators\\Pdf',
      4 => 'Spatie\\MediaLibrary\\Conversions\\ImageGenerators\\Svg',
      5 => 'Spatie\\MediaLibrary\\Conversions\\ImageGenerators\\Video',
    ),
    'temporary_directory_path' => NULL,
    'image_driver' => 'gd',
    'ffmpeg_path' => '/usr/bin/ffmpeg',
    'ffprobe_path' => '/usr/bin/ffprobe',
    'ffmpeg_timeout' => 900,
    'ffmpeg_threads' => 0,
    'jobs' => 
    array (
      'perform_conversions' => 'Spatie\\MediaLibrary\\Conversions\\Jobs\\PerformConversionsJob',
      'generate_responsive_images' => 'Spatie\\MediaLibrary\\ResponsiveImages\\Jobs\\GenerateResponsiveImagesJob',
    ),
    'media_downloader' => 'Spatie\\MediaLibrary\\Downloaders\\DefaultDownloader',
    'media_downloader_ssl' => true,
    'temporary_url_default_lifetime' => 5,
    'remote' => 
    array (
      'extra_headers' => 
      array (
        'CacheControl' => 'max-age=604800',
      ),
    ),
    'responsive_images' => 
    array (
      'width_calculator' => 'Spatie\\MediaLibrary\\ResponsiveImages\\WidthCalculator\\FileSizeOptimizedWidthCalculator',
      'use_tiny_placeholders' => true,
      'tiny_placeholder_generator' => 'Spatie\\MediaLibrary\\ResponsiveImages\\TinyPlaceholderGenerator\\Blurred',
    ),
    'enable_vapor_uploads' => false,
    'default_loading_attribute_value' => NULL,
    'prefix' => '',
    'force_lazy_loading' => true,
  ),
  'audit' => 
  array (
    'enabled' => true,
    'implementation' => 'OwenIt\\Auditing\\Models\\Audit',
    'user' => 
    array (
      'morph_prefix' => 'user',
      'guards' => 
      array (
        0 => 'web',
        1 => 'api',
      ),
      'resolver' => 'OwenIt\\Auditing\\Resolvers\\UserResolver',
    ),
    'resolvers' => 
    array (
      'ip_address' => 'OwenIt\\Auditing\\Resolvers\\IpAddressResolver',
      'user_agent' => 'OwenIt\\Auditing\\Resolvers\\UserAgentResolver',
      'url' => 'OwenIt\\Auditing\\Resolvers\\UrlResolver',
    ),
    'events' => 
    array (
      0 => 'created',
      1 => 'updated',
      2 => 'deleted',
      3 => 'restored',
    ),
    'strict' => false,
    'exclude' => 
    array (
    ),
    'empty_values' => true,
    'allowed_empty_values' => 
    array (
      0 => 'retrieved',
    ),
    'allowed_array_values' => false,
    'timestamps' => false,
    'threshold' => 0,
    'driver' => 'database',
    'drivers' => 
    array (
      'database' => 
      array (
        'table' => 'audits',
        'connection' => NULL,
      ),
    ),
    'queue' => 
    array (
      'enable' => false,
      'connection' => 'sync',
      'queue' => 'default',
      'delay' => 0,
    ),
    'console' => false,
  ),
  'tinker' => 
  array (
    'commands' => 
    array (
    ),
    'alias' => 
    array (
    ),
    'dont_alias' => 
    array (
      0 => 'App\\Nova',
    ),
    'trust_project' => 'always',
  ),
);
