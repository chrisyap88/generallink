<div>
<x-tallui-notification />

@php
    $status = $bill->status->value ?? (string) $bill->status;
    $badgeType = match($status) {
        'settled' => 'success',
        'approved', 'issued', 'sent' => 'info',
        'partially_settled', 'partial' => 'warning',
        'overdue', 'void' => 'error',
        default => 'neutral',
    };

    // Collect all journal entries in chronological order:
    // 1. Bill posting JE
    // 2. Payment JEs
    // 3. Charge / Discount JEs (from expenses)
    $allJournals = collect();

    if ($bill->journalEntry) {
        $allJournals->push([
            'type'  => 'Bill',
            'badge' => 'primary',
            'entry' => $bill->journalEntry,
        ]);
    }

    foreach ($bill->payments as $payment) {
        if ($payment->journalEntry) {
            $allJournals->push([
                'type'  => 'Payment',
                'badge' => 'success',
                'entry' => $payment->journalEntry,
            ]);
        }
    }

    foreach ($bill->expenses as $charge) {
        if ($charge->journalEntry) {
            $allJournals->push([
                'type'  => $charge->account?->name ?? 'Charge',
                'badge' => match($charge->account?->code ?? '') {
                    '4210' => 'info',
                    '4220' => 'info',
                    '6310' => 'info',
                    '6320' => 'info',
                    '6330' => 'info',
                    '6340' => 'info',
                    '5500', '5501', '5502', '5503' => 'error',
                    default => 'neutral',
                },
                'entry' => $charge->journalEntry,
            ]);
        }
    }

    $allJournals = $allJournals->sortBy(fn($j) => $j['entry']->date?->timestamp ?? 0)->values();
@endphp

<x-tallui-page-header title="Bill {{ $bill->bill_number }}" subtitle="Vendor bill details and payment history" icon="o-shopping-cart">
    <x-slot:actions>
        <a href="{{ route('accounting.bills') }}" class="btn btn-ghost btn-sm">Back to Bills</a>
        @if(!in_array($status, ['void']))
            <button wire:click="openDiscountModal" class="btn btn-outline btn-sm">
                Record Discount
            </button>
            <button wire:click="openChargeModal" class="btn btn-outline btn-sm">
                Record Charge
            </button>
        @endif
        @if(in_array($status, ['approved', 'issued', 'sent', 'partially_settled', 'partial', 'overdue']) && $bill->balance > 0)
            <a href="{{ route('accounting.bills', ['action' => 'pay', 'bill' => $bill->id]) }}" class="btn btn-primary btn-sm">
                Record Payment
            </a>
        @endif
    </x-slot:actions>
</x-tallui-page-header>

{{-- Bill header + summary --}}
<div class="grid gap-4 lg:grid-cols-3">
    <x-tallui-card class="lg:col-span-2">
        <div class="flex flex-wrap items-start justify-between gap-4">
            <div>
                <div class="text-sm text-base-content/60">Vendor</div>
                <div class="text-lg font-semibold">{{ $bill->vendor?->name ?? 'Unknown vendor' }}</div>
                @if($bill->vendor?->email)
                    <div class="text-sm text-base-content/60">{{ $bill->vendor->email }}</div>
                @endif
                @if($bill->vendor?->phone)
                    <div class="text-sm text-base-content/60">{{ $bill->vendor->phone }}</div>
                @endif
            </div>
            <div class="text-right">
                <x-tallui-badge :type="$badgeType">{{ str($status)->replace('_', ' ')->title() }}</x-tallui-badge>
                @if($bill->inventory_purchase_order_id && Route::has('inventory.purchase-orders.show'))
                    <div class="mt-2">
                        <a href="{{ route('inventory.purchase-orders.show', ['recordId' => $bill->inventory_purchase_order_id]) }}" wire:navigate class="inline-flex items-center gap-1 text-sm text-primary hover:underline">
                            <x-tallui-icon name="o-arrow-down-tray" class="h-3.5 w-3.5" />
                            {{ $bill->source_reference ?: 'View Purchase Order' }}
                        </a>
                    </div>
                @endif
            </div>
        </div>

        <div class="mt-6 grid gap-4 md:grid-cols-2 xl:grid-cols-4">
            <div>
                <div class="text-xs uppercase text-base-content/50">Bill Date</div>
                <div class="font-medium">{{ $bill->bill_date?->format('M d, Y') }}</div>
            </div>
            <div>
                <div class="text-xs uppercase text-base-content/50">Due Date</div>
                <div class="font-medium">{{ $bill->due_date?->format('M d, Y') }}</div>
            </div>
            <div>
                <div class="text-xs uppercase text-base-content/50">Currency</div>
                <div class="font-medium">{{ $bill->currency }}</div>
            </div>
            <div>
                <div class="text-xs uppercase text-base-content/50">Exchange Rate</div>
                <div class="font-medium">{{ number_format((float) ($bill->exchange_rate ?? 1), 4) }}</div>
            </div>
        </div>

        @if($bill->notes)
            <div class="mt-6 rounded-xl border border-base-200 bg-base-50 p-4">
                <div class="text-xs uppercase text-base-content/50">Notes</div>
                <div class="mt-1 whitespace-pre-line text-sm">{{ $bill->notes }}</div>
            </div>
        @endif
    </x-tallui-card>

    <x-tallui-card>
        <div class="space-y-3">
            <div class="flex items-center justify-between">
                <span class="text-sm text-base-content/60">Subtotal</span>
                <span class="font-mono">{{ $bill->base_currency }} {{ number_format((float) $bill->base_subtotal, 2) }}</span>
            </div>
            <div class="flex items-center justify-between">
                <span class="text-sm text-base-content/60">Tax</span>
                <span class="font-mono">{{ $bill->base_currency }} {{ number_format((float) $bill->base_tax_amount, 2) }}</span>
            </div>
            @if((float) $bill->discount_amount > 0)
                <div class="flex items-center justify-between">
                    <span class="text-sm text-base-content/60">Discount</span>
                    <span class="font-mono">-{{ $bill->base_currency }} {{ number_format((float) $bill->base_discount_amount, 2) }}</span>
                </div>
            @endif
            @if((float) $bill->shipping_amount > 0)
                <div class="flex items-center justify-between">
                    <span class="text-sm text-base-content/60">Shipping</span>
                    <span class="font-mono">{{ $bill->base_currency }} {{ number_format((float) $bill->base_shipping_amount, 2) }}</span>
                </div>
            @endif
            @if((float) $bill->other_charges_amount > 0)
                <div class="flex items-center justify-between">
                    <span class="text-sm text-base-content/60">Other Charges</span>
                    <span class="font-mono">{{ $bill->base_currency }} {{ number_format((float) $bill->base_other_charges_amount, 2) }}</span>
                </div>
            @endif
            <div class="flex items-center justify-between border-t border-base-200 pt-3">
                <span class="font-medium">Total</span>
                <span class="font-mono font-semibold">{{ $bill->base_currency }} {{ number_format((float) $bill->base_total, 2) }}</span>
            </div>
            <div class="flex items-center justify-between">
                <span class="text-sm text-base-content/60">Paid</span>
                <span class="font-mono text-success">{{ $bill->base_currency }} {{ number_format((float) $bill->base_paid_amount, 2) }}</span>
            </div>
            <div class="flex items-center justify-between">
                <span class="text-sm text-base-content/60">Balance</span>
                <span class="font-mono {{ $bill->base_balance > 0 ? 'text-warning' : 'text-success' }}">{{ $bill->base_currency }} {{ number_format((float) $bill->base_balance, 2) }}</span>
            </div>
        </div>
    </x-tallui-card>
</div>

{{-- Line Items + Payments + Charges --}}
<div class="mt-4 mb-4 grid gap-4 xl:grid-cols-3">
    <x-tallui-card class="xl:col-span-2" padding="none">
        <div class="border-b border-base-200 px-5 py-4">
            <h3 class="font-semibold">Line Items</h3>
        </div>
        <div class="overflow-x-auto">
            <table class="table table-sm w-full">
                <thead>
                    <tr class="bg-base-300 text-xs text-base-content/60 uppercase tracking-wide border-b border-base-300">
                        <th class="pl-5">Description</th>
                        <th class="text-right">Qty</th>
                        <th class="text-right">Unit Price</th>
                        <th class="text-right">Tax</th>
                        <th class="pr-5 text-right">Line Total</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-base-200">
                    @forelse($bill->items as $item)
                        <tr class="even:bg-base-200/50 hover:bg-base-200">
                            <td class="pl-5 text-sm">{{ $item->description }}</td>
                            <td class="text-right font-mono text-sm">{{ number_format((float) $item->quantity, 2) }}</td>
                            <td class="text-right font-mono text-sm">{{ $bill->base_currency }} {{ number_format($bill->convertToBase($item->unit_price), 2) }}</td>
                            <td class="text-right font-mono text-sm">{{ $bill->base_currency }} {{ number_format($bill->convertToBase($item->tax_amount), 2) }}</td>
                            <td class="pr-5 text-right font-mono text-sm">{{ $bill->base_currency }} {{ number_format($bill->convertToBase($item->total), 2) }}</td>
                        </tr>
                    @empty
                        <tr>
                            <td colspan="5" class="px-5 py-6 text-center text-sm text-base-content/60">No line items recorded.</td>
                        </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
    </x-tallui-card>

    <div class="flex flex-col gap-4">
        {{-- Payments --}}
        <x-tallui-card padding="none">
            <div class="border-b border-base-200 px-5 py-4">
                <h3 class="font-semibold">Payments</h3>
            </div>
            <div class="divide-y divide-base-200">
                @forelse($bill->payments as $payment)
                    <div class="px-5 py-3">
                        <div class="flex items-start justify-between gap-3">
                            <div>
                                <div class="font-medium text-sm">{{ $payment->payment_date?->format('M d, Y') }}</div>
                                <div class="text-xs text-base-content/60">{{ str($payment->payment_method)->replace('_', ' ')->title() }}</div>
                                @if($payment->reference)
                                    <div class="text-xs text-base-content/50">Ref: {{ $payment->reference }}</div>
                                @endif
                            </div>
                            <div class="text-right">
                                <div class="font-mono font-semibold text-sm">{{ $bill->base_currency }} {{ number_format($bill->convertToBase($payment->amount), 2) }}</div>
                                @if($payment->journalEntry)
                                    <div class="font-mono text-xs text-base-content/40">{{ $payment->journalEntry->entry_number }}</div>
                                @endif
                            </div>
                        </div>
                    </div>
                @empty
                    <div class="px-5 py-6 text-sm text-base-content/60">No payments recorded yet.</div>
                @endforelse
            </div>
        </x-tallui-card>

        {{-- Charges & Discounts --}}
        @if($bill->expenses->isNotEmpty())
        <x-tallui-card padding="none">
            <div class="border-b border-base-200 px-5 py-4">
                <div class="flex items-center justify-between">
                    <h3 class="font-semibold">Charges & Discounts</h3>
                    <span class="badge badge-ghost badge-sm">{{ $bill->expenses->count() }}</span>
                </div>
            </div>
            <div class="divide-y divide-base-200">
                @foreach($bill->expenses as $item)
                    @php
                        $itemBadge = match($item->account?->code ?? '') {
                            '4210', '4220', '6310', '6320', '6330', '6340' => 'info',
                            '5500', '5501', '5502', '5503' => 'error',
                            default => 'neutral',
                        };
                    @endphp
                    <div class="px-5 py-3">
                        <div class="flex items-start justify-between gap-3">
                            <div>
                                <x-tallui-badge :type="$itemBadge" size="sm">{{ $item->account?->name ?? 'Entry' }}</x-tallui-badge>
                                <div class="mt-1 text-xs text-base-content/60">{{ $item->expense_date?->format('M d, Y') }}</div>
                                @if($item->notes)
                                    <div class="text-xs text-base-content/50">{{ $item->notes }}</div>
                                @endif
                            </div>
                            <div class="text-right">
                                @php $isDiscountItem = in_array($item->account?->code, ['5500', '5501', '5502', '5503'], true); @endphp
                                <div class="font-mono font-semibold text-sm {{ $isDiscountItem ? 'text-error' : '' }}">
                                    {{ $isDiscountItem ? '−' : '+' }}{{ $bill->base_currency }} {{ number_format((float) $item->total, 2) }}
                                </div>
                                @if($item->journalEntry)
                                    <div class="font-mono text-xs text-base-content/40">{{ $item->journalEntry->entry_number }}</div>
                                @endif
                            </div>
                        </div>
                    </div>
                @endforeach
            </div>
        </x-tallui-card>
        @endif
    </div>
</div>

{{-- Unified Journal Ledger --}}
<x-tallui-card class="mt-4" padding="none">
    <div class="border-b border-base-200 px-5 py-4">
        <div class="flex items-center justify-between">
            <div>
                <h3 class="font-semibold">Journal Ledger</h3>
                <p class="text-sm text-base-content/60">All accounting entries for this bill</p>
            </div>
            @if($allJournals->isNotEmpty())
                <span class="badge badge-ghost badge-sm">{{ $allJournals->count() }} {{ Str::plural('entry', $allJournals->count()) }}</span>
            @endif
        </div>
    </div>

    @forelse($allJournals as $journal)
        @php
            $je = $journal['entry'];
            $jeStatus = $je->status?->value ?? (string) $je->status;
        @endphp

        <div class="border-b border-base-200 bg-base-50 px-5 py-3">
            <div class="flex flex-wrap items-center gap-3">
                <x-tallui-badge :type="$journal['badge']" size="sm">{{ $journal['type'] }}</x-tallui-badge>
                <span class="font-mono text-sm font-semibold">{{ $je->entry_number }}</span>
                <span class="text-sm text-base-content/60">{{ $je->date?->format('M d, Y') }}</span>
                <span class="text-sm text-base-content/50">·</span>
                <span class="text-sm text-base-content/70">{{ $je->description }}</span>
                <span class="ml-auto">
                    <x-tallui-badge :type="match($jeStatus) { 'posted' => 'success', 'void' => 'error', default => 'neutral' }" size="sm">
                        {{ str($jeStatus)->replace('_', ' ')->title() }}
                    </x-tallui-badge>
                </span>
            </div>
        </div>

        <div class="overflow-x-auto {{ !$loop->last ? 'border-b border-base-200' : '' }}">
            <table class="table table-sm w-full">
                <thead>
                    <tr class="bg-base-300 text-xs text-base-content/60 uppercase tracking-wide border-b border-base-300">
                        <th class="pl-5">Account</th>
                        <th>Description</th>
                        <th class="text-right">Debit</th>
                        <th class="pr-5 text-right">Credit</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-base-200">
                    @foreach($je->lines as $line)
                        <tr class="even:bg-base-200/50 hover:bg-base-200">
                            <td class="pl-5 text-sm">
                                <div class="font-medium">{{ $line->account?->name ?? 'Unknown account' }}</div>
                                <div class="text-xs text-base-content/40">{{ $line->account?->code }}</div>
                            </td>
                            <td class="text-sm text-base-content/60">{{ $line->description ?: $je->description ?: '—' }}</td>
                            <td class="text-right font-mono text-sm">
                                {{ $line->type === 'debit' ? number_format((float) $line->amount, 2) : '—' }}
                            </td>
                            <td class="pr-5 text-right font-mono text-sm">
                                {{ $line->type === 'credit' ? number_format((float) $line->amount, 2) : '—' }}
                            </td>
                        </tr>
                    @endforeach
                </tbody>
                <tfoot>
                    <tr class="bg-base-200/50 text-xs font-semibold text-base-content/60">
                        <td colspan="2" class="pl-5 py-2">Totals</td>
                        <td class="py-2 text-right font-mono">{{ number_format((float) $je->lines->where('type', 'debit')->sum('amount'), 2) }}</td>
                        <td class="pr-5 py-2 text-right font-mono">{{ number_format((float) $je->lines->where('type', 'credit')->sum('amount'), 2) }}</td>
                    </tr>
                </tfoot>
            </table>
        </div>
    @empty
        <div class="px-5 py-6 text-sm text-base-content/60">No journal entries recorded for this bill yet.</div>
    @endforelse
</x-tallui-card>

{{-- Record Discount Modal --}}
@if($showDiscountModal)
<div class="modal modal-open">
    <div class="modal-box max-w-md">
        <h3 class="mb-4 text-lg font-bold">Record Purchase Discount</h3>

        <div class="space-y-4">
            <div>
                <label class="label"><span class="label-text font-medium">Discount Type <span class="text-error">*</span></span></label>
                <select wire:model="discount_type" class="select select-bordered w-full">
                    @foreach($this->discountAccounts as $acct)
                        <option value="{{ $acct->code }}">{{ $acct->name }} ({{ $acct->code }})</option>
                    @endforeach
                </select>
                @error('discount_type') <span class="mt-1 text-xs text-error">{{ $message }}</span> @enderror
            </div>

            <div>
                <label class="label"><span class="label-text font-medium">Discount Amount <span class="text-error">*</span></span></label>
                <label class="input input-bordered flex items-center gap-2">
                    <span class="text-sm text-base-content/60">{{ $bill->base_currency }}</span>
                    <input wire:model="discount_amount" type="number" step="0.01" min="0.01" placeholder="0.00" class="grow" />
                </label>
                @error('discount_amount') <span class="mt-1 text-xs text-error">{{ $message }}</span> @enderror
            </div>

            <div>
                <label class="label"><span class="label-text font-medium">Date <span class="text-error">*</span></span></label>
                <input wire:model="discount_date" type="date" class="input input-bordered w-full" />
                @error('discount_date') <span class="mt-1 text-xs text-error">{{ $message }}</span> @enderror
            </div>

            <div>
                <label class="label"><span class="label-text font-medium">Notes</span></label>
                <textarea wire:model="discount_notes" rows="2" placeholder="Reason for discount..." class="textarea textarea-bordered w-full"></textarea>
            </div>

            <div class="rounded-lg border border-base-200 bg-base-50 px-4 py-3 text-sm">
                <div class="flex items-center justify-between">
                    <span class="text-base-content/60">Available AP balance</span>
                    <span class="font-mono font-semibold {{ $this->availableAp() > 0 ? 'text-success' : 'text-error' }}">
                        {{ $bill->base_currency }} {{ number_format($this->availableAp(), 2) }}
                    </span>
                </div>
            </div>
            <div class="rounded-lg border border-error/30 bg-error/10 px-4 py-3 text-sm text-base-content/70">
                Journal entry posted: <span class="font-mono">DR AP (2000) / CR {{ $discount_type }}</span>
            </div>
        </div>

        <div class="modal-action">
            <button wire:click="$set('showDiscountModal', false)" class="btn btn-ghost">Cancel</button>
            <button wire:click="recordDiscount" wire:loading.attr="disabled" class="btn btn-error">
                <span wire:loading wire:target="recordDiscount" class="loading loading-spinner loading-sm"></span>
                Record Discount
            </button>
        </div>
    </div>
    <div class="modal-backdrop" wire:click="$set('showDiscountModal', false)"></div>
</div>
@endif

{{-- Record Charge Modal --}}
@if($showChargeModal)
<div class="modal modal-open">
    <div class="modal-box max-w-md">
        <h3 class="mb-4 text-lg font-bold">Record Charge</h3>

        <div class="space-y-4">
            <div>
                <label class="label"><span class="label-text font-medium">Charge Type <span class="text-error">*</span></span></label>
                <select wire:model="charge_type" class="select select-bordered w-full">
                    <option value="4210">Delivery Charge (4210)</option>
                    <option value="4220">Cash on Delivery Charge (4220)</option>
                    <option value="6310">Courier Bill / Charge (6310)</option>
                    <option value="6320">Shipping / Transfer Bill — Carriage (6320)</option>
                    <option value="6330">Hand Carry Delivery (6330)</option>
                    <option value="6340">Delivery Return Charge (6340)</option>
                </select>
                @error('charge_type') <span class="mt-1 text-xs text-error">{{ $message }}</span> @enderror
            </div>

            <div>
                <label class="label"><span class="label-text font-medium">Amount <span class="text-error">*</span></span></label>
                <label class="input input-bordered flex items-center gap-2">
                    <span class="text-sm text-base-content/60">{{ $bill->base_currency }}</span>
                    <input wire:model="charge_amount" type="number" step="0.01" min="0.01" placeholder="0.00" class="grow" />
                </label>
                @error('charge_amount') <span class="mt-1 text-xs text-error">{{ $message }}</span> @enderror
            </div>

            <div>
                <label class="label"><span class="label-text font-medium">Date <span class="text-error">*</span></span></label>
                <input wire:model="charge_date" type="date" class="input input-bordered w-full" />
                @error('charge_date') <span class="mt-1 text-xs text-error">{{ $message }}</span> @enderror
            </div>

            <div>
                <label class="label"><span class="label-text font-medium">Paid From <span class="text-error">*</span></span></label>
                <select wire:model="charge_account_code" class="select select-bordered w-full">
                    @foreach($this->chargeAccounts as $acct)
                        <option value="{{ $acct->code }}">{{ $acct->code }} — {{ $acct->name }}</option>
                    @endforeach
                </select>
                @error('charge_account_code') <span class="mt-1 text-xs text-error">{{ $message }}</span> @enderror
            </div>

            <div>
                <label class="label"><span class="label-text font-medium">Notes</span></label>
                <textarea wire:model="charge_notes" rows="2" placeholder="Optional notes..." class="textarea textarea-bordered w-full"></textarea>
            </div>

            <div class="rounded-lg border border-base-200 bg-base-50 px-4 py-3 text-sm">
                <div class="flex items-center justify-between">
                    <span class="text-base-content/60">Available AP balance</span>
                    <span class="font-mono font-semibold text-success">
                        {{ $bill->base_currency }} {{ number_format($this->availableAp(), 2) }}
                    </span>
                </div>
            </div>
            <div class="rounded-lg border border-info/30 bg-info/10 px-4 py-3 text-sm text-base-content/70">
                Journal entry posted: <span class="font-mono">DR {{ $charge_type }} / CR {{ $charge_account_code }}</span>
            </div>
        </div>

        <div class="modal-action">
            <button wire:click="$set('showChargeModal', false)" class="btn btn-ghost">Cancel</button>
            <button wire:click="recordCharge" wire:loading.attr="disabled" class="btn btn-primary">
                <span wire:loading wire:target="recordCharge" class="loading loading-spinner loading-sm"></span>
                Record Charge
            </button>
        </div>
    </div>
    <div class="modal-backdrop" wire:click="$set('showChargeModal', false)"></div>
</div>
@endif

</div>
