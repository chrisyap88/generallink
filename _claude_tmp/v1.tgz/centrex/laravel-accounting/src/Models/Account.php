<?php

declare(strict_types = 1);

namespace Centrex\Accounting\Models;

use Centrex\Accounting\Concerns\AddTablePrefix;
use Centrex\Accounting\Enums\{AccountSubtype, AccountType};
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\{Model, SoftDeletes};
use Illuminate\Database\Eloquent\Relations\{BelongsTo, HasMany};
use OwenIt\Auditing\Auditable as AuditableTrait;
use OwenIt\Auditing\Contracts\Auditable;

// Account Model
class Account extends Model implements Auditable
{
    use AddTablePrefix;
    use AuditableTrait;
    use HasFactory;
    use SoftDeletes;

    protected function getTableSuffix(): string
    {
        return 'accounts';
    }

    /**
     * Specify the connection, since this implements multitenant solution
     * Called via constructor to faciliate testing
     */
    public function __construct(array $attributes = [])
    {
        parent::__construct($attributes);
        $this->setConnection(config('accounting.drivers.database.connection', config('database.default')));
    }

    protected $fillable = [
        'code', 'name', 'type', 'subtype', 'parent_id',
        'description', 'currency', 'is_active', 'is_system', 'level',
    ];

    protected $casts = [
        'type'      => AccountType::class,
        'subtype'   => AccountSubtype::class,
        'is_active' => 'boolean',
        'is_system' => 'boolean',
        'level'     => 'integer',
    ];

    public function parent(): BelongsTo
    {
        return $this->belongsTo(Account::class, 'parent_id');
    }

    public function children(): HasMany
    {
        return $this->hasMany(Account::class, 'parent_id');
    }

    public function journalEntryLines(): HasMany
    {
        return $this->hasMany(JournalEntryLine::class);
    }

    public function balances(): HasMany
    {
        return $this->hasMany(AccountBalance::class);
    }

    // Get current balance
    public function getCurrentBalance(): float
    {
        $debits = $this->journalEntryLines()
            ->whereHas('journalEntry', function ($q): void {
                $q->where('status', 'posted');
            })
            ->where('type', 'debit')
            ->sum('amount');

        $credits = $this->journalEntryLines()
            ->whereHas('journalEntry', function ($q): void {
                $q->where('status', 'posted');
            })
            ->where('type', 'credit')
            ->sum('amount');

        return $this->isDebitAccount() ? ($debits - $credits) : ($credits - $debits);
    }

    // Check if account has normal debit balance
    public function isDebitAccount(): bool
    {
        // $this->type is cast to AccountType enum; in PHP 8.1+ backed enums never equal
        // plain strings via ==, so we compare the backing value explicitly.
        $type = $this->type instanceof \BackedEnum ? $this->type->value : (string) $this->type;

        return in_array($type, ['asset', 'expense'], true);
    }
}
