<?php

declare(strict_types = 1);

namespace Centrex\Accounting\Models;

use Centrex\Accounting\Concerns\AddTablePrefix;
use Centrex\Accounting\Enums\EntryStatus;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\{Model, SoftDeletes};
use Illuminate\Database\Eloquent\Relations\{BelongsTo, HasMany, MorphMany};
use Illuminate\Support\Facades\DB;
use OwenIt\Auditing\Auditable as AuditableTrait;
use OwenIt\Auditing\Contracts\Auditable;

class Bill extends Model implements Auditable
{
    use AddTablePrefix;
    use AuditableTrait;
    use HasFactory;
    use SoftDeletes;

    /**
     * Expense account codes that reduce AP when recorded against a bill: manual
     * purchase discounts plus purchase returns & allowances posted by the inventory
     * ERP integration. Canonical set — also used by BillDetails and VendorLedger.
     */
    public const AP_REDUCING_ACCOUNT_CODES = ['5500', '5501', '5502', '5503', '5504'];

    protected function getTableSuffix(): string
    {
        return 'bills';
    }

    public function __construct(array $attributes = [])
    {
        parent::__construct($attributes);
        $this->setConnection(config('accounting.drivers.database.connection', config('database.default')));
    }

    protected $fillable = [
        'bill_number', 'vendor_id', 'bill_date', 'due_date',
        'subtotal', 'tax_amount', 'discount_amount', 'shipping_amount', 'other_charges_amount', 'total', 'paid_amount',
        'grni_clearing_amount',
        'currency', 'exchange_rate', 'status', 'notes', 'journal_entry_id',
        'source_type', 'source_id', 'source_reference', 'sbu_code',
        'inventory_purchase_order_id',
    ];

    protected $casts = [
        'bill_date'            => 'date',
        'due_date'             => 'date',
        'status'               => EntryStatus::class,
        'subtotal'             => 'decimal:2',
        'tax_amount'           => 'decimal:2',
        'discount_amount'      => 'decimal:2',
        'shipping_amount'      => 'decimal:2',
        'other_charges_amount' => 'decimal:2',
        'grni_clearing_amount' => 'decimal:2',
        'total'                => 'decimal:2',
        'paid_amount'          => 'decimal:2',
        'exchange_rate'        => 'decimal:6',
    ];

    #[\Override]
    protected static function boot(): void
    {
        parent::boot();

        static::creating(function (self $bill): void {
            if ($bill->bill_number) {
                return;
            }

            DB::connection($bill->getConnectionName())->transaction(function () use ($bill) {
                $date = now()->format('Ymd');

                $lastBill = self::withTrashed()
                    ->orderByDesc('id') // safer than bill_number
                    ->lockForUpdate()
                    ->first();

                $sequence = 1;

                if ($lastBill && preg_match('/(\d+)$/', $lastBill->bill_number, $m)) {
                    $sequence = ((int) $m[1]) + 1;
                }

                $bill->bill_number = sprintf(
                    'BILL-%s-%05d',
                    $date,
                    $sequence,
                );
            });
        });
    }

    public function vendor(): BelongsTo
    {
        return $this->belongsTo(Vendor::class);
    }

    public function items(): HasMany
    {
        return $this->hasMany(BillItem::class);
    }

    public function payments(): HasMany
    {
        return $this->hasMany(Payment::class, 'payable_id')
            ->where('payable_type', self::class);
    }

    public function journalEntry(): BelongsTo
    {
        return $this->belongsTo(JournalEntry::class);
    }

    public function expenses(): MorphMany
    {
        return $this->morphMany(Expense::class, 'chargeable');
    }

    public function convertToBase(float|int|string|null $amount): float
    {
        $value = (float) ($amount ?? 0);
        $rate = (float) ($this->exchange_rate ?? 1);

        if ($rate <= 0) {
            $rate = 1.0;
        }

        return round($value * $rate, 2);
    }

    public function getBaseCurrencyAttribute(): string
    {
        return (string) config('accounting.base_currency', 'BDT');
    }

    public function getBaseSubtotalAttribute(): float
    {
        return $this->convertToBase($this->subtotal);
    }

    public function getBaseTaxAmountAttribute(): float
    {
        return $this->convertToBase($this->tax_amount);
    }

    public function getBaseDiscountAmountAttribute(): float
    {
        return $this->convertToBase($this->discount_amount);
    }

    public function getBaseShippingAmountAttribute(): float
    {
        return $this->convertToBase($this->shipping_amount);
    }

    public function getBaseOtherChargesAmountAttribute(): float
    {
        return $this->convertToBase($this->other_charges_amount);
    }

    public function getBaseTotalAttribute(): float
    {
        return $this->convertToBase($this->total);
    }

    public function getBasePaidAmountAttribute(): float
    {
        return $this->convertToBase($this->paid_amount);
    }

    public function getBaseBalanceAttribute(): float
    {
        return $this->convertToBase($this->balance);
    }

    public function getBalanceAttribute(): float
    {
        $discounts = $this->expenses()
            ->whereHas('account', fn ($q) => $q->whereIn('code', self::AP_REDUCING_ACCOUNT_CODES))
            ->sum('total');

        return round((float) $this->total - (float) $this->paid_amount - (float) $discounts, 2);
    }
}
