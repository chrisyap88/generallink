<?php

declare(strict_types = 1);

namespace Centrex\Accounting\Livewire;

use Centrex\Accounting\Accounting;
use Centrex\Accounting\Concerns\ShowsAuditTrail;
use Centrex\Accounting\Models\{Account, Bill, BillItem, TaxRate, Vendor};
use Illuminate\Support\Facades\DB;
use Livewire\Attributes\{Computed, On};
use Livewire\Component;

class Bills extends Component
{
    use ShowsAuditTrail;

    public bool $showModal = false;

    public bool $showPayModal = false;

    public ?int $billId = null;

    public ?int $vendor_id = null;

    public string $bill_date = '';

    public string $due_date = '';

    public string $currency = '';

    public string $notes = '';

    public array $items = [];

    public ?int $payingBillId = null;

    public string $pay_date = '';

    public string $pay_amount = '';

    public string $pay_method = 'bank_transfer';

    public string $pay_account_code = '1100';

    public string $pay_reference = '';

    public string $pay_notes = '';

    public function mount(): void
    {
        $this->bill_date = now()->format('Y-m-d');
        $this->due_date = now()->addDays(30)->format('Y-m-d');
        $this->currency = config('accounting.base_currency', 'BDT');
        $this->addItem();

        $this->handleRequestedAction();
    }

    protected function handleRequestedAction(): void
    {
        if (!request()->filled('bill')) {
            return;
        }

        $billId = (int) request()->query('bill');

        if ($billId <= 0) {
            return;
        }

        $bill = Bill::query()->find($billId);

        if (!$bill) {
            return;
        }

        $action = (string) request()->query('action', '');

        if (in_array($action, ['post', 'post-and-pay'], true) && ($bill->status->value ?? (string) $bill->status) === 'draft') {
            try {
                app(Accounting::class)->postBill($bill);
                $bill->refresh();
                $this->dispatch('notify', type: 'success', message: "Bill {$bill->bill_number} approved.");
            } catch (\Throwable $e) {
                $this->dispatch('notify', type: 'error', message: $e->getMessage());

                return;
            }
        }

        if (in_array($action, ['pay', 'post-and-pay'], true)) {
            $this->openPayModal($billId);
        }
    }

    public function addItem(): void
    {
        $this->items[] = ['description' => '', 'quantity' => 1, 'unit_price' => 0, 'tax_rate' => 0, 'tax_rate_id' => null];
    }

    public function removeItem(int $index): void
    {
        unset($this->items[$index]);
        $this->items = array_values($this->items);
    }

    public function openCreate(): void
    {
        $this->reset(['billId', 'vendor_id', 'notes', 'items']);
        $this->bill_date = now()->format('Y-m-d');
        $this->due_date = now()->addDays(30)->format('Y-m-d');
        $this->currency = config('accounting.base_currency', 'BDT');
        $this->addItem();
        $this->showModal = true;
    }

    public function save(): void
    {
        $this->validate([
            'vendor_id'           => 'required|integer',
            'bill_date'           => 'required|date',
            'due_date'            => 'required|date|after_or_equal:bill_date',
            'items'               => 'required|array|min:1',
            'items.*.description' => 'required|string',
            'items.*.quantity'    => 'required|numeric|min:0.01',
            'items.*.unit_price'  => 'required|numeric|min:0',
            'items.*.tax_rate_id' => 'nullable|integer|exists:' . config('accounting.table_prefix', 'acct_') . 'tax_rates,id',
        ]);

        DB::transaction(function (): void {
            $subtotal = 0;
            $taxAmount = 0;

            foreach ($this->items as $item) {
                $amount = $item['quantity'] * $item['unit_price'];
                $itemTax = $amount * ($this->effectiveTaxRate($item) / 100);
                $subtotal += $amount;
                $taxAmount += $itemTax;
            }

            $bill = Bill::create([
                'vendor_id'  => $this->vendor_id,
                'bill_date'  => $this->bill_date,
                'due_date'   => $this->due_date,
                'subtotal'   => $subtotal,
                'tax_amount' => $taxAmount,
                'total'      => $subtotal + $taxAmount,
                'currency'   => $this->currency,
                'status'     => 'draft',
                'notes'      => $this->notes ?: null,
            ]);

            foreach ($this->items as $item) {
                $amount = $item['quantity'] * $item['unit_price'];
                $taxRate = $this->effectiveTaxRate($item);

                BillItem::create([
                    'bill_id'     => $bill->id,
                    'description' => $item['description'],
                    'quantity'    => $item['quantity'],
                    'unit_price'  => $item['unit_price'],
                    'amount'      => $amount,
                    'tax_rate'    => $taxRate,
                    'tax_rate_id' => $item['tax_rate_id'] ?? null,
                    'tax_amount'  => $amount * ($taxRate / 100),
                ]);
            }
        });

        $this->dispatch('notify', type: 'success', message: 'Bill created successfully!');
        $this->showModal = false;
        $this->reset(['billId', 'vendor_id', 'items']);
        $this->dispatch('bill-table:refresh');
    }

    #[On('bill-table:post')]
    public function postBill(int $id): void
    {
        $bill = Bill::findOrFail($id);

        try {
            app(Accounting::class)->postBill($bill);
            $this->dispatch('notify', type: 'success', message: "Bill {$bill->bill_number} approved.");
            $this->dispatch('bill-table:refresh');
        } catch (\Throwable $e) {
            $this->dispatch('notify', type: 'error', message: $e->getMessage());
        }
    }

    #[On('bill-table:audit')]
    public function openBillAuditTrail(int $id): void
    {
        $bill = Bill::findOrFail($id);
        $this->openAuditTrail($bill::class, $bill->getKey(), $bill->bill_number);
    }

    #[Computed]
    public function activeTaxRates(): \Illuminate\Database\Eloquent\Collection
    {
        return TaxRate::where('is_active', true)->orderBy('name')->get(['id', 'name', 'code', 'rate', 'is_compound']);
    }

    /** Resolve the percentage to apply for a line: the linked TaxRate's current rate, or the free-typed fallback. */
    protected function effectiveTaxRate(array $item): float
    {
        if (!empty($item['tax_rate_id'])) {
            $rate = TaxRate::find($item['tax_rate_id']);

            if ($rate !== null) {
                return (float) $rate->rate;
            }
        }

        return (float) ($item['tax_rate'] ?? 0);
    }

    #[Computed]
    public function paymentAccounts(): \Illuminate\Database\Eloquent\Collection
    {
        return Account::where('is_active', true)
            ->where('type', 'asset')
            ->where(fn ($q) => $q->where('code', 'like', '10%')->orWhere('code', 'like', '11%'))
            ->orderBy('code')
            ->get(['id', 'code', 'name']);
    }

    #[Computed]
    public function payingBill(): ?Bill
    {
        return $this->payingBillId ? Bill::find($this->payingBillId) : null;
    }

    #[On('bill-table:pay')]
    public function openPayModal(int $id): void
    {
        $bill = Bill::findOrFail($id);
        $this->payingBillId = $id;
        $this->pay_date = now()->format('Y-m-d');
        $this->pay_amount = number_format($bill->balance, 2, '.', '');
        $this->pay_method = 'bank_transfer';
        $this->pay_account_code = '1100';
        $this->pay_reference = '';
        $this->pay_notes = '';
        $this->showPayModal = true;
    }

    public function recordPayment(): void
    {
        $this->validate([
            'pay_date'         => 'required|date',
            'pay_amount'       => 'required|numeric|min:0.01',
            'pay_method'       => 'required|string',
            'pay_account_code' => 'required|string',
        ]);

        $bill = Bill::findOrFail($this->payingBillId);

        if ((float) $this->pay_amount > $bill->balance + 0.005) {
            $this->addError('pay_amount', 'Amount cannot exceed the outstanding balance of ' . $bill->currency . ' ' . number_format($bill->balance, 2) . '.');

            return;
        }

        try {
            app(Accounting::class)->recordBillPayment($bill, [
                'date'         => $this->pay_date,
                'amount'       => $this->pay_amount,
                'method'       => $this->pay_method,
                'account_code' => $this->pay_account_code,
                'reference'    => $this->pay_reference ?: null,
                'notes'        => $this->pay_notes ?: null,
            ]);

            $this->dispatch('notify', type: 'success', message: 'Payment recorded successfully!');
            $this->showPayModal = false;
            $this->dispatch('bill-table:refresh');
        } catch (\Throwable $e) {
            $this->dispatch('notify', type: 'error', message: $e->getMessage());
        }
    }

    public function getSubtotalProperty(): float
    {
        return collect($this->items)->sum(fn ($i): int|float => ($i['quantity'] ?? 0) * ($i['unit_price'] ?? 0));
    }

    public function getTaxTotalProperty(): float
    {
        return collect($this->items)->sum(function ($i): float {
            $amount = ($i['quantity'] ?? 0) * ($i['unit_price'] ?? 0);

            return $amount * ($this->effectiveTaxRate($i) / 100);
        });
    }

    public function getTotalProperty(): float
    {
        return $this->subtotal + $this->taxTotal;
    }

    public function render()
    {
        $vendors = Vendor::where('is_active', true)->orderBy('name')->get();

        $layout = view()->exists('layouts.app')
        ? 'layouts.app'
        : 'components.layouts.app';

        return view('accounting::livewire.bills', ['vendors' => $vendors])->layout($layout, ['title' => __('Bills')]);
    }
}
