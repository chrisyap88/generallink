<?php

declare(strict_types = 1);

namespace Centrex\Accounting\Livewire;

use Centrex\Accounting\Concerns\ShowsAuditTrail;
use Centrex\Accounting\Models\Account;
use Illuminate\Contracts\View\View;
use Illuminate\Validation\Rule;
use Livewire\{Component, WithPagination};

class ChartOfAccounts extends Component
{
    use ShowsAuditTrail;
    use WithPagination;

    public $search = '';

    public $typeFilter = '';

    public $showModal = false;

    // Form fields
    public $accountId;

    public $code;

    public $name;

    public $type;

    public $subtype;

    public $parent_id;

    public $description;

    public $currency = 'USD';

    public $is_active = true;

    public function openModal($id = null): void
    {
        $this->reset(['code', 'name', 'type', 'subtype', 'parent_id', 'description']);

        if ($id) {
            $account = Account::findOrFail($id);
            $this->accountId = $account->id;
            $this->code = $account->code;
            $this->name = $account->name;
            $this->type = $account->type;
            $this->subtype = $account->subtype;
            $this->parent_id = $account->parent_id;
            $this->description = $account->description;
            $this->currency = $account->currency;
            $this->is_active = $account->is_active;
        }

        $this->showModal = true;
    }

    public function save(): void
    {
        $this->validate([
            'code' => [
                'required',
                Rule::unique((new Account())->getTable(), 'code')
                    ->ignore($this->accountId),
            ],
            'name'     => 'required|min:3',
            'type'     => 'required|in:asset,liability,equity,revenue,expense',
            'currency' => 'required|size:3',
        ]);

        if ($this->accountId) {
            $account = Account::findOrFail($this->accountId);
            $account->update([
                'code'        => $this->code,
                'name'        => $this->name,
                'type'        => $this->type,
                'subtype'     => $this->subtype,
                'parent_id'   => $this->parent_id,
                'description' => $this->description,
                'currency'    => $this->currency,
                'is_active'   => $this->is_active,
            ]);
            $message = 'Account updated successfully!';
        } else {
            Account::create([
                'code'        => $this->code,
                'name'        => $this->name,
                'type'        => $this->type,
                'subtype'     => $this->subtype,
                'parent_id'   => $this->parent_id,
                'description' => $this->description,
                'currency'    => $this->currency,
                'is_active'   => $this->is_active,
            ]);
            $message = 'Account created successfully!';
        }

        session()->flash('message', $message);
        $this->showModal = false;
        $this->reset(['accountId', 'code', 'name', 'type']);
    }

    public function toggleStatus($id): void
    {
        $account = Account::findOrFail($id);

        if ($account->is_system) {
            session()->flash('error', 'Cannot deactivate system accounts');

            return;
        }

        $account->update(['is_active' => !$account->is_active]);
        session()->flash('message', 'Account status updated!');
    }

    public function exportPdf()
    {
        if (!class_exists(\Barryvdh\DomPDF\Facade\Pdf::class)) {
            session()->flash('error', 'PDF export is not available in this environment.');

            return null;
        }

        $accounts = $this->filteredAccountsQuery()
            ->with('parent')
            ->get();

        $pdf = \Barryvdh\DomPDF\Facade\Pdf::loadView('accounting::pdf.chart-of-accounts', [
            'accounts'    => $accounts,
            'search'      => $this->search,
            'typeFilter'  => $this->typeFilter,
            'generatedAt' => now(),
        ]);

        return response()->streamDownload(
            static fn () => print ($pdf->output()),
            'chart-of-accounts-' . now()->format('Ymd_His') . '.pdf',
        );
    }

    protected function filteredAccountsQuery()
    {
        return Account::query()
            ->when($this->search, function ($q): void {
                $q->where(function ($query): void {
                    $query->where('code', 'like', '%' . $this->search . '%')
                        ->orWhere('name', 'like', '%' . $this->search . '%');
                });
            })
            ->when($this->typeFilter, fn ($q) => $q->where('type', $this->typeFilter))
            ->orderBy('code');
    }

    /**
     * Build a QuickBooks-style tree: grouped by account type in standard financial-statement
     * order, with each top-level (parentless) account immediately followed by its children
     * (flattened with a depth marker for indentation, since the UI renders a flat list of rows).
     *
     * A search/type filter narrows the underlying account set, but a matched child still pulls
     * its parent in too (unindented, marked so the view can grey it out) — otherwise a filtered
     * child would appear with no visual anchor for its indentation.
     *
     * @return array<int, array{type: string, rows: array<int, array{account: Account, depth: int, matched: bool}>}>
     */
    protected function groupedAccounts(): array
    {
        $matched = $this->filteredAccountsQuery()->get();
        $matchedIds = $matched->pluck('id')->all();

        $parentIds = $matched->pluck('parent_id')->filter()->diff($matchedIds)->unique();
        $extraParents = $parentIds->isEmpty() ? collect() : Account::query()->whereIn('id', $parentIds)->get();

        $all = $matched->concat($extraParents)->unique('id');
        $byParent = $all->groupBy('parent_id');

        $buildRows = function (?int $parentId, int $depth) use (&$buildRows, $byParent, $matchedIds): array {
            $rows = [];

            foreach ($byParent->get($parentId, collect())->sortBy('code') as $account) {
                $rows[] = ['account' => $account, 'depth' => $depth, 'matched' => in_array($account->id, $matchedIds, true)];
                $rows = array_merge($rows, $buildRows($account->id, $depth + 1));
            }

            return $rows;
        };

        $typeOrder = ['asset', 'liability', 'equity', 'revenue', 'expense'];
        $topLevelByType = $all->whereNull('parent_id')->groupBy(fn (Account $a) => $a->type->value ?? $a->type);

        $groups = [];

        foreach ($typeOrder as $type) {
            if ($this->typeFilter && $this->typeFilter !== $type) {
                continue;
            }

            $rows = [];

            foreach ($topLevelByType->get($type, collect())->sortBy('code') as $topAccount) {
                $rows[] = ['account' => $topAccount, 'depth' => 0, 'matched' => in_array($topAccount->id, $matchedIds, true)];
                $rows = array_merge($rows, $buildRows($topAccount->id, 1));
            }

            if ($rows !== []) {
                $groups[] = ['type' => $type, 'rows' => $rows];
            }
        }

        return $groups;
    }

    public function render(): View
    {
        $parentAccounts = Account::whereNull('parent_id')
            ->orderBy('code')
            ->get();

        $layout = view()->exists('layouts.app')
        ? 'layouts.app'
        : 'components.layouts.app';

        return view('accounting::livewire.chart-of-accounts', [
            'accountGroups'  => $this->groupedAccounts(),
            'parentAccounts' => $parentAccounts,
        ])->layout($layout, ['title' => __('Chart of Accounts')]);
    }
}
