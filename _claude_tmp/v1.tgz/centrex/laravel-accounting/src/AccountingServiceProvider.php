<?php

declare(strict_types = 1);

namespace Centrex\Accounting;

use Centrex\Accounting\Commands\{AccountingDemoCommand, AccountingReportCommand};
use Centrex\Accounting\Events\{BillPosted, InvoicePosted, PaymentRecorded};
use Centrex\Accounting\Listeners\{NotifyAccountingTeam, SyncCustomerOutstanding, SyncVendorOutstanding};
use Centrex\Accounting\Livewire\{AccountingBalanceSnapshotCard, AccountingCurrentAssetsCard, AccountingDashboard, AccountingKpiCard, AccountingPayablesCard, AccountingReceivablesCard, BillDetails, BillTable, Bills, Budgets, ChartOfAccounts, CreditMemoDetails, CreditMemos, CustomerLedger, CustomerLedgerIndex, Customers, ExpenseDetails, ExpenseTable, Expenses, FinancialReports, GeneralLedger, InvoiceDetails, InvoiceTable, Invoices, JournalEntries, PeriodClose, Requisitions, VendorLedger, VendorLedgerIndex, Vendors};
use Centrex\Accounting\Models\{BillItem, ExpenseItem, InvoiceItem, JournalEntry, Payment};
use Centrex\Accounting\Observers\{BillItemObserver, ExpenseItemObserver, InvoiceItemObserver, JournalEntryObserver, PaymentObserver};
use Illuminate\Support\Facades\Blade;
use Illuminate\Support\Facades\{Event, Gate};
use Illuminate\Support\ServiceProvider;
use Livewire\Livewire;

class AccountingServiceProvider extends ServiceProvider
{
    /** Bootstrap the application services. */
    public function boot(): void
    {
        $this->registerViteDirective();

        // Resolve Model::factory() for this package's own models to its Database\Factories
        // namespace. Only applies to Centrex\Accounting\Models\* — anything else falls
        // back to Laravel's default App\Database\Factories guess, so host-app factories
        // keep working unaffected.
        \Illuminate\Database\Eloquent\Factories\Factory::guessFactoryNamesUsing(
            fn (string $modelName): string => str_starts_with($modelName, 'Centrex\\Accounting\\Models\\')
                ? 'Centrex\\Accounting\\Database\\Factories\\' . class_basename($modelName) . 'Factory'
                : 'Database\\Factories\\' . class_basename($modelName) . 'Factory',
        );

        // Register Livewire Components
        Livewire::component('accounting-dashboard', AccountingDashboard::class);
        Livewire::component('accounting-kpi-card', AccountingKpiCard::class);
        Livewire::component('accounting-receivables-card', AccountingReceivablesCard::class);
        Livewire::component('accounting-payables-card', AccountingPayablesCard::class);
        Livewire::component('accounting-balance-snapshot-card', AccountingBalanceSnapshotCard::class);
        Livewire::component('accounting-current-assets-card', AccountingCurrentAssetsCard::class);
        Livewire::component('chart-of-accounts', ChartOfAccounts::class);
        Livewire::component('financial-reports', FinancialReports::class);
        Livewire::component('journal-entries', JournalEntries::class);
        Livewire::component('accounting-invoices', Invoices::class);
        Livewire::component('accounting-invoice-table', InvoiceTable::class);
        Livewire::component('accounting-invoice-details', InvoiceDetails::class);
        Livewire::component('accounting-bills', Bills::class);
        Livewire::component('accounting-bill-table', BillTable::class);
        Livewire::component('accounting-bill-details', BillDetails::class);
        Livewire::component('accounting-credit-memos', CreditMemos::class);
        Livewire::component('accounting-credit-memo-details', CreditMemoDetails::class);
        Livewire::component('accounting-customers', Customers::class);
        Livewire::component('accounting-vendors', Vendors::class);
        Livewire::component('accounting-expenses', Expenses::class);
        Livewire::component('accounting-expense-table', ExpenseTable::class);
        Livewire::component('accounting-expense-details', ExpenseDetails::class);
        Livewire::component('accounting-general-ledger', GeneralLedger::class);
        Livewire::component('accounting-customer-ledger', CustomerLedger::class);
        Livewire::component('accounting-customer-ledger-index', CustomerLedgerIndex::class);
        Livewire::component('accounting-vendor-ledger', VendorLedger::class);
        Livewire::component('accounting-vendor-ledger-index', VendorLedgerIndex::class);
        Livewire::component('accounting-budgets', Budgets::class);
        Livewire::component('accounting-period-close', PeriodClose::class);
        Livewire::component('accounting-requisitions', Requisitions::class);

        // Register model observers
        JournalEntry::observe(JournalEntryObserver::class);
        Payment::observe(PaymentObserver::class);
        BillItem::observe(BillItemObserver::class);
        InvoiceItem::observe(InvoiceItemObserver::class);
        ExpenseItem::observe(ExpenseItemObserver::class);
        // Register event listeners
        Event::listen(InvoicePosted::class, [SyncCustomerOutstanding::class, 'handle']);
        Event::listen(BillPosted::class, [SyncVendorOutstanding::class, 'handle']);
        Event::listen(PaymentRecorded::class, [SyncCustomerOutstanding::class, 'handlePayment']);
        Event::listen(PaymentRecorded::class, [SyncVendorOutstanding::class, 'handlePayment']);
        Event::listen(PaymentRecorded::class, [NotifyAccountingTeam::class, 'handle']);

        // Register authorization gates.
        // Host application may override any gate by re-defining it after the provider boots.
        $this->registerGates();

        /*
         * Optional methods to load your package assets
         */
        // $this->loadTranslationsFrom(__DIR__.'/../resources/lang', 'accounting');
        $this->loadViewsFrom(__DIR__ . '/../resources/views', 'accounting');
        $this->loadMigrationsFrom(__DIR__ . '/../database/migrations');
        $this->loadRoutesFrom(__DIR__ . '/../routes/web.php');
        $this->loadRoutesFrom(__DIR__ . '/../routes/api.php');

        if ($this->app->runningInConsole()) {
            $this->publishes([
                __DIR__ . '/../config/config.php' => config_path('accounting.php'),
            ], 'laravel-accounting-config');

            // Publishing the views.
            $this->publishes([
                __DIR__ . '/../resources/views' => resource_path('views/vendor/accounting'),
            ], 'laravel-accounting-views');

            // Publishing assets.
            /*$this->publishes([
                __DIR__.'/../resources/assets' => public_path('vendor/accounting'),
            ], 'accounting-assets');*/

            // Publishing the translation files.
            /*$this->publishes([
                __DIR__.'/../resources/lang' => resource_path('lang/vendor/accounting'),
            ], 'accounting-lang');*/

            // Registering package commands.
            $this->commands([
                AccountingReportCommand::class,
                AccountingDemoCommand::class,
            ]);
        }
    }

    private function registerViteDirective(): void
    {
        Blade::directive('accountingVite', fn (): string => sprintf(
            '<?php echo \\Centrex\\TallUi\\Support\\PackageVite::render(%s, %s, %s); ?>',
            var_export(dirname(__DIR__), true),
            var_export('accounting.hot', true),
            var_export(['resources/js/app.js'], true),
        ));
    }

    /**
     * Register default authorization gates for accounting actions.
     *
     * Each gate falls back to the `accounting-admin` super-gate so host apps
     * can grant blanket access by defining that single gate, or override
     * individual abilities for fine-grained control.
     *
     * Default behaviour: denies everyone (safe default).
     * Override in AppServiceProvider after calling parent::boot().
     */
    protected function registerGates(): void
    {
        $abilities = [
            // Journal entries
            'accounting.journal.view',
            'accounting.journal.create',
            'accounting.journal.submit',
            'accounting.journal.post',
            'accounting.journal.void',

            // General ledger
            'accounting.ledger.view',

            // Invoices & bills
            'accounting.invoice.view',
            'accounting.invoice.create',
            'accounting.invoice.post',
            'accounting.invoice.payment',
            'accounting.bill.view',
            'accounting.bill.create',
            'accounting.bill.post',
            'accounting.bill.payment',

            // Credit memos
            'accounting.credit-memo.view',
            'accounting.credit-memo.create',
            'accounting.credit-memo.issue',
            'accounting.credit-memo.refund',

            // Reports (read-only)
            'accounting.reports.view',

            // Requisitions
            'accounting.requisitions.view',

            // Chart of accounts
            'accounting.accounts.view',
            'accounting.accounts.manage',

            // Customers & vendors
            'accounting.customers.view',
            'accounting.customers.manage',
            'accounting.vendors.view',
            'accounting.vendors.manage',

            // Fiscal year & budgets
            'accounting.fiscal-year.close',
            'accounting.budget.view',
            'accounting.budget.manage',
            'accounting.budget.approve',

            // Loans & owner's equity
            'accounting.loans.view',
            'accounting.loans.manage',
            'accounting.equity.view',
            'accounting.equity.manage',
            'accounting.owners.view',
            'accounting.owners.manage',

            // Fixed assets
            'accounting.fixed-assets.view',
            'accounting.fixed-assets.manage',

            // Expenses
            'accounting.expense.view',
            'accounting.expense.delete',

            // Tax rates
            'accounting.tax-rates.view',
            'accounting.tax-rates.manage',

            // Bank reconciliation
            'accounting.bank-reconciliation.view',
            'accounting.bank-reconciliation.create',
            'accounting.bank-reconciliation.reconcile',
        ];

        foreach ($abilities as $ability) {
            // Only define the gate if the host app has not already registered it
            if (!Gate::has($ability)) {
                Gate::define($ability, static function ($user): bool {
                    // Allow if the user passes the super-gate
                    if (Gate::has('accounting-admin') && Gate::forUser($user)->check('accounting-admin')) {
                        return true;
                    }

                    // Fall back to a config-driven role attribute check
                    $roleAttribute = config('accounting.admin_role_attribute', null);

                    if ($roleAttribute && method_exists($user, 'hasRole')) {
                        return $user->hasRole(config('accounting.admin_roles', []));
                    }

                    return false;
                });
            }
        }
    }

    /** Register the application services. */
    public function register(): void
    {
        $this->mergeConfigFrom(__DIR__ . '/../config/config.php', 'accounting');

        $this->app->singleton('accounting', fn (): Accounting => new Accounting());
    }
}
