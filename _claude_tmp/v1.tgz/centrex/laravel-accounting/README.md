# Laravel Accounting

[![Latest Version on Packagist](https://img.shields.io/packagist/v/centrex/laravel-accounting.svg?style=flat-square)](https://packagist.org/packages/centrex/laravel-accounting)
[![GitHub Tests Action Status](https://img.shields.io/github/actions/workflow/status/centrex/laravel-accounting/run-tests.yml?branch=main&label=tests&style=flat-square)](https://github.com/centrex/laravel-accounting/actions?query=workflow%3Arun-tests+branch%3Amain)
[![GitHub Code Style Action Status](https://img.shields.io/github/actions/workflow/status/centrex/laravel-accounting/fix-php-code-style-issues.yml?branch=main&label=code%20style&style=flat-square)](https://github.com/centrex/laravel-accounting/actions?query=workflow%3A"Fix+PHP+code+style+issues"+branch%3Amain)
[![Total Downloads](https://img.shields.io/packagist/dt/centrex/laravel-accounting?style=flat-square)](https://packagist.org/packages/centrex/laravel-accounting)

Full double-entry accounting system for Laravel. Includes a chart of accounts, journal entries with two-step approval workflow, invoices, bills, expenses, customer/vendor ledgers, managed tax rates with a sales tax liability report, bank reconciliation (statement import, matching, adjusting entries), financial reports (including A/R and A/P aging), month-end period closing with inventory reconciliation, fiscal year closing, budgets, QuickBooks Online two-way sync, and a Livewire UI with a complete REST API layer.

Developer architecture notes live in [docs/developer-architecture.md](docs/developer-architecture.md).

---

## Table of Contents

- [Installation](#installation)
- [Environment Variables](#environment-variables)
- [Core Concepts](#core-concepts)
- [Chart of Accounts](#chart-of-accounts)
- [Journal Entries — Two-Step Workflow](#journal-entries--two-step-workflow)
- [Invoices & Payments](#invoices--payments)
- [Bills & Vendor Payments](#bills--vendor-payments)
- [Invoice & Bill Charges / Discounts](#invoice--bill-charges--discounts)
- [Tax Rates & Sales Tax Liability](#tax-rates--sales-tax-liability)
- [Expenses](#expenses)
- [Requisitions](#requisitions)
- [Customer & Vendor Ledger](#customer--vendor-ledger)
- [General Ledger](#general-ledger)
- [Financial Reports](#financial-reports)
- [SBU (Cost Centre) Filtering](#sbu-cost-centre-filtering)
- [Budgets](#budgets)
- [Period Closing (Month-End)](#period-closing-month-end)
- [Fiscal Year Closing](#fiscal-year-closing)
- [Adjustments, Reconciliation & Closing](#adjustments-reconciliation--closing)
- [Bank Reconciliation](#bank-reconciliation)
- [Inventory Financing](#inventory-financing)
- [Organizational Loans & SBU-wise Tracking](#organizational-loans--sbu-wise-tracking)
- [Owner's Equity](#owners-equity)
- [Real-World Example — Trading Company Month-End Close](#real-world-example--trading-company-month-end-close)
- [Authorization Gates](#authorization-gates)
- [Web UI Routes](#web-ui-routes)
- [REST API](#rest-api)
- [Artisan Commands](#artisan-commands)
- [QuickBooks Online Integration](#quickbooks-online-integration)
- [Testing](#testing)

---

## Installation

```bash
composer require centrex/laravel-accounting
php artisan vendor:publish --tag="laravel-accounting-config"
php artisan migrate
```

Seed the standard chart of accounts (idempotent, safe to re-run):

```php
use Centrex\Accounting\Facades\Accounting;

Accounting::initializeChartOfAccounts();
```

Standard accounts created: Cash (1000), Bank (1100), Accounts Receivable (1200), Inventory (1300), Accounts Payable (2000), Sales Tax Payable (2300), Share Capital (3000), Retained Earnings (3100), Sales Revenue (4000), COGS (5000), and more.

Publish views for customisation:

```bash
php artisan vendor:publish --tag="laravel-accounting-views"
```

---

## Environment Variables

```env
ACCOUNTING_CURRENCY=BDT
ACCOUNTING_DB_CONNECTION=mysql          # optional separate DB connection for multi-tenancy
ACCOUNTING_TABLE_PREFIX=acct_
ACCOUNTING_FISCAL_START_MONTH=1         # 1 = January
ACCOUNTING_FISCAL_AUTO_CREATE=true      # auto-create fiscal periods
ACCOUNTING_ENFORCE_PERIOD_LOCK=true     # block posting to closed periods
ACCOUNTING_ROUNDING_TOLERANCE=0.005     # max debit/credit mismatch allowed
ACCOUNTING_ADMIN_ROLES=administrator,admin,superadmin
ACCOUNTING_ADMIN_ROLE_ATTRIBUTE=        # fallback role attribute name

# Pre-selected default accounts for the bank reconciliation adjusting-entry mini-form
# (any active account can still be picked — these just save a click)
ACCOUNTING_ACCOUNT_BANK_FEES_EXPENSE=6800
ACCOUNTING_ACCOUNT_INTEREST_INCOME=4900

# QuickBooks Online integration (optional)
QBO_CLIENT_ID=
QBO_CLIENT_SECRET=
QBO_REDIRECT_URI=https://yourapp.com/accounting/qbo/callback
QBO_ENVIRONMENT=sandbox                 # sandbox | production
QBO_REALM_ID=                           # QBO Company ID (filled after first OAuth connect)
QBO_WEBHOOK_VERIFIER_TOKEN=             # required only if using QBO webhooks
```

---

## Core Concepts

### Double-Entry Bookkeeping

Every `JournalEntry` has two or more lines. Debits must equal credits within the configured `rounding_tolerance` before an entry can be posted.

| Account Type | Normal Balance | Increases with | Decreases with |
| --- | --- | --- | --- |
| Asset | Debit | Debit | Credit |
| Liability | Credit | Credit | Debit |
| Equity | Credit | Credit | Debit |
| Revenue | Credit | Credit | Debit |
| Expense | Debit | Debit | Credit |

### Journal Entry Lifecycle

```
Draft ──► Submitted ──► Posted ──► Void
           (review)     (GL impact)
```

- **Draft** — being prepared, no GL impact
- **Submitted** — sent for approval, no GL impact
- **Posted** — hits the General Ledger, affects all reports
- **Void** — cancelled; a separate reversing entry must be used if previously posted

### WAC — Weighted Average Cost

Used for inventory valuation. Recalculated on every goods-in movement:

```
New WAC = (Current Stock Value + New Purchase Value)
          ────────────────────────────────────────────
                Current Qty + New Purchase Qty
```

**Example:**

| Event | Qty | Unit Cost | Total Value | WAC |
| --- | --- | --- | --- | --- |
| Opening | 100 | ৳ 50.00 | ৳ 5,000 | ৳ 50.00 |
| Purchase | +50 | ৳ 60.00 | +৳ 3,000 | **(5,000+3,000)÷150 = ৳ 53.33** |
| Sale | -80 | ৳ 53.33 | COGS = ৳ 4,266.67 | ৳ 53.33 |
| Balance | 70 | ৳ 53.33 | ৳ 3,733.33 | ৳ 53.33 |

WAC resets on each purchase. FIFO / LIFO batching is not used.

---

## Chart of Accounts

```php
use Centrex\Accounting\Models\Account;
use Centrex\Accounting\Enums\{AccountType, AccountSubtype};

// Create a custom account
$account = Account::create([
    'code'     => '1310',
    'name'     => 'Raw Materials Inventory',
    'type'     => 'asset',
    'subtype'  => 'current_asset',
    'currency' => 'BDT',
]);

// Create a child account (sub-account)
$sub = Account::create([
    'code'      => '1311',
    'name'      => 'Finished Goods Inventory',
    'type'      => 'asset',
    'subtype'   => 'current_asset',
    'parent_id' => $account->id,
]);

// Retrieve by code
$cash = Account::where('code', '1000')->first();

// Current balance of an account
$balance = $cash->getCurrentBalance(); // float
```

---

## Journal Entries — Two-Step Workflow

### Standard Flow (with approval)

```php
use Centrex\Accounting\Facades\Accounting;
use Centrex\Accounting\Models\JournalEntry;

// Step 1: Accountant creates a draft
$entry = Accounting::createJournalEntry([
    'date'        => '2026-04-30',
    'reference'   => 'RENT-APR-2026',
    'type'        => 'general',      // general | closing | adjustment
    'description' => 'April office rent payment',
    'currency'    => 'BDT',
    'lines' => [
        ['account_id' => $rentExpenseId, 'type' => 'debit',  'amount' => 75000],
        ['account_id' => $bankId,        'type' => 'credit', 'amount' => 75000],
    ],
]);
// $entry->status === JvStatus::DRAFT

// Step 2: Accountant submits for review
$entry->submit();
// $entry->status === JvStatus::SUBMITTED
// submitted_by / submitted_at are now recorded

// Step 3a: Reviewer approves → posted to GL
$entry->post();
// $entry->status === JvStatus::POSTED
// approved_by / approved_at are recorded

// Step 3b: Reviewer rejects → back to draft with a note
$entry->returnToDraft('Wrong expense account — use 5200 for admin costs');
// $entry->status === JvStatus::DRAFT
// $entry->reviewer_note is set
```

### Admin Bypass (post directly from draft)

```php
// Users with accounting.journal.post gate can skip the submit step
$entry = Accounting::createJournalEntry([...]);
$entry->post();  // Draft → Posted in one step
```

### Multi-Line Complex Entry

```php
// Record a purchase: goods received, tax input credit, and advance payment applied
$entry = Accounting::createJournalEntry([
    'date'        => '2026-04-15',
    'reference'   => 'PO-2026-047',
    'description' => 'Purchase of electronics — Samsung batch',
    'lines' => [
        // What we received
        ['account_id' => $inventoryId,    'type' => 'debit',  'amount' => 500000, 'description' => 'Electronics inventory'],
        ['account_id' => $vatInputId,     'type' => 'debit',  'amount' => 75000,  'description' => 'VAT input credit 15%'],
        // How we paid
        ['account_id' => $advanceToSupId, 'type' => 'credit', 'amount' => 100000, 'description' => 'Advance applied'],
        ['account_id' => $apId,           'type' => 'credit', 'amount' => 475000, 'description' => 'Balance payable to supplier'],
    ],
]);

$entry->submit();
$entry->post();
```

### Void and Reverse a Posted Entry

```php
// Void (marks as cancelled — does not reverse GL)
$entry->void();

// To reverse the GL effect, post a reversing entry manually
$reversal = Accounting::createJournalEntry([
    'date'        => today(),
    'reference'   => 'REV-' . $entry->entry_number,
    'type'        => 'adjustment',
    'description' => 'Reversal of ' . $entry->description,
    'lines' => $entry->lines->map(fn ($l) => [
        'account_id' => $l->account_id,
        'type'       => $l->type === 'debit' ? 'credit' : 'debit',
        'amount'     => $l->amount,
    ])->toArray(),
]);
$reversal->post();
```

---

## Invoices & Payments

### Create and Post an Invoice

```php
use Centrex\Accounting\Models\{Customer, Invoice, InvoiceItem};
use Centrex\Accounting\Facades\Accounting;

// Create customer
$customer = Customer::create([
    'code'          => 'CUST-001',
    'name'          => 'Rahman Brothers Ltd',
    'email'         => 'accounts@rahman.com',
    'phone'         => '+880 1711-000000',
    'credit_limit'  => 500000,
    'payment_terms' => 30,
    'currency'      => 'BDT',
]);

// Create invoice
$invoice = Invoice::create([
    'customer_id'     => $customer->id,
    'invoice_date'    => '2026-04-10',
    'due_date'        => '2026-05-10',
    'currency'        => 'BDT',
    'subtotal'        => 200000,
    'tax_amount'      => 30000,
    'discount_amount' => 10000,
    'total'           => 220000,
    'notes'           => 'Payment terms: Net 30. Cheque in favour of ABC Trading.',
]);

// Add line items
$invoice->items()->createMany([
    ['description' => 'Samsung TV 55"',  'quantity' => 10, 'unit_price' => 15000, 'total' => 150000],
    ['description' => 'Samsung Fridge',  'quantity' => 5,  'unit_price' => 10000, 'total' => 50000],
]);

// Post → creates JE: DR Accounts Receivable 1200 / CR Sales Revenue 4000 + CR Sales Tax 2300
$journalEntry = Accounting::postInvoice($invoice);
// Fires: InvoicePosted → SyncCustomerOutstanding
```

### Partial Payment, then Full Settlement

```php
// First payment — partial
Accounting::recordInvoicePayment($invoice, [
    'date'      => '2026-04-25',
    'amount'    => 100000,
    'method'    => 'bank_transfer',
    'reference' => 'TT-DHAKA-20260425',
]);
// $invoice->status → 'partially_settled'
// JE: DR Bank 1100 / CR AR 1200

// Second payment — settles the balance
Accounting::recordInvoicePayment($invoice, [
    'date'      => '2026-05-08',
    'amount'    => 120000,
    'method'    => 'cheque',
    'reference' => 'CHQ-00547',
]);
// $invoice->status → 'settled'
```

### Multi-Currency Invoice

```php
$invoice = Invoice::create([
    'customer_id'   => $exportCustomer->id,
    'invoice_date'  => today(),
    'due_date'      => today()->addDays(60),
    'currency'      => 'USD',
    'exchange_rate' => 110.50,      // 1 USD = 110.50 BDT (base currency)
    'subtotal'      => 5000,        // USD
    'total'         => 5000,
]);

// Post converts to BDT using exchange_rate
// JE posts 5000 × 110.50 = ৳ 552,500 to GL
Accounting::postInvoice($invoice);
```

---

## Bills & Vendor Payments

```php
use Centrex\Accounting\Models\{Vendor, Bill};

$vendor = Vendor::create([
    'code'          => 'VEND-001',
    'name'          => 'Global Electronics Ltd',
    'email'         => 'billing@globalelec.com',
    'payment_terms' => 45,
    'currency'      => 'BDT',
    'tax_id'        => 'BIN-123456789',
]);

$bill = Bill::create([
    'vendor_id'  => $vendor->id,
    'bill_date'  => '2026-04-05',
    'due_date'   => '2026-05-20',
    'subtotal'   => 400000,
    'tax_amount' => 60000,
    'total'      => 460000,
    'notes'      => 'Invoice #GEL-2026-0312',
]);

$bill->items()->createMany([
    ['description' => 'Samsung TV 55" — 30 units',  'quantity' => 30, 'unit_price' => 12000, 'total' => 360000],
    ['description' => 'Samsung Fridge — 8 units',   'quantity' => 8,  'unit_price' => 5000,  'total' => 40000],
]);

// Post → JE: DR Expense 5000 + DR VAT Input 1250 / CR Accounts Payable 2000
Accounting::postBill($bill);

// Pay vendor by bank transfer
Accounting::recordBillPayment($bill, [
    'date'      => '2026-05-15',
    'amount'    => 460000,
    'method'    => 'bank_transfer',
    'reference' => 'TT-OUT-20260515',
]);
// $bill->status → 'settled'
```

---

## Invoice & Bill Charges / Discounts

The invoice and bill detail pages support recording additional charges and price adjustments with full double-entry journal entries. All amounts are guarded by an AR/AP balance check so payments plus discounts can never exceed the effective receivable or payable balance.

### Invoice Expenses (Delivery / COD)

Records an additional company-borne expense against a posted invoice — e.g., a delivery fee, courier charge, or cash-on-delivery handling cost. Journal entry: DR Expense account / CR Cash (1000).

| Account | Code | Use |
| --- | --- | --- |
| Delivery Charge | 4210 | Standard courier / shipping charge |
| Cash on Delivery Charge | 4220 | COD handling fee |
| Courier Bill / Charge | 6310 | Courier fee |
| Shipping / Transfer Bill (Carriage) | 6320 | Freight / carriage |
| Hand Carry Delivery | 6330 | Hand-carried delivery |
| Delivery Return Charge | 6340 | Return shipment fee |

```php
use Centrex\Accounting\Models\{Account, Expense, Invoice};
use Centrex\Accounting\Facades\Accounting;

$invoice      = Invoice::find($id);
$cashAccount  = Account::where('code', '1000')->first();
$chargeAccount = Account::where('code', '4210')->first(); // or 4220

$expense = Expense::create([
    'chargeable_type' => Invoice::class,
    'chargeable_id'   => $invoice->id,
    'account_id'      => $chargeAccount->id,
    'expense_date'    => today(),
    'subtotal'        => 500,
    'total'           => 500,
    'paid_amount'     => 500,
    'currency'        => 'BDT',
    'status'          => 'paid',
    'payment_method'  => 'cash',
    'reference'       => $invoice->invoice_number,
]);

$entry = Accounting::createJournalEntry([
    'date'        => today(),
    'reference'   => $invoice->invoice_number,
    'type'        => 'general',
    'description' => 'Delivery expense — ' . $invoice->invoice_number,
    'currency'    => 'BDT',
    'lines' => [
        ['account_id' => $chargeAccount->id, 'type' => 'debit',  'amount' => 500, 'description' => 'Delivery Charge'],
        ['account_id' => $cashAccount->id,   'type' => 'credit', 'amount' => 500, 'description' => 'Cash payment for Delivery Charge'],
    ],
]);
$entry->post();
$expense->update(['journal_entry_id' => $entry->id]);
```

The UI equivalent is the **Record Charge** button on the invoice detail page (`/accounting/invoices/{id}`).

### Invoice Discounts (Sales Discount)

Records a price concession granted to the customer, reducing the AR balance. Journal entry: DR Sales Discount (6130) / CR Accounts Receivable (1200).

```php
$discountAccount = Account::where('code', '6130')->first();
$arAccount       = Account::where('code', '1200')->first();

$expense = Expense::create([
    'chargeable_type' => Invoice::class,
    'chargeable_id'   => $invoice->id,
    'account_id'      => $discountAccount->id,
    'expense_date'    => today(),
    'subtotal'        => 1000,
    'total'           => 1000,
    'paid_amount'     => 1000,
    'currency'        => 'BDT',
    'status'          => 'paid',
    'payment_method'  => 'cash',
    'reference'       => $invoice->invoice_number,
]);

$entry = Accounting::createJournalEntry([
    'date'        => today(),
    'reference'   => $invoice->invoice_number,
    'type'        => 'general',
    'description' => 'Sales Discount — ' . $invoice->invoice_number,
    'currency'    => 'BDT',
    'lines' => [
        ['account_id' => $discountAccount->id, 'type' => 'debit',  'amount' => 1000, 'description' => 'Sales Discount'],
        ['account_id' => $arAccount->id,       'type' => 'credit', 'amount' => 1000, 'description' => 'Discount applied to AR'],
    ],
]);
$entry->post();
$expense->update(['journal_entry_id' => $entry->id]);
```

AR balance guard — discount amount is validated not to exceed `effective_ar`. The same guard prevents over-payment.

```text
effective_ar = invoice->total − invoice->paid_amount − Σdiscounts(6130)
```

---

### Bill Charges (Freight / Shipping)

Records an additional vendor cost against a posted bill — e.g., a courier charge or carriage fee.

Journal entry: DR Expense account / CR Cash (1000).

| Account | Code | Use |
| --- | --- | --- |
| Courier Bill / Charge | 6310 | Standard courier fee |
| Shipping / Transfer Bill (Carriage) | 6320 | Freight / sea or land carriage |
| Hand Carry Delivery | 6330 | Hand-carried goods delivery |
| Delivery Return Charge | 6340 | Return shipment fee |

```php
use Centrex\Accounting\Models\{Account, Bill, Expense};

$bill          = Bill::find($id);
$cashAccount   = Account::where('code', '1000')->first();
$chargeAccount = Account::where('code', '6310')->first(); // or 6320, 6330, 6340

$expense = Expense::create([
    'chargeable_type' => Bill::class,
    'chargeable_id'   => $bill->id,
    'account_id'      => $chargeAccount->id,
    'expense_date'    => today(),
    'subtotal'        => 300,
    'total'           => 300,
    'paid_amount'     => 300,
    'currency'        => 'BDT',
    'status'          => 'paid',
    'payment_method'  => 'cash',
    'reference'       => $bill->bill_number,
]);

$entry = Accounting::createJournalEntry([
    'date'        => today(),
    'reference'   => $bill->bill_number,
    'type'        => 'general',
    'description' => 'Courier Charge — ' . $bill->bill_number,
    'currency'    => 'BDT',
    'lines' => [
        ['account_id' => $chargeAccount->id, 'type' => 'debit',  'amount' => 300, 'description' => 'Courier Charge'],
        ['account_id' => $cashAccount->id,   'type' => 'credit', 'amount' => 300, 'description' => 'Cash payment for Courier Charge'],
    ],
]);
$entry->post();
$expense->update(['journal_entry_id' => $entry->id]);
```

### Bill Discounts (Purchase Discount)

Records a price reduction granted by the vendor, reducing the AP balance. Journal entry: DR Accounts Payable (2000) / CR Purchase Discount (5500).

```php
$discountAccount = Account::where('code', '5500')->first();
$apAccount       = Account::where('code', '2000')->first();

$expense = Expense::create([
    'chargeable_type' => Bill::class,
    'chargeable_id'   => $bill->id,
    'account_id'      => $discountAccount->id,
    'expense_date'    => today(),
    'subtotal'        => 2000,
    'total'           => 2000,
    'paid_amount'     => 2000,
    'currency'        => 'BDT',
    'status'          => 'paid',
    'payment_method'  => 'cash',
    'reference'       => $bill->bill_number,
]);

$entry = Accounting::createJournalEntry([
    'date'        => today(),
    'reference'   => $bill->bill_number,
    'type'        => 'general',
    'description' => 'Purchase Discount — ' . $bill->bill_number,
    'currency'    => 'BDT',
    'lines' => [
        ['account_id' => $apAccount->id,       'type' => 'debit',  'amount' => 2000, 'description' => 'Discount applied to AP'],
        ['account_id' => $discountAccount->id, 'type' => 'credit', 'amount' => 2000, 'description' => 'Purchase Discount'],
    ],
]);
$entry->post();
$expense->update(['journal_entry_id' => $entry->id]);
```

AP balance guard — discount amount is validated not to exceed `effective_ap`.

```text
effective_ap = bill->total − bill->paid_amount − Σdiscounts(5500)
```

The UI equivalent is the **Record Charge** and **Record Discount** buttons on the bill detail page (`/accounting/bills/{id}`).

### Journal Flow at a Glance

| Event | DR | CR |
| --- | --- | --- |
| Invoice delivery/COD expense | Delivery/COD/Courier expense `4210` / `4220` / `6310–6340` | Cash `1000` |
| Invoice sales discount | Sales Discount `6130` | AR `1200` |
| Bill freight charge | Courier/Shipping `6310–6340` | Cash `1000` |
| Bill purchase discount | AP `2000` | Purchase Discount `5500` |

### Convenience Methods

Instead of building the `Expense` + `JournalEntry` manually, you can call the facade helpers which create both in one atomic transaction and auto-post the journal entry:

```php
use Centrex\Accounting\Facades\Accounting;
use Centrex\Accounting\Models\{Invoice, Bill};

// Record a delivery charge against an invoice (cash payment)
$expense = Accounting::recordInvoiceExpense($invoice, [
    'account_id'     => $chargeAccountId,  // e.g. Account::where('code','4210')->value('id')
    'amount'         => 500,
    'tax_amount'     => 0,
    'payment_method' => 'cash',            // 'cash' → CR Cash 1000; 'credit' → CR AP 2000
    'date'           => today(),
    'description'    => 'Delivery Charge',
    'reference'      => $invoice->invoice_number,
]);

// Record a freight charge against a bill (on credit / AP)
$expense = Accounting::recordBillExpense($bill, [
    'account_id'     => $freightAccountId, // e.g. Account::where('code','6320')->value('id')
    'amount'         => 300,
    'payment_method' => 'credit',
    'date'           => today(),
]);
```

Both methods return the persisted `Expense` model with `journal_entry_id` already set.

---

## Tax Rates & Sales Tax Liability

Invoice and bill line items have always had a per-line `tax_rate`/`tax_amount` pair, but historically that percentage was just typed in freehand. `TaxRate` turns it into a governed, reportable entity — a named rate (VAT, GST, a reduced rate, whatever your jurisdiction needs) that line items can select from a dropdown instead of retyping a number every time. **The free-typed percentage still works** — `tax_rate_id` is optional, so nothing breaks for existing data or ad-hoc one-off rates.

### Managing Tax Rates

```php
use Centrex\Accounting\Models\TaxRate;

$vat = TaxRate::create([
    'name'        => 'VAT Standard',
    'code'        => 'VAT',
    'rate'        => 15.00,
    'is_compound' => false,
    'is_active'   => true,
]);
```

Manage rates from the UI at `/accounting/tax-rates`, or via the REST API (see [Tax Rates](#tax-rates) below).

### Using a Tax Rate on a Line Item

Pass `tax_rate_id` when creating an `InvoiceItem`/`BillItem` — the current rate is **snapshotted** into the line's own `tax_rate`/`tax_amount` columns at save time, so a later edit to `TaxRate::rate` never retroactively changes an already-saved line:

```php
use Centrex\Accounting\Models\{Invoice, InvoiceItem};

$item = InvoiceItem::create([
    'invoice_id'  => $invoice->id,
    'description' => 'Samsung TV 55"',
    'quantity'    => 10,
    'unit_price'  => 15000,
    'tax_rate_id' => $vat->id,   // amount = 150000, tax_rate = 15.00, tax_amount = 22500 — computed automatically
]);

// Free-typed fallback still works exactly as before — just omit tax_rate_id:
InvoiceItem::create([
    'invoice_id'  => $invoice->id,
    'description' => 'One-off negotiated rate',
    'quantity'    => 1,
    'unit_price'  => 1000,
    'tax_rate'    => 7.5,        // tax_amount = 75.00
]);
```

The Invoices/Bills create screens expose this as a tax-rate dropdown per line with an "Other %" option that reveals the free-text field. `TaxRate::is_compound` is stored for reporting, but since the schema allows only one rate per line, it doesn't change the per-line math today — there's no second rate for it to compound on top of yet.

### Sales Tax Liability Report

Groups output tax (invoices) against input tax (bills) by rate over a period, with an "Unassigned / Ad-hoc" bucket for free-typed lines:

```php
use Centrex\Accounting\Facades\Accounting;

$report = Accounting::getSalesTaxLiabilityReport('2026-04-01', '2026-04-30');
// [
//   'rows' => [
//     ['tax_rate_id' => 1, 'name' => 'VAT Standard', 'code' => 'VAT', 'rate' => 15.00,
//      'collected' => 33750.00, 'paid' => 4500.00, 'net_payable' => 29250.00],
//     ['tax_rate_id' => null, 'name' => 'Unassigned / Ad-hoc', 'code' => null, 'rate' => null,
//      'collected' => 75.00, 'paid' => 0.00, 'net_payable' => 75.00],
//   ],
//   'total_collected'   => 33825.00,
//   'total_paid'        => 4500.00,
//   'total_net_payable' => 29325.00,
// ]
```

Available from the Financial Reports page (`sales_tax_liability` report type), the REST API, and:

```bash
php artisan accounting:report sales-tax-liability --start=2026-04-01 --end=2026-04-30
```

---

## Expenses

```php
use Centrex\Accounting\Models\Expense;

// Cash expense — paid immediately
$expense = Expense::create([
    'account_id'     => $officeSuppliesAccountId,
    'expense_date'   => today(),
    'subtotal'       => 12000,
    'tax_amount'     => 1800,
    'total'          => 13800,
    'payment_method' => 'cash',
    'vendor_name'    => 'Bashundhara City Shop',
    'notes'          => 'Printer cartridges and paper — Q2 office supplies',
]);

$expense->items()->createMany([
    ['description' => 'HP 67 Black Ink — 3 units',  'amount' => 6000],
    ['description' => 'A4 Paper — 10 reams',         'amount' => 6000],
]);

// Post → JE: DR Office Supplies 5400 / CR Cash 1000
Accounting::postExpense($expense);

// Credit expense — pay later
$creditExpense = Expense::create([
    'account_id'     => $marketingAccountId,
    'expense_date'   => today(),
    'due_date'       => today()->addDays(15),
    'total'          => 50000,
    'payment_method' => 'credit',  // creates AP entry
    'vendor_name'    => 'DigiAds Bangladesh',
]);

Accounting::postExpense($creditExpense);
// JE: DR Marketing Expense 5600 / CR Accounts Payable 2000

// Pay when due
Accounting::recordExpensePayment($creditExpense, [
    'date'   => today()->addDays(15),
    'amount' => 50000,
    'method' => 'bank_transfer',
]);
```

---

## Requisitions

A **requisition** is a pre-approval request to spend money, raised before a Bill or Expense is created. Two types exist:

- `purchase` — becomes a **Bill** once approved (goods/services from a vendor)
- `expense` — becomes a **Expense** once approved (internal cost on a GL account)

### Lifecycle

```text
Draft ──► Submitted ──► Approved ──► Converted
                  └──► Rejected ──► (closed)
```

### Create and Submit a Requisition

```php
use Centrex\Accounting\Facades\Accounting;

// Purchase requisition — routed to vendor as a bill
$req = Accounting::createRequisition([
    'type'           => 'purchase',
    'title'          => 'Q3 Office Supplies',
    'vendor_id'      => $vendor->id,
    'requested_by'   => auth()->id(),
    'requested_date' => today(),
    'required_date'  => today()->addDays(7),
    'currency'       => 'BDT',
    'notes'          => 'Urgent: needed before staff training on July 5',
    'items' => [
        ['description' => 'A4 Paper — 20 reams',       'quantity' => 20, 'unit_price' => 300],
        ['description' => 'Whiteboard Markers (set)',   'quantity' => 5,  'unit_price' => 250],
    ],
]);
// $req->status === RequisitionStatus::DRAFT

// Expense requisition — routed to GL account as an expense
$expReq = Accounting::createRequisition([
    'type'           => 'expense',
    'title'          => 'Team lunch — Q2 close',
    'account_id'     => $entertainmentAccountId,
    'requested_by'   => auth()->id(),
    'requested_date' => today(),
    'currency'       => 'BDT',
    'items' => [
        ['description' => 'Team lunch at La Bella', 'quantity' => 1, 'unit_price' => 8500],
    ],
]);

// Requester submits for manager approval
Accounting::submitRequisition($req);
// $req->status === RequisitionStatus::SUBMITTED
```

### Approve, Reject, or Convert

```php
// Manager approves
Accounting::approveRequisition($req, auth()->id());
// $req->status === RequisitionStatus::APPROVED

// Manager rejects (sends back with reason)
Accounting::rejectRequisition($req, 'Over budget — reduce to 10 reams of paper.', auth()->id());
// $req->status === RequisitionStatus::REJECTED

// Convert approved purchase requisition → Bill (items map 1-to-1)
$bill = Accounting::convertRequisitionToBill($req);
// $req->status → RequisitionStatus::CONVERTED
// $bill->status === 'draft' — ready to post via Accounting::postBill($bill)

// Convert approved expense requisition → Expense
$expense = Accounting::convertRequisitionToExpense($expReq);
// $expense->status === 'draft', payment_method = 'credit'
// Ready to post via Accounting::postExpense($expense)
```

### Enums

| Enum | Cases |
| --- | --- |
| `RequisitionStatus` | DRAFT, SUBMITTED, APPROVED, REJECTED, CONVERTED |
| `RequisitionType` | PURCHASE (`purchase`), EXPENSE (`expense`) |

---

## Customer & Vendor Ledger

### Per-Entity Ledger (Statement of Account)

```php
use Centrex\Accounting\Models\Customer;

// Navigate to the individual ledger page via web UI:
// GET /accounting/customers/{customer}/ledger?startDate=2026-01-01&endDate=2026-04-30

// Or query the data programmatically:
$customer = Customer::find($id);

// Outstanding balance attribute (active invoices only)
$outstanding = $customer->total_outstanding; // float — sum of (total - paid_amount) for issued/partial/overdue invoices
```

### Ledger Index (All Customers / Vendors)

```text
GET /accounting/ledger/customers   — paginated list with outstanding per customer
GET /accounting/ledger/vendors     — paginated list with outstanding per vendor
```

Each index row shows: total invoiced, total received, and net outstanding for active (issued/partial/overdue) documents only.

---

## General Ledger

```php
use Centrex\Accounting\Facades\Accounting;

// All accounts, full year
$gl = Accounting::getGeneralLedger(
    accountId: null,
    startDate: '2026-01-01',
    endDate:   '2026-04-30',
    sbuCode:   null,
);

// Single account with SBU filter
$gl = Accounting::getGeneralLedger(
    accountId: $bankAccountId,
    startDate: '2026-04-01',
    endDate:   '2026-04-30',
    sbuCode:   'OCT',           // Strategic Business Unit code
);

// Response structure
foreach ($gl['accounts'] as $section) {
    $section['account'];           // Account model
    $section['opening_balance'];   // float — balance before start date
    $section['period_debits'];     // float
    $section['period_credits'];    // float
    $section['closing_balance'];   // float
    $section['entries'];           // array of posted GL lines with running_balance
}
```

---

## Financial Reports

```php
use Centrex\Accounting\Facades\Accounting;

// Trial Balance — checks if all posted entries balance
$tb = Accounting::getTrialBalance('2026-01-01', '2026-04-30');
// [
//   'accounts'      => [['account' => ..., 'debit' => x, 'credit' => x, 'balance' => x], ...],
//   'total_debits'  => 1250000.00,
//   'total_credits' => 1250000.00,
//   'is_balanced'   => true,
// ]

// Balance Sheet — point-in-time snapshot
$bs = Accounting::getBalanceSheet('2026-04-30');
// [
//   'assets'      => ['accounts' => [...], 'total' => 8500000.00],
//   'liabilities' => ['accounts' => [...], 'total' => 2300000.00],
//   'equity'      => ['accounts' => [...], 'total' => 5870000.00, 'total_with_income' => 6200000.00],
//   'is_balanced' => true,
// ]

// Income Statement (P&L)
$pl = Accounting::getIncomeStatement('2026-04-01', '2026-04-30');
// [
//   'revenue'      => ['accounts' => [...], 'total' => 1500000.00],
//   'expenses'     => ['accounts' => [...], 'total' => 1170000.00],
//   'gross_profit' => 330000.00,
//   'net_income'   => 330000.00,
// ]

// Cash Flow Statement
$cf = Accounting::getCashFlowStatement('2026-04-01', '2026-04-30');
// [
//   'operating_activities'  => 280000.00,
//   'investing_activities'  => -50000.00,
//   'financing_activities'  => 0.00,
//   'net_change'            => 230000.00,
// ]

// A/R Aging — QBO-compatible buckets (current, 1-30, 31-60, 61-90, 91+)
$arAging = Accounting::getArAging('2026-04-30');
// [
//   'as_of_date' => '2026-04-30',
//   'rows' => [
//     ['name' => 'Acme Corp', 'current' => 5000.00, '1_30' => 1200.00, '31_60' => 0.00, '61_90' => 800.00, 'over_90' => 0.00, 'total' => 7000.00],
//   ],
//   'totals' => ['current' => 5000.00, '1_30' => 1200.00, '31_60' => 0.00, '61_90' => 800.00, 'over_90' => 0.00, 'total' => 7000.00],
// ]

// A/P Aging
$apAging = Accounting::getApAging('2026-04-30');

// Sales Tax Liability — output tax collected (invoices) vs input tax paid (bills), by rate
$taxLiability = Accounting::getSalesTaxLiabilityReport('2026-04-01', '2026-04-30');
// [
//   'rows' => [['tax_rate_id' => 1, 'name' => 'VAT Standard', 'code' => 'VAT', 'rate' => 15.00,
//               'collected' => 33750.00, 'paid' => 4500.00, 'net_payable' => 29250.00], ...],
//   'total_collected' => 33825.00, 'total_paid' => 4500.00, 'total_net_payable' => 29325.00,
// ]
```

See [Tax Rates & Sales Tax Liability](#tax-rates--sales-tax-liability) above for how line items get linked to a rate.

---

## SBU (Cost Centre) Filtering

All reports and the General Ledger accept a `sbuCode` parameter to filter by Strategic Business Unit. The SBU code is stored on each `JournalEntry` row.

```php
// Manual SBU tagging
$entry = Accounting::createJournalEntry([
    'date'        => today(),
    'description' => 'Dhaka branch rent',
    'sbu_code'    => 'DHK',
    'lines'       => [...],
]);

// Reports filtered by SBU
$pl  = Accounting::getIncomeStatement('2026-01-01', '2026-04-30', sbuCode: 'DHK');
$gl  = Accounting::getGeneralLedger(null, '2026-04-01', '2026-04-30', sbuCode: 'DHK');
$tb  = Accounting::getTrialBalance('2026-01-01', '2026-04-30', sbuCode: 'DHK');
$bs  = Accounting::getBalanceSheet('2026-04-30', sbuCode: 'DHK');
```

---

## Budgets

```php
use Centrex\Accounting\Facades\Accounting;
use Centrex\Accounting\Models\FiscalYear;

$fy = FiscalYear::where('is_current', true)->first();

$budget = Accounting::createBudget([
    'name'         => 'Q2 2026 Operating Budget',
    'fiscal_year_id' => $fy->id,
    'period_start' => '2026-04-01',
    'period_end'   => '2026-06-30',
    'currency'     => 'BDT',
    'items' => [
        ['account_id' => $rentExpenseId,     'description' => 'Office rent Q2',      'amount' => 225000],
        ['account_id' => $salariesId,         'description' => 'Staff salaries Q2',   'amount' => 900000],
        ['account_id' => $marketingId,        'description' => 'Digital marketing',   'amount' => 150000],
        ['account_id' => $officeSuppliesId,   'description' => 'Office supplies',     'amount' => 36000],
    ],
]);

// Approve the budget
Accounting::approveBudget($budget, auth()->id());

// Budget vs Actual comparison
$comparison = Accounting::getBudgetVsActual($budget);
foreach ($comparison['items'] as $item) {
    echo $item['account']->name . ': ';
    echo 'Budget ৳' . number_format($item['budgeted']) . ', ';
    echo 'Actual ৳' . number_format($item['actual'])   . ', ';
    echo 'Remaining ৳' . number_format($item['remaining']) . ' ';
    echo '(' . $item['percentage_used'] . '% used)' . PHP_EOL;
}
```

---

## Period Closing (Month-End)

### Pre-Close Checks

```php
use Centrex\Accounting\Facades\Accounting;
use Centrex\Accounting\Models\FiscalPeriod;

$period = FiscalPeriod::where('name', 'April 2026')->first();

$checks = Accounting::getPeriodCloseChecks($period);
// [
//   'unposted_journals' => 2,   // ← BLOCKER: must be 0 before closing
//   'open_invoices'     => 5,   // warning only (still editable after close)
//   'open_bills'        => 1,   // warning only
//   'has_blockers'      => true,
//   'has_warnings'      => true,
// ]

if ($checks['has_blockers']) {
    // Resolve the 2 unposted entries first
}
```

### Close the Period

```php
$result = Accounting::closeFiscalPeriod(
    period: $period,
    snapshotInventory: true,   // requires laravel-inventory with ERP bridge enabled
);

// $result['period']    — the now-closed FiscalPeriod model
// $result['inventory'] — inventory reconciliation data (or null)

if ($result['inventory']) {
    $inv = $result['inventory'];
    echo "Inventory snapshot: {$inv['snapshot_count']} lines captured\n";
    echo "Physical value:  ৳ " . number_format($inv['physical_value'], 2) . "\n";
    echo "GL balance (1300): ৳ " . number_format($inv['gl_balance'], 2) . "\n";
    echo "Variance:          ৳ " . number_format($inv['variance'], 2) . "\n";
    echo "Reconciled: " . ($inv['is_reconciled'] ? 'YES ✓' : 'NO — post an adjustment') . "\n";
}
```

After closing, the period is **locked**. Attempting to post a journal entry dated within a closed period throws `AccountingException`:

```php
// ACCOUNTING_ENFORCE_PERIOD_LOCK=true (default)
$entry->post();
// ✗ AccountingException: Cannot post to a closed period.
//   Entry date 2026-04-15 falls in a locked accounting period.

// Internal closing/adjusting entries bypass the lock automatically
// (closeFiscalYear() and closeFiscalPeriod() call post(bypassPeriodLock: true) internally)
```

To disable the lock temporarily for data migrations:

```env
ACCOUNTING_ENFORCE_PERIOD_LOCK=false
```

---

## Fiscal Year Closing

```php
use Centrex\Accounting\Models\FiscalYear;
use Centrex\Accounting\Facades\Accounting;

$fy = FiscalYear::where('name', '2025-26')->first();

Accounting::closeFiscalYear($fy);
// 1. Calculates net income for the year
// 2. Creates closing JE: DR Income Summary (3900) / CR Retained Earnings (3100)
// 3. Posts the entry (bypasses period lock)
// 4. Sets fiscal_year.is_closed = true
```

---

## Adjustments, Reconciliation & Closing

### Adjustment Journals

There's no separate "adjustment" API — an adjustment is just a normal journal entry with `'type' => 'adjustment'` (purely a label for filtering/reporting; the ledger effect is identical to `'general'`). Use it for accruals, depreciation, prepaid amortization, write-offs, and reclassifications:

```php
use Centrex\Accounting\Facades\Accounting;

$entry = Accounting::createJournalEntry([
    'date'        => today(),
    'reference'   => 'ADJ-' . now()->format('Ymd') . '-001',
    'type'        => 'adjustment',
    'description' => 'Accrual — electricity bill received but not yet invoiced',
    'lines' => [
        ['account_id' => $utilitiesExpenseId, 'type' => 'debit',  'amount' => 18000],
        ['account_id' => $accruedLiabilityId, 'type' => 'credit', 'amount' => 18000],
    ],
]);
$entry->submit();  // optional — post() works directly from draft too
$entry->post();
```

`createJournalEntry()` throws `UnbalancedJournalException` immediately if debits ≠ credits, so an adjustment can never be saved half-written. To undo a posted adjustment, don't edit it — void it and post a mirror-image reversal (see [Void and Reverse a Posted Entry](#void-and-reverse-a-posted-entry)).

### Cash Adjustments

A cash/petty-cash count that doesn't match the GL (`1000` Cash, `1050` Petty Cash) is posted as an adjustment against a dedicated variance account. The chart of accounts doesn't seed one by default — create it once:

```php
use Centrex\Accounting\Models\Account;
use Centrex\Accounting\Enums\{AccountType, AccountSubtype};

$cashOverShort = Account::firstOrCreate(['code' => '6900'], [
    'name'    => 'Cash Over/Short',
    'type'    => AccountType::EXPENSE,
    'subtype' => AccountSubtype::OTHER_EXPENSE,
]);
```

```php
$cash = Account::where('code', '1000')->first();

// Shortage — physical count is ৳500 less than the GL balance
$entry = Accounting::createJournalEntry([
    'date'        => today(),
    'reference'   => 'CASH-ADJ-' . today()->format('Ymd'),
    'type'        => 'adjustment',
    'description' => 'Cash count variance — shortage',
    'lines' => [
        ['account_id' => $cashOverShort->id, 'type' => 'debit',  'amount' => 500],
        ['account_id' => $cash->id,          'type' => 'credit', 'amount' => 500],
    ],
]);
$entry->post();

// Overage — physical count is ৳500 more than the GL balance (reverse the lines)
$entry = Accounting::createJournalEntry([
    'date'        => today(),
    'reference'   => 'CASH-ADJ-' . today()->format('Ymd'),
    'type'        => 'adjustment',
    'description' => 'Cash count variance — overage',
    'lines' => [
        ['account_id' => $cash->id,          'type' => 'debit',  'amount' => 500],
        ['account_id' => $cashOverShort->id, 'type' => 'credit', 'amount' => 500],
    ],
]);
$entry->post();
```

The same pattern applies to the Bank account (`1100`) for bank-side adjustments (fees, unmatched deposits) — see [Daily Cash / Bank Reconciliation](#daily-cash--bank-reconciliation) below for how the variance is usually discovered.

### Inventory Adjustments

**With `laravel-inventory` installed** (recommended — keeps stock quantities and GL in sync): use `Inventory::createAdjustment()` / `postAdjustment()`. Posting auto-generates the GL entry against `INVENTORY_ACCOUNTING_GAIN` (default `4900`) for a count increase or `INVENTORY_ACCOUNTING_LOSS` (default `5000`) for a decrease:

```php
use Centrex\Inventory\Facades\Inventory;

$adj = Inventory::createAdjustment([
    'warehouse_id' => $warehouseId,
    'reason'       => 'cycle_count',   // cycle_count | write_off | damage | theft | expiry | found_stock | other
    'adjusted_at'  => today(),
    'items' => [
        ['product_id' => 1, 'qty_actual' => 95, 'notes' => 'Counted 95, system had 100'],
    ],
]);
Inventory::postAdjustment($adj->id);
// Shortage: DR Inventory Loss (5000) / CR Inventory (1300)
// Surplus:  DR Inventory (1300) / CR Inventory Gain (4900)
```

**Without `laravel-inventory`** (accounting-only, e.g. physical stock count at period-end), post the same effect as a plain adjustment journal against the Inventory asset account:

```php
$inventoryShrinkageEntry = Accounting::createJournalEntry([
    'date'        => today(),
    'reference'   => 'SHRINK-' . today()->format('Ymd'),
    'type'        => 'adjustment',
    'description' => 'Inventory shrinkage — physical count variance',
    'lines' => [
        ['account_id' => $inventoryLossId,  'type' => 'debit',  'amount' => 37500],
        ['account_id' => $inventoryAssetId, 'type' => 'credit', 'amount' => 37500],
    ],
]);
$inventoryShrinkageEntry->post();
```

If `INVENTORY_ACCOUNTING_ENABLED=true`, prefer the `Inventory::` path — it also writes the underlying `StockMovement` row, so the physical count and the GL never drift apart. Reconciling the two independently (posting a manual JE while stock quantities are unchanged, or vice versa) is the single most common cause of a subsequent inventory variance at period close — see [Close the Period](#close-the-period) for the automated snapshot-vs-GL check.

### Daily Cash / Bank Reconciliation

Pull the day's posted GL activity for the Cash/Bank account and tie it to the physical count / bank statement:

```php
use Centrex\Accounting\Facades\Accounting;
use Centrex\Accounting\Models\Account;

$bank = Account::where('code', '1100')->first();
$today = today()->toDateString();

$gl = Accounting::getGeneralLedger($bank->id, $today, $today);
$section = $gl['accounts'][0] ?? null;

if ($section) {
    echo "Opening: " . number_format($section['opening_balance'], 2) . "\n";

    foreach ($section['entries'] as $line) {
        echo "{$line['entry_number']}  {$line['line_description']}  DR {$line['debit']}  CR {$line['credit']}  → {$line['running_balance']}\n";
    }

    echo "System closing balance: " . number_format($section['closing_balance'], 2) . "\n";
    // Compare against the bank's own statement / the physical cash count.
    // Any variance → post a Cash Adjustment (see above) dated today.
}
```

Run this as a scheduled report (or a quick Artisan/Tinker check) at end-of-day for every cash-handling location and the operating bank account — catching a variance same-day is far cheaper than tracing it back weeks later. This is a same-day sanity check, not a substitute for formally reconciling the month — see [Bank Reconciliation](#bank-reconciliation) below for matching against an actual imported statement.

### Monthly Reconciliation

Monthly reconciliation is the broader version of the daily check, run as part of the pre-close routine (see the [Week 4 Pre-Close Workflow](#week-4-pre-close-workflow-days-2730) for a full worked example):

```php
use Centrex\Accounting\Models\FiscalPeriod;

$period = FiscalPeriod::where('name', 'April 2026')->first();

// 1. Trial balance must balance before you even start reconciling
$tb = Accounting::getTrialBalance($period->start_date, $period->end_date);
abort_unless($tb['is_balanced'], 500, 'Trial balance out of balance — resolve before reconciling.');

// 2. Tie Bank (1100) to the bank statement — prefer the automated Bank Reconciliation
//    workflow below (matches every statement line, resolves unmatched ones via an
//    adjusting entry, and enforces the balance check before you can complete it):
$bank = Account::where('code', '1100')->first();
$recon = Accounting::createBankReconciliation([
    'account_id'               => $bank->id,
    'statement_date'           => $period->end_date,
    'opening_balance'          => $bank->getCurrentBalance(),
    'statement_ending_balance' => 5_432_100.00, // from the bank's statement
]);
// ...import statement lines, match, resolve, then Accounting::completeBankReconciliation($recon)
// — see Bank Reconciliation below for the full workflow. Or, for a quick manual pull:
$gl = Accounting::getGeneralLedger($bank->id, $period->start_date, $period->end_date);
$bankClosing = $gl['accounts'][0]['closing_balance'] ?? 0.0;
// Compare $bankClosing to the statement; post a Cash Adjustment for any residual (bank fees,
// unmatched deposits in transit, etc.) before closing the period.

// 3. Tie AR / AP subledgers to their control accounts
$arAging = Accounting::getArAging($period->end_date);
$apAging = Accounting::getApAging($period->end_date);
$ar = Account::where('code', '1200')->first()->getCurrentBalance();
$ap = Account::where('code', '2000')->first()->getCurrentBalance();
// $arAging['totals']['total'] should equal $ar; $apAging['totals']['total'] should equal $ap.
// A mismatch usually means an invoice/bill was posted with the wrong account code.

// 4. Inventory ties into physical count automatically when you close with a snapshot —
//    see closeFiscalPeriod(snapshotInventory: true) below.
```

### Monthly Closing

Monthly closing is the [Period Closing (Month-End)](#period-closing-month-end) workflow: run `getPeriodCloseChecks()`, resolve any blockers, then call `closeFiscalPeriod()`. It **locks the period** and (optionally) snapshots inventory — it does **not** post any journal entry of its own; it only freezes what's already posted:

```php
$checks = Accounting::getPeriodCloseChecks($period);
if (!$checks['has_blockers']) {
    Accounting::closeFiscalPeriod($period, snapshotInventory: true);
}
```

### Closing Journal (Year-End)

The **closing journal** — the entry that actually zeroes revenue/expense into equity — is only created once a year, by [Fiscal Year Closing](#fiscal-year-closing):

```php
Accounting::closeFiscalYear($fy);
// DR Income Summary (3900)   ← revenue − expenses for the year
// CR Retained Earnings (3100)
```

Monthly period closes never touch `3900`/`3100` — they just lock the period so nothing more can post into it. Revenue and expense account balances keep accumulating across every open month within the fiscal year until `closeFiscalYear()` runs; that's why `getBalanceSheet()` computes `equity.retained_earnings` as prior Retained Earnings **plus** cumulative net income to date, rather than reading `3100` alone.

### Solving Balance Sheet Discrepancies

Because `Accounting::createJournalEntry()` throws `UnbalancedJournalException` before an unbalanced entry can even be saved, `getBalanceSheet()['is_balanced']` being `false` is almost never "an entry doesn't balance." Work through these in order:

```php
use Centrex\Accounting\Models\{Account, JournalEntry};

// 1. Confirm the trial balance itself balances first
$tb = Accounting::getTrialBalance();
if (!$tb['is_balanced']) {
    // Only possible if a JournalEntry row was written outside the facade
    // (direct ::create() bypasses the balance check). Find the culprit:
    $unbalanced = JournalEntry::where('status', 'posted')
        ->with('lines')
        ->get()
        ->reject(fn (JournalEntry $e) => $e->isBalanced());
}

// 2. Inactive accounts still carrying a posted balance.
//    getBalanceSheet()/getTrialBalance()/getGeneralLedger() only look at
//    is_active = true accounts, but getCurrentBalance() does not filter on
//    is_active — so a deactivated account with historical postings becomes
//    invisible to every report while its balance is still real.
$orphaned = Account::where('is_active', false)->get()
    ->map(fn (Account $a) => ['code' => $a->code, 'name' => $a->name, 'balance' => $a->getCurrentBalance()])
    ->filter(fn (array $row) => abs($row['balance']) > 0.01);
// Reactivate the account, or move its balance out with an adjustment JE, then reconcile.

// 3. Wrong account `type` — the most common real cause. Assets/Expenses are
//    debit-normal; Liabilities/Equity/Revenue are credit-normal (Account::isDebitAccount()).
//    An account filed under the wrong `type` lands in the wrong Balance Sheet
//    bucket even though total debits still equal total credits globally.
Account::where('is_active', true)->get()->each(function (Account $a) {
    // Spot-check: does the account's type match how it's actually used?
    // e.g. a "Loan Payable" account accidentally created with type: asset
});

// 4. A posted entry was voided after the fact (e.g. after it had already been
//    reconciled against a bank statement or shipped inventory). void() removes
//    the entry from every report immediately — it does not create a reversing
//    entry, so any downstream process that already relied on it is now stale.
$recentlyVoided = JournalEntry::where('status', 'void')
    ->where('updated_at', '>=', now()->subDays(7))
    ->get();

// 5. Rounding tolerance drift — many small entries can each pass individually
//    (ACCOUNTING_ROUNDING_TOLERANCE, default 0.005) but sum to a visible variance.
//    Tighten it temporarily to surface exactly where the drift accumulates:
config(['accounting.rounding_tolerance' => 0.0001]);
$tb = Accounting::getTrialBalance();
```

If none of the above turn anything up, drill into the specific account with `getGeneralLedger($accountId, ...)` and walk the `entries` array line by line — the discrepancy is always traceable to one posted (or missing) entry.

---

## Bank Reconciliation

Matches the GL activity on a bank/cash account against an actual bank statement — one `BankReconciliation` session per statement period, with `BankStatementLine` rows imported from the statement and matched against `JournalEntryLine`s one at a time. Unmatched lines (bank fees, interest earned) get resolved with an adjusting entry created directly from the reconciliation, and the session can't be completed until every statement line is accounted for and the running balance ties to the statement's ending balance within `ACCOUNTING_ROUNDING_TOLERANCE`.

### Start a Reconciliation

```php
use Centrex\Accounting\Facades\Accounting;
use Centrex\Accounting\Models\Account;

$bank = Account::where('code', '1100')->first();

$reconciliation = Accounting::createBankReconciliation([
    'account_id'               => $bank->id,
    'statement_date'           => '2026-04-30',
    'opening_balance'          => 1_200_000.00,
    'statement_ending_balance' => 1_487_650.00,
]);
```

### Import Statement Lines

The facade takes plain, already-parsed rows — the Livewire workspace parses a pasted CSV (`date,description,amount,type,reference`) before calling this, so any source (a bank's export, a manual entry form) can feed it the same shape:

```php
Accounting::importBankStatementLines($reconciliation, [
    ['transaction_date' => '2026-04-02', 'description' => 'Customer wire — Rahman Brothers', 'amount' => 220000.00, 'type' => 'debit'],
    ['transaction_date' => '2026-04-15', 'description' => 'Monthly service charge',           'amount' => 250.00,    'type' => 'credit'],
]);
```

### Match Statement Lines to GL Lines

```php
use Centrex\Accounting\Models\JournalEntryLine;

$unreconciled = Accounting::getUnreconciledLines($bank->id);   // posted GL lines not yet tied to a statement
$statementLine = $reconciliation->statementLines()->first();
$glLine = $unreconciled->first();

Accounting::matchStatementLine($statementLine, $glLine);
// Validates: neither side already matched, amounts agree within tolerance, and the
// debit/credit polarity matches exactly (a statement debit pairs with a GL debit line).

// Made a mistake? Unmatch while the reconciliation is still draft:
Accounting::unmatchStatementLine($statementLine);
```

### Resolve Unmatched Lines with an Adjusting Entry

For statement activity with no corresponding GL line yet — bank fees, interest earned — post one directly from the reconciliation. It creates a balanced two-line journal entry (the bank leg + an offset expense/revenue account) and matches the bank leg to the statement line in the same transaction:

```php
use Centrex\Accounting\Models\Account;

$bankFees = Account::where('code', config('accounting.accounts.bank_fees_expense', '6800'))->first();

$entry = Accounting::createAdjustingJournalEntryForStatementLine($statementLine, [
    'offset_account_id' => $bankFees->id,
    'description'       => 'Monthly service charge',
]);
// DR/CR the bank account (matching the statement line's type) / CR/DR the offset account
```

### Complete the Reconciliation

```php
Accounting::completeBankReconciliation($reconciliation);
// Throws if any statement line is still unmatched, or if
// opening_balance + reconciled debits − reconciled credits ≠ statement_ending_balance
// (within tolerance) — throws ReconciliationBalanceMismatchException with the variance.
// On success: status → completed, reconciled_by/reconciled_at stamped.
```

Once completed, matched lines can no longer be unmatched — `unmatchStatementLine()` refuses to touch a line belonging to a completed reconciliation. (Voiding the underlying `JournalEntry` after completion is not separately blocked — treat a completed reconciliation's entries as final.)

Manage all of this from the UI at `/accounting/bank-reconciliations` — a two-column workspace (unreconciled GL lines vs. imported statement lines) with CSV paste-import, one-click matching, and the adjusting-entry mini-form built in.

---

## Inventory Financing

Inventory financing is a revolving short-term credit facility where a lender advances funds specifically to purchase stock. The inventory itself serves as collateral. Each lender is registered as a **facility** and receives its own pair of dedicated GL sub-accounts, keeping balances fully isolated per lender.

### Account Structure

`initializeChartOfAccounts()` seeds these parent accounts automatically:

| Code | Name | Type | Notes |
| --- | --- | --- | --- |
| `2150` | Inventory Financing Payable | Liability | Parent — never posted to directly |
| `2151–2169` | Per-lender payable | Liability | Auto-created on `addFinancingFacility()` |
| `2170` | Accrued Interest — Inventory Financing | Liability | Parent — never posted to directly |
| `2171–2189` | Per-lender accrued interest | Liability | Auto-created on `addFinancingFacility()` |
| `6710` | Interest Expense — Inventory Financing | Expense | Child of `6700 Interest Expense` |

### Register Lenders

Each call to `addFinancingFacility()` creates the facility record and allocates the next available sub-account codes under `2150` and `2170`:

```php
use Centrex\Accounting\Facades\Accounting;

// Lender 1 — bank (gets 2151 + 2171)
$brac = Accounting::addFinancingFacility(
    lenderName:  'BRAC Bank Ltd',
    lenderType:  'bank',
    monthlyRate: 0.02,          // 2% per month
    creditLimit: 5_000_000.00,  // ৳50 lakh ceiling
    contact:     'Md. Hasan, 01700-000001',
);

// Lender 2 — private party (gets 2152 + 2172)
$karim = Accounting::addFinancingFacility(
    lenderName:  'Mr. Abdul Karim',
    lenderType:  'private',
    monthlyRate: 0.02,
    creditLimit: 1_500_000.00,
);

// Lender 3 — microfinance institution (gets 2153 + 2173)
$buro = Accounting::addFinancingFacility(
    lenderName:  'BURO Bangladesh',
    lenderType:  'mfi',
    monthlyRate: 0.02,
    creditLimit: 800_000.00,
);
```

### Draw Down Funds to Purchase Inventory

Each draw-down posts immediately as a draft journal entry. Submit and approve via the normal two-step workflow:

```php
// BRAC Bank advances ৳20,00,000 for Samsung batch purchase
$entry = Accounting::drawdownFinancing(
    facility:    $brac,
    amount:      2_000_000.00,
    date:        '2026-04-05',
    reference:   'BRAC-DD-2026-001',
    description: 'Samsung Galaxy A-series batch — PO-2026-047',
);
$entry->submit();    // accountant submits for review
$entry->post();      // finance manager approves
// DR Inventory 1300  ৳20,00,000
// CR BRAC Bank Payable 2151  ৳20,00,000

// Private party advances ৳8,00,000 for accessories stock
$entry2 = Accounting::drawdownFinancing(
    facility:  $karim,
    amount:    800_000.00,
    date:      '2026-04-10',
    reference: 'KARIM-DD-2026-001',
);
$entry2->submit();
$entry2->post();
// DR Inventory 1300  ৳8,00,000
// CR Mr. Abdul Karim Payable 2152  ৳8,00,000
```

A second draw-down from the same lender stacks on top:

```php
// Mid-month top-up from BRAC Bank
Accounting::drawdownFinancing($brac, 500_000.00, '2026-04-18', 'BRAC-DD-2026-002')
    ->submit();
// Outstanding under BRAC: 2151 balance = ৳25,00,000
// Attempting to exceed credit limit throws RuntimeException
```

### Month-End Interest Accrual

Run once at month-end for all active facilities in a single call, or accrue per-facility for fine-grained control:

```php
// Accrue all active facilities at once (run via scheduler on the 28th)
$results = Accounting::accrueAllFinancingInterest(date: '2026-04-30');
// Returns: [facility_id => JournalEntry|null]

// Per-facility breakdown:
// BRAC Bank — principal ৳25,00,000 × 2% = ৳50,000
//   DR Interest Expense — Inv. Financing 6710  ৳50,000
//   CR Accrued Interest — BRAC Bank 2171       ৳50,000

// Mr. Karim — principal ৳8,00,000 × 2% = ৳16,000
//   DR Interest Expense — Inv. Financing 6710  ৳16,000
//   CR Accrued Interest — Mr. Abdul Karim 2172 ৳16,000

// Accrue a single facility manually (for corrections/adjustments)
$je = Accounting::accrueFinancingInterest($brac, date: '2026-04-30');
// Returns null and skips cleanly if outstanding principal is zero
```

Automate via the scheduler so it never gets missed:

```php
// routes/console.php
Schedule::call(fn () => Accounting::accrueAllFinancingInterest())
    ->monthlyOn(28, '23:00')
    ->name('accounting:accrue-inventory-interest')
    ->withoutOverlapping();
```

### Pay the Interest

```php
// Pay BRAC Bank interest for April
Accounting::payFinancingInterest(
    facility:  $brac,
    amount:    50_000.00,
    date:      '2026-05-05',
    reference: 'BRAC-INT-APR-2026',
);
// DR Accrued Interest — BRAC Bank 2171  ৳50,000
// CR Bank Account 1100                  ৳50,000

// Pay private party interest
Accounting::payFinancingInterest($karim, 16_000.00, '2026-05-05', 'KARIM-INT-APR-2026');
```

### Repay Principal as Inventory Sells

Repay each lender as the financed goods are sold and cash comes in. The method validates the amount does not exceed outstanding principal:

```php
// ৳10,00,000 of Samsung stock sold — repay BRAC proportionally
Accounting::repayFinancing(
    facility:  $brac,
    amount:    1_000_000.00,
    date:      '2026-05-10',
    reference: 'BRAC-REPAY-2026-001',
);
// DR BRAC Bank Payable 2151  ৳10,00,000
// CR Bank Account 1100       ৳10,00,000
// Remaining BRAC balance: 2151 = ৳15,00,000

// Full repayment of private party facility
Accounting::repayFinancing($karim, 800_000.00, '2026-05-15', 'KARIM-REPAY-2026-001');
// 2152 balance = ৳0 — facility fully settled
```

### Portfolio Summary

```php
$summary = Accounting::getFinancingSummary();

// Returns per-facility:
// [
//   'lender_name'           => 'BRAC Bank Ltd',
//   'lender_type'           => 'bank',
//   'is_active'             => true,
//   'monthly_rate'          => 0.02,
//   'credit_limit'          => 5000000.0,
//   'outstanding_principal' => 1500000.0,   // ৳15,00,000 remaining
//   'accrued_interest'      => 0.0,         // paid already
//   'monthly_interest'      => 30000.0,     // next month estimate
//   'principal_account'     => '2151 Inv. Financing Payable — BRAC Bank Ltd',
//   'interest_account'      => '2171 Accrued Interest — BRAC Bank Ltd',
// ],
// [
//   'lender_name'           => 'Mr. Abdul Karim',
//   'outstanding_principal' => 0.0,         // fully repaid
//   'monthly_interest'      => 0.0,
//   ...
// ],
```

### Pre-Close Check Integration

The period-close wizard automatically flags financing imbalances before locking the period:

```php
$checks = Accounting::getPeriodCloseChecks($period);

// Example blocker if financing > inventory value:
// [
//   'type'    => 'blocker',
//   'message' => 'Inventory financing (৳28,00,000) exceeds inventory GL balance (৳24,50,000).
//                 Possible unrecorded goods receipt or over-draw.',
// ]
```

### Journal Flow at a Glance

| Event | DR | CR |
| --- | --- | --- |
| Draw down (buy inventory) | Inventory `1300` | Lender Payable `215x` |
| Month-end interest accrual | Interest Expense `6710` | Accrued Interest `217x` |
| Pay interest | Accrued Interest `217x` | Bank `1100` |
| Repay principal | Lender Payable `215x` | Bank `1100` |

---

## Organizational Loans & SBU-wise Tracking

Covers every loan a company takes from an external lender or an internal entity — term loans, working-capital lines, inter-company advances, director loans, equipment finance, and overdraft facilities. Each loan is a **facility** with its own GL sub-accounts. The `sbu_code` field on the facility tags every journal entry automatically, so SBU-filtered P&L and balance sheets work without any extra steps.

A facility can be denominated in its own `currency` — a foreign lender's USD line, say — with `exchange_rate` converting every drawdown, interest accrual, payment, and repayment to the accounting base currency for GL posting. Interest is calculated on the outstanding principal in the facility's own currency, since that's what the lender actually charges. Omit `currency`/`exchangeRate` and a facility behaves exactly as before (base currency, 1:1).

> Full reference (account-code ranges, all facade methods, journal flow table): [docs/loans.md](docs/loans.md).

### Loan Types

| `loan_type` | Typical use |
| --- | --- |
| `term_loan` | Fixed-amount, fixed-tenure bank loan |
| `working_capital` | Short-term revolving credit for operations |
| `inter_company` | Advance from / to a sister or parent company |
| `director` | Unsecured loan from a director / shareholder |
| `equipment` | Asset-backed financing for machinery or vehicles |
| `overdraft` | Bank overdraft against current account |
| `bridge` | Short-term bridge pending long-term funding |

### Account Structure

`initializeChartOfAccounts()` seeds these parent accounts automatically:

| Code | Name | Term | Notes |
| --- | --- | --- | --- |
| `2400` | Short-term Loans Payable | Short | Parent — never posted to directly |
| `2401–2419` | Per-facility payable | Short | Auto-created on `addLoanFacility()` |
| `2420` | Accrued Interest — Short-term Loans | Short | Parent |
| `2421–2439` | Per-facility accrued interest | Short | Auto-created |
| `2500` | Long-term Loans Payable | Long | Parent |
| `2501–2519` | Per-facility payable | Long | Auto-created |
| `2520` | Accrued Interest — Long-term Loans | Long | Parent |
| `2521–2539` | Per-facility accrued interest | Long | Auto-created |
| `6720` | Interest Expense — Short-term Loans | — | Child of `6700` |
| `6730` | Interest Expense — Long-term Loans | — | Child of `6700` |

The `loan_term` field drives which range is used: `short_term` (< 12 months) → `240x/242x`; `long_term` (≥ 12 months) → `250x/252x`.

---

### Register Loan Facilities

```php
use Centrex\Accounting\Facades\Accounting;

// 1. Short-term working-capital line from Dutch-Bangla Bank — North SBU
$wcLine = Accounting::addLoanFacility(
    lenderName:    'Dutch-Bangla Bank Ltd',
    loanType:      'working_capital',
    loanTerm:      'short_term',
    monthlyRate:   0.02,                // 2% per month
    sbuCode:       'NORTH',             // all JEs tagged NORTH
    loanAmount:    3_000_000.00,
    disbursedAt:   '2026-04-01',
    dueAt:         '2026-10-01',
    tenureMonths:  6,
    contact:       'Branch Manager, Gulshan',
);
// → creates 2401 "Working Capital Payable — Dutch-Bangla Bank Ltd"
// → creates 2421 "Accrued Interest — Dutch-Bangla Bank Ltd"

// 2. Long-term term loan from BRAC Bank — South SBU
$termLoan = Accounting::addLoanFacility(
    lenderName:   'BRAC Bank Ltd',
    loanType:     'term_loan',
    loanTerm:     'long_term',
    monthlyRate:  0.02,
    sbuCode:      'SOUTH',
    loanAmount:   10_000_000.00,
    disbursedAt:  '2026-01-01',
    dueAt:        '2028-12-31',
    tenureMonths: 36,
);
// → creates 2501 "Term Loan Payable — BRAC Bank Ltd"
// → creates 2521 "Accrued Interest — BRAC Bank Ltd"

// 3. Inter-company advance from parent — Head Office SBU
$icLoan = Accounting::addLoanFacility(
    lenderName:  'ABC Holdings Ltd (Parent)',
    loanType:    'inter_company',
    loanTerm:    'short_term',
    monthlyRate: 0.02,
    sbuCode:     'HO',
    loanAmount:  5_000_000.00,
);
// → creates 2402 / 2422

// 4. Director loan — no SBU (company-wide)
$directorLoan = Accounting::addLoanFacility(
    lenderName:  'Mr. Rahim (Director)',
    loanType:    'director',
    loanTerm:    'short_term',
    monthlyRate: 0.02,
    loanAmount:  1_000_000.00,
);
// → creates 2403 / 2423 — sbu_code = null, JEs carry no SBU tag

// 5. Foreign-currency term loan — USD facility from an offshore lender
$offshoreLoan = Accounting::addLoanFacility(
    lenderName:   'Standard Chartered (Offshore)',
    loanType:     'term_loan',
    loanTerm:     'long_term',
    monthlyRate:  0.01,                 // 1%/month, charged on the USD outstanding principal
    sbuCode:      'HO',
    loanAmount:   100_000.00,           // USD 100,000 sanctioned
    disbursedAt:  '2026-01-01',
    dueAt:        '2029-01-01',
    tenureMonths: 36,
    currency:     'USD',
    exchangeRate: 110.50,               // 1 USD = 110.50 BDT — converts every posting to base currency
);
// → creates 2502 / 2522 — all GL balances in BDT despite the facility being USD-denominated
```

---

### Drawdown — Receive Loan Proceeds

`amount` is always in the facility's own currency — `drawdownLoan()` converts it to base currency using the facility's `exchange_rate` before posting.

```php
// Dutch-Bangla working-capital: ৳30,00,000 received into bank
$entry = Accounting::drawdownLoan(
    facility:  $wcLine,
    amount:    3_000_000.00,
    date:      '2026-04-01',
    reference: 'DBBL-WC-2026-001',
);
$entry->submit();
$entry->post();
// DR Bank 1100               ৳30,00,000   [sbu_code = NORTH]
// CR Working Capital Payable 2401  ৳30,00,000

// BRAC term loan — first tranche ৳60,00,000
Accounting::drawdownLoan($termLoan, 6_000_000.00, '2026-04-01', 'BRAC-TL-2026-T1')
    ->submit();
// DR Bank 1100              ৳60,00,000   [sbu_code = SOUTH]
// CR Term Loan Payable 2501  ৳60,00,000

// Second tranche ৳40,00,000 a month later
Accounting::drawdownLoan($termLoan, 4_000_000.00, '2026-05-01', 'BRAC-TL-2026-T2')
    ->submit();
// Total outstanding on 2501: ৳1,00,00,000

// Inter-company advance — override SBU at draw-down level if needed
Accounting::drawdownLoan(
    facility: $icLoan,
    amount:   5_000_000.00,
    date:     '2026-04-10',
    reference: 'IC-ADV-2026-001',
    sbuCode:  'EAST',   // overrides facility-level 'HO' for this specific entry
);

// Offshore USD facility — amount is in USD, journal lines post in BDT
Accounting::drawdownLoan($offshoreLoan, 40_000.00, '2026-01-01', 'SCB-USD-2026-T1');
// DR Bank 1100  ৳44,20,000  (40,000 × 110.50)   [sbu_code = HO]
// CR Term Loan Payable 2502  ৳44,20,000
```

---

### Month-End Interest Accrual

Interest is calculated on the outstanding principal **in the facility's own currency** (`outstandingPrincipalLocal()` × `monthly_rate`), then converted to base currency for the journal entry — so a USD facility's interest is whatever the lender actually charges on the USD balance, not on its fluctuating BDT equivalent.

```php
// Accrue all active loan facilities in one call
$results = Accounting::accrueAllLoanInterest(date: '2026-04-30');

// Facility-by-facility breakdown:
// Dutch-Bangla WC: ৳30,00,000 × 2% = ৳60,000  [NORTH]
//   DR Interest Expense — Short-term 6720  ৳60,000
//   CR Accrued Interest — DBBL 2421         ৳60,000

// BRAC Term Loan: ৳60,00,000 × 2% = ৳1,20,000  [SOUTH]
//   DR Interest Expense — Long-term 6730    ৳1,20,000
//   CR Accrued Interest — BRAC 2521          ৳1,20,000

// Director loan: ৳10,00,000 × 2% = ৳20,000  [no SBU]
//   DR Interest Expense — Short-term 6720   ৳20,000
//   CR Accrued Interest — Mr. Rahim 2423     ৳20,000

foreach ($results as $facilityId => $je) {
    if ($je) {
        $je->submit();
        $je->post();
    }
}

// Accrue a single facility (e.g., missed in bulk run)
$je = Accounting::accrueLoanInterest($icLoan, date: '2026-04-30');

// Scheduler — run on the 28th of each month at 11 PM
Schedule::call(fn () => Accounting::accrueAllLoanInterest())
    ->monthlyOn(28, '23:00')
    ->name('accounting:accrue-loan-interest')
    ->withoutOverlapping();
```

---

### Pay Interest

```php
// Pay Dutch-Bangla interest for April
Accounting::payLoanInterest(
    facility:  $wcLine,
    amount:    60_000.00,
    date:      '2026-05-05',
    reference: 'DBBL-INT-APR26',
);
// DR Accrued Interest — DBBL 2421  ৳60,000   [sbu_code = NORTH]
// CR Bank 1100                      ৳60,000

// Pay BRAC interest
Accounting::payLoanInterest($termLoan, 120_000.00, '2026-05-05', 'BRAC-INT-APR26');
```

---

### Repay Principal

```php
// Monthly instalment on working-capital line: ৳5,00,000
Accounting::repayLoan(
    facility:  $wcLine,
    amount:    500_000.00,
    date:      '2026-05-01',
    reference: 'DBBL-REPAY-APR26',
);
// DR Working Capital Payable 2401  ৳5,00,000   [sbu_code = NORTH]
// CR Bank 1100                      ৳5,00,000

// Full director loan repayment
Accounting::repayLoan($directorLoan, 1_000_000.00, '2026-05-15', 'DIR-REPAY-2026');
// 2403 balance = ৳0 — facility fully settled
```

---

### SBU-wise Loan Portfolio

```php
// All facilities, all SBUs
$all = Accounting::getLoanSummary();

// Only NORTH SBU
$north = Accounting::getLoanSummary(sbuCode: 'NORTH');

// Returns per facility:
// [
//   'lender_name'                 => 'Dutch-Bangla Bank Ltd',
//   'loan_type'                   => 'working_capital',
//   'loan_term'                   => 'short_term',
//   'sbu_code'                    => 'NORTH',
//   'monthly_rate'                => 0.02,
//   'loan_amount'                 => 3000000.0,
//   'currency'                    => 'BDT',
//   'exchange_rate'               => 1.0,
//   'disbursed_at'                => '2026-04-01',
//   'due_at'                      => '2026-10-01',
//   'months_remaining'            => 5,
//   'outstanding_principal'       => 2500000.0,   // base currency (GL) — after one instalment
//   'outstanding_principal_local' => 2500000.0,   // facility's own currency
//   'accrued_interest'            => 0.0,         // base currency — paid
//   'accrued_interest_local'      => 0.0,         // facility's own currency
//   'monthly_interest'            => 50000.0,     // facility's own currency — next estimate on reduced balance
//   'principal_account'           => '2401 Working Capital Payable — Dutch-Bangla Bank Ltd',
//   'interest_account'            => '2421 Accrued Interest — Dutch-Bangla Bank Ltd',
// ]

// For $offshoreLoan (USD), 'outstanding_principal' is the BDT GL balance while
// 'outstanding_principal_local' is that balance ÷ exchange_rate — the actual USD still owed.
```

---

### SBU-Filtered Financial Reports

Because every drawdown, accrual, and repayment journal entry is tagged with `sbu_code`, the standard report methods filter correctly with no extra work:

```php
// NORTH SBU income statement — interest expense attributed correctly
$pl = Accounting::getIncomeStatement('2026-04-01', '2026-04-30', sbuCode: 'NORTH');
// expenses will include ৳60,000 interest on the Dutch-Bangla WC line

// SOUTH SBU balance sheet — term loan liability appears under long-term
$bs = Accounting::getBalanceSheet('2026-04-30', sbuCode: 'SOUTH');
// liabilities will include 2501 = ৳1,00,00,000 (both tranches)

// Head-office consolidated trial balance (no SBU filter)
$tb = Accounting::getTrialBalance('2026-04-01', '2026-04-30');
// Includes all SBUs — 2400-parent and 2500-parent roll up correctly
```

---

### Journal Flow at a Glance

| Event | DR | CR | SBU tag |
| --- | --- | --- | --- |
| Receive loan proceeds | Bank `1100` | Loan Payable `240x`/`250x` | Facility SBU |
| Month-end interest accrual | Interest Expense `6720`/`6730` | Accrued Interest `242x`/`252x` | Facility SBU |
| Pay interest | Accrued Interest `242x`/`252x` | Bank `1100` | Facility SBU |
| Repay principal | Loan Payable `240x`/`250x` | Bank `1100` | Facility SBU |

---

### Web UI

`/accounting/loans` (route: `accounting.loans`, gated by `accounting.loans.view` / `.manage`) lists every facility with its live outstanding principal and accrued interest, pulled straight from the GL. From there you can:

- **New Loan Facility** — registers a lender via `addLoanFacility()`; the monthly rate field takes a plain percentage (e.g. `1.5`) and is converted to the `0.015` fraction the facade expects. Currency (defaults to the accounting base currency) and Exchange Rate fields set the facility's own currency once, at creation.
- **Drawdown / Pay Interest / Repay** — each opens a small amount + date + reference form that calls the matching facade method (`drawdownLoan()`, `payLoanInterest()`, `repayLoan()`) and posts the resulting entry immediately. The amount field is labelled with the facility's currency (e.g. "Amount * (USD)") — it's always in that currency, converted to base currency automatically. The facility list shows outstanding principal / accrued interest in the facility's currency, with the base-currency equivalent underneath when it differs.
- **Accrue Interest** — one click, calls `accrueLoanInterest()` for that facility only and posts it; shows an info toast instead of erroring when there's no outstanding principal to accrue.
- **Mark Inactive / Reactivate** — toggles `is_active`; `drawdownLoan()` refuses further draws against an inactive facility.

Add it to your app's navigation via `Centrex\Accounting\Support\AccountingWorkspace::sidebarNavigation()`, which already includes it under a "Financing" section.

---

## Owner's Equity

Contributions and drawings can be tracked at two levels: **company-wide**, posted straight to the fixed `3000`/`3200` aggregate accounts, or **per-owner**, via `addOwner()` + `recordOwnerContribution()`/`recordOwnerDrawing()`, which auto-provisions a dedicated Capital and Drawings sub-account per owner (rolling up into the same aggregate balances on the Balance Sheet). Both levels support multi-currency contributions/drawings — a foreign owner can contribute in their own currency, converted to the accounting base currency for posting, the same mechanism as `Invoice`/`Bill`/`LoanFacility`.

> Full reference (account table, per-owner facade methods, currency handling, journal flow table): [docs/equity.md](docs/equity.md).

| Code | Name | Normal balance | Purpose |
| --- | --- | --- | --- |
| `3000` | Capital (parent) | Credit | Owner / shareholder contributions — aggregate |
| `3001–3099` | Per-owner Capital sub-account | Credit | Auto-created by `addOwner()` |
| `3100` | Retained Earnings | Credit | Auto-updated by `closeFiscalYear()` |
| `3200` | Owner Drawings (parent) | Debit (contra-equity) | Owner withdrawals — aggregate |
| `3201–3299` | Per-owner Drawings sub-account | Debit (contra-equity) | Auto-created by `addOwner()` |

Both parent account codes are configurable — `ACCOUNTING_ACCOUNT_CAPITAL` (default `3000`) and `ACCOUNTING_ACCOUNT_OWNER_DRAWINGS` (default `3200`) — and resolved via `config('accounting.accounts.capital')` / `config('accounting.accounts.owner_drawings')`.

### Register an Owner

```php
use Centrex\Accounting\Facades\Accounting;

$owner = Accounting::addOwner([
    'code'                 => 'OWN-001',
    'name'                 => 'Jane Rahman',
    'ownership_percentage' => 60.0,
]);
// → creates 3001 "Capital — Jane Rahman" and 3201 "Drawings — Jane Rahman"
```

### Record a Capital Contribution

```php
// Per owner — DR deposit account / CR that owner's own Capital sub-account
Accounting::recordOwnerContribution($owner, [
    'amount'               => 500_000.00,
    'date'                 => today(),
    'deposit_account_code' => '1100',
    'description'          => 'Capital injection — Q1 2026',
]);
// DR Bank 1100                  ৳5,00,000
// CR Capital — Jane Rahman 3001  ৳5,00,000

// A foreign owner contributing in their own currency — converted to base currency for posting
Accounting::recordOwnerContribution($owner, [
    'amount'        => 10_000.00,   // USD 10,000
    'currency'      => 'USD',
    'exchange_rate' => 110.50,      // 1 USD = 110.50 BDT
]);
// DR Bank 1100                  ৳11,05,000  (10,000 × 110.50)
// CR Capital — Jane Rahman 3001  ৳11,05,000

// Company-wide (no specific owner) — post directly to the aggregate account
use Centrex\Accounting\Models\Account;

$bank    = Account::where('code', '1100')->first();
$capital = Account::where('code', config('accounting.accounts.capital', '3000'))->first();

$entry = Accounting::createJournalEntry([
    'date'        => today(),
    'reference'   => 'CAP-001',
    'description' => 'Capital injection — founding shareholders',
    'currency'    => 'BDT',
    'lines' => [
        ['account_id' => $bank->id,    'type' => 'debit',  'amount' => 500_000.00],
        ['account_id' => $capital->id, 'type' => 'credit', 'amount' => 500_000.00],
    ],
]);
$entry->post();
```

### Record an Owner Drawing

```php
// Per owner — DR that owner's own Drawings sub-account / CR source account
Accounting::recordOwnerDrawing($owner, [
    'amount'              => 50_000.00,
    'date'                => today(),
    'source_account_code' => '1100',
]);
// DR Drawings — Jane Rahman 3201  ৳50,000
// CR Bank 1100                    ৳50,000

// Company-wide (no specific owner)
$drawings = Account::where('code', config('accounting.accounts.owner_drawings', '3200'))->first();
$bank     = Account::where('code', '1100')->first();

$entry = Accounting::createJournalEntry([
    'date'        => today(),
    'reference'   => 'DRAW-001',
    'description' => 'Owner withdrawal',
    'currency'    => 'BDT',
    'lines' => [
        ['account_id' => $drawings->id, 'type' => 'debit',  'amount' => 50_000.00],
        ['account_id' => $bank->id,     'type' => 'credit', 'amount' => 50_000.00],
    ],
]);
$entry->post();
```

### Per-Owner Equity Summary

```php
$summary = Accounting::getOwnerEquitySummary();
// Collection, per active owner: ['owner' => Owner, 'capital_balance', 'drawings_balance', 'net_equity']
```

Retained Earnings rolls up automatically — `Accounting::closeFiscalYear($fiscalYear)` transfers net income into `3100` via a closing journal entry; it is never posted to directly.

### Web UI

- **`/accounting/owners`** (route `accounting.owners`, gated by `accounting.owners.view` / `.manage`) — register and manage owners; creating one calls `addOwner()` and provisions its sub-accounts.
- **`/accounting/equity`** (route `accounting.equity`, gated by `accounting.equity.view` / `.manage`) shows live Capital / Owner Drawings / Retained Earnings balances as stat cards, a **By Owner** table, and a feed of posted equity journal lines. **Record Contribution** and **Record Drawing** open a modal with an Owner picker ("Company-wide" or a specific owner), Amount, Currency, Exchange Rate, date, and a cash/bank account picker restricted to active `10xx`/`11xx` accounts — same pattern as the invoice/bill payment modals.

---

## Real-World Example — Trading Company Month-End Close

**Scenario:** ABC Trading Ltd imports electronics from South Korea and sells in Bangladesh. The company carries two active inventory financing facilities — BRAC Bank (৳50 lakh limit, 2%/month) and a private party Mr. Karim (৳15 lakh limit, 2%/month). April 2026 had 80 purchase transactions, 140 sales orders, and 6 stock adjustments.

### Week 4 Pre-Close Workflow (Days 27–30)

#### Day 27–28: Cut-Off Procedures

Ensure all economic events before April 30 are captured:

```php
// 1. Every goods received note (GRN) for April must be posted
//    → JE: DR Inventory 1300 ৳ 4,218,500 / CR Accounts Payable 2000 ৳ 4,218,500

// 2. All April sale fulfillments posted
//    → JE: DR COGS 5000 ৳ 2,940,000 / CR Inventory 1300 ৳ 2,940,000

// 3. All customer invoices for April shipments issued
//    → JE: DR AR 1200 ৳ 5,100,000 / CR Sales Revenue 4000 ৳ 4,500,000
//                                   / CR VAT Payable 2300  ৳   600,000

// 4. All vendor bills for April purchases posted
//    → JE: DR Inventory 1300 ৳ 4,200,000 / DR VAT Input ৳ 630,000
//         / CR Accounts Payable 2000 ৳ 4,830,000

// 5. Bank receipts from customers posted
Accounting::recordInvoicePayment($invoice, [
    'date' => '2026-04-28', 'amount' => 2800000, 'method' => 'bank_transfer',
]);

// 6. Vendor payments posted
Accounting::recordBillPayment($bill, [
    'date' => '2026-04-28', 'amount' => 3200000, 'method' => 'bank_transfer',
]);
```

#### Day 29: Manual Adjusting Entries

```php
// Accrual: April electricity bill — received but not invoiced yet
$entry = Accounting::createJournalEntry([
    'date'        => '2026-04-30',
    'reference'   => 'ACCR-UTIL-APR26',
    'type'        => 'adjustment',
    'description' => 'Accrual — April utilities bill (estimated)',
    'lines' => [
        ['account_id' => $utilitiesExpenseId, 'type' => 'debit',  'amount' => 18000],
        ['account_id' => $accruedLiabId,      'type' => 'credit', 'amount' => 18000],
    ],
]);
$entry->submit();
$entry->post(); // Approved by Finance Manager

// Depreciation: Monthly depreciation for equipment
$depEntry = Accounting::createJournalEntry([
    'date'        => '2026-04-30',
    'reference'   => 'DEP-APR26',
    'type'        => 'adjustment',
    'description' => 'Monthly depreciation — warehouse equipment',
    'lines' => [
        ['account_id' => $depreciationExpenseId, 'type' => 'debit',  'amount' => 25000],
        ['account_id' => $accumDepreciationId,   'type' => 'credit', 'amount' => 25000],
    ],
]);
$depEntry->submit();
$depEntry->post();

// Inventory financing interest accrual — all active facilities
// BRAC Bank: outstanding ৳38,00,000 × 2% = ৳76,000
// Mr. Karim:  outstanding ৳12,00,000 × 2% = ৳24,000
$accruals = Accounting::accrueAllFinancingInterest(date: '2026-04-30');

foreach ($accruals as $facilityId => $je) {
    if ($je) {
        $je->submit();
        $je->post(); // Finance Manager approves each
    }
}
// Total interest expense booked: ৳1,00,000
// DR Interest Expense — Inv. Financing 6710  ৳1,00,000
// CR Accrued Interest — BRAC Bank 2171        ৳76,000
// CR Accrued Interest — Mr. Abdul Karim 2172  ৳24,000
```

#### Day 30: Run Pre-Close Checks

```php
$period = FiscalPeriod::where('name', 'April 2026')->first();

$checks = Accounting::getPeriodCloseChecks($period);
// unposted_journals: 0  ✓
// open_invoices:     3  (3 customers haven't paid — OK, will carry forward)
// open_bills:        1  (1 vendor bill payment due May 15 — OK)
// has_blockers:      false  ✓  Ready to close
```

#### Day 30: Review Income Statement Before Closing

```php
$pl = Accounting::getIncomeStatement('2026-04-01', '2026-04-30');

// Revenue
//   Sales Revenue (4000):    ৳ 51,00,000
//   Total Revenue:           ৳ 51,00,000

// Expenses
//   COGS (5000):             ৳ 29,40,000
//   Office Rent (5100):      ৳    75,000
//   Salaries (5200):         ৳  3,00,000
//   Marketing (5600):        ৳    50,000
//   Utilities (5700):        ৳    18,000
//   Depreciation (5800):     ৳    25,000
//   Total Expenses:          ৳ 34,08,000

// Net Profit for April 2026: ৳ 16,92,000  ✓
```

#### Day 30: Physical Inventory Count

Warehouse team counts all items and updates system stock levels. A 3-unit shrinkage of Samsung TVs (WAC ৳ 12,500 each) is found:

```php
$shrinkageEntry = Accounting::createJournalEntry([
    'date'        => '2026-04-30',
    'reference'   => 'SHRINK-APR26-TV',
    'type'        => 'adjustment',
    'description' => 'Inventory shrinkage — 3× Samsung TV 55" (physical count variance)',
    'lines' => [
        ['account_id' => $inventoryShrinkageId, 'type' => 'debit',  'amount' => 37500],
        ['account_id' => $inventoryAssetId,     'type' => 'credit', 'amount' => 37500],
    ],
]);
$shrinkageEntry->submit();
$shrinkageEntry->post();
```

#### Day 30: Close the Period + Inventory Snapshot

```php
$result = Accounting::closeFiscalPeriod($period, snapshotInventory: true);

// Inventory reconciliation output:
// Snapshot lines:    427 (product × warehouse combinations)
// Physical value:    ৳ 4,21,85,000.00
// GL balance (1300): ৳ 4,21,85,000.00
// Variance:          ৳          0.00  ✓ Reconciled

// Period is now LOCKED — no more entries can be posted with April dates
```

#### Final Balance Sheet — April 30, 2026

```php
$bs = Accounting::getBalanceSheet('2026-04-30');

// ASSETS
//   Cash (1000):               ৳  45,00,000
//   Bank (1100):               ৳  82,50,000
//   Accounts Receivable (1200):৳  24,60,000   (3 open invoices)
//   Inventory (1300):          ৳ 4,21,85,000  (verified by snapshot)
//   Total Assets:              ৳ 5,73,95,000

// LIABILITIES
//   Accounts Payable (2000):          ৳  38,50,000   (1 open bill)
//   Inv. Financing Payable — BRAC (2151): ৳  38,00,000
//   Inv. Financing Payable — Karim (2152):৳  12,00,000
//   Accrued Interest — BRAC (2171):   ৳      76,000   (booked Apr 30, paid May 5)
//   Accrued Interest — Karim (2172):  ৳      24,000
//   VAT Payable (2300):               ৳   6,00,000
//   Accrued Liabilities:              ৳      18,000
//   Total Liabilities:                ৳  95,68,000

// EQUITY
//   Share Capital (3000):      ৳ 4,96,85,000
//   Retained Earnings (3100):  ৳  15,00,000   (prior periods)
//   Current Period Income:     ৳  15,92,000   (April profit after ৳1,00,000 financing interest)
//   Total Equity:              ৳ 5,27,77,000

// BALANCE CHECK: ৳ 5,73,95,000  ✓  (assets unchanged; liabilities + equity = assets)
```

May 1 — a new period opens automatically. The April numbers are frozen.

---

## Authorization Gates

The package registers fine-grained gates. Override any gate in your `AppServiceProvider`:

```php
// Grant full access via the super-gate
Gate::define('accounting-admin', fn ($user) => $user->hasRole('accountant'));

// Or override individual abilities
Gate::define('accounting.journal.submit', fn ($user) => $user->hasRole(['accountant', 'junior_accountant']));
Gate::define('accounting.journal.post',   fn ($user) => $user->hasRole(['finance_manager', 'cfo']));
Gate::define('accounting.fiscal-year.close', fn ($user) => $user->hasRole('cfo'));
```

Available gates:

| Gate | Description |
| --- | --- |
| `accounting.journal.view` | See journal entries |
| `accounting.journal.create` | Create/edit draft entries |
| `accounting.journal.submit` | Submit entry for approval |
| `accounting.journal.post` | Approve and post to GL |
| `accounting.journal.void` | Void a posted entry |
| `accounting.invoice.view` | View invoices |
| `accounting.invoice.create` | Create/edit invoices |
| `accounting.invoice.post` | Post invoice to GL |
| `accounting.invoice.payment` | Record payments |
| `accounting.bill.view` | View bills |
| `accounting.bill.create` | Create/edit bills |
| `accounting.bill.post` | Post bill to GL |
| `accounting.bill.payment` | Record payments |
| `accounting.reports.view` | View all financial reports |
| `accounting.accounts.view` | View chart of accounts |
| `accounting.accounts.manage` | Create/edit accounts |
| `accounting.customers.view` | View customers |
| `accounting.customers.manage` | Create/edit customers |
| `accounting.vendors.view` | View vendors |
| `accounting.vendors.manage` | Create/edit vendors |
| `accounting.budget.view` | View budgets |
| `accounting.budget.manage` | Create/edit budgets |
| `accounting.budget.approve` | Approve budgets |
| `accounting.fiscal-year.close` | Close fiscal year |
| `accounting.loans.view` | View loan facilities |
| `accounting.loans.manage` | Register facilities; record drawdowns, interest, repayments |
| `accounting.equity.view` | View owner's equity balances & activity |
| `accounting.equity.manage` | Record capital contributions & owner drawings |
| `accounting.qbo.connect` | Initiate QBO OAuth2 connect / disconnect |
| `accounting.qbo.sync` | Trigger push sync to QBO or pull QBO reports |
| `accounting.tax-rates.view` | View tax rates |
| `accounting.tax-rates.manage` | Create/edit/deactivate tax rates |
| `accounting.bank-reconciliation.view` | View bank reconciliations |
| `accounting.bank-reconciliation.create` | Start a new reconciliation |
| `accounting.bank-reconciliation.reconcile` | Complete a reconciliation |

---

## Web UI Routes

All routes are protected by `web_middleware` (default `['web', 'auth']`) under `web_prefix` (default `accounting`):

| Route name | URL | Description |
| --- | --- | --- |
| `accounting.dashboard` | `/accounting/dashboard` | Overview dashboard with pending approvals widget |
| `accounting.accounts` | `/accounting/accounts` | Chart of accounts |
| `accounting.journal` | `/accounting/journal-entries` | Journal entries with two-step workflow |
| `accounting.ledger` | `/accounting/ledger` | General ledger |
| `accounting.ledger.customers` | `/accounting/ledger/customers` | Customer ledger index |
| `accounting.ledger.vendors` | `/accounting/ledger/vendors` | Vendor ledger index |
| `accounting.customers.ledger` | `/accounting/customers/{customer}/ledger` | Per-customer statement |
| `accounting.vendors.ledger` | `/accounting/vendors/{vendor}/ledger` | Per-vendor statement |
| `accounting.invoices` | `/accounting/invoices` | Invoice management |
| `accounting.invoices.show` | `/accounting/invoices/{invoice}` | Invoice detail |
| `accounting.bills` | `/accounting/bills` | Bill management |
| `accounting.bills.show` | `/accounting/bills/{bill}` | Bill detail |
| `accounting.expenses` | `/accounting/expenses` | Expense management |
| `accounting.expenses.show` | `/accounting/expenses/{expense}` | Expense detail |
| `accounting.customers` | `/accounting/customers` | Customer list |
| `accounting.vendors` | `/accounting/vendors` | Vendor list |
| `accounting.requisitions` | `/accounting/requisitions` | Purchase & expense requisitions |
| `accounting.reports` | `/accounting/reports` | Financial reports (trial balance, P&L, balance sheet, cash flow) |
| `accounting.budgets` | `/accounting/budgets` | Budget management |
| `accounting.loans` | `/accounting/loans` | Loan facilities — register lenders, drawdown, accrue/pay interest, repay |
| `accounting.equity` | `/accounting/equity` | Owner's equity — capital contributions & drawings |
| `accounting.period-close` | `/accounting/period-close` | Month-end period close wizard |
| `accounting.tax-rates` | `/accounting/tax-rates` | Tax rate management |
| `accounting.bank-reconciliations` | `/accounting/bank-reconciliations` | Bank reconciliation list |
| `accounting.bank-reconciliations.show` | `/accounting/bank-reconciliations/{bankReconciliation}` | Reconciliation workspace — import, match, adjust, complete |

---

## REST API

Base prefix: `api/accounting`. Default middleware: `['api', 'auth:sanctum']`.

### Journal Entries

| Method | Endpoint | Action |
| --- | --- | --- |
| `GET` | `/api/accounting/journal-entries` | List entries (filterable by status, date, search) |
| `POST` | `/api/accounting/journal-entries` | Create entry |
| `GET` | `/api/accounting/journal-entries/{id}` | Get entry |
| `POST` | `/api/accounting/journal-entries/{id}/post` | Post entry to GL |
| `POST` | `/api/accounting/journal-entries/{id}/void` | Void entry |

### Accounts

| Method | Endpoint | Action |
| --- | --- | --- |
| `GET` | `/api/accounting/accounts` | List accounts |
| `POST` | `/api/accounting/accounts` | Create account |
| `GET` | `/api/accounting/accounts/{id}` | Get account |
| `PUT` | `/api/accounting/accounts/{id}` | Update account |
| `GET` | `/api/accounting/accounts/{id}/balance` | Current account balance |

### Invoices

| Method | Endpoint | Action |
| --- | --- | --- |
| `GET` | `/api/accounting/invoices` | List invoices |
| `POST` | `/api/accounting/invoices` | Create invoice |
| `GET` | `/api/accounting/invoices/{id}` | Get invoice |
| `PUT` | `/api/accounting/invoices/{id}` | Update invoice |
| `DELETE` | `/api/accounting/invoices/{id}` | Delete invoice |
| `POST` | `/api/accounting/invoices/{id}/post` | Post invoice to GL |
| `POST` | `/api/accounting/invoices/{id}/payments` | Record payment |
| `POST` | `/api/accounting/invoices/{id}/expenses` | Record charge/expense against invoice |

### Bills

| Method | Endpoint | Action |
| --- | --- | --- |
| `GET` | `/api/accounting/bills` | List bills |
| `POST` | `/api/accounting/bills` | Create bill |
| `GET` | `/api/accounting/bills/{id}` | Get bill |
| `DELETE` | `/api/accounting/bills/{id}` | Delete bill |
| `POST` | `/api/accounting/bills/{id}/post` | Post bill to GL |
| `POST` | `/api/accounting/bills/{id}/payments` | Record payment |
| `POST` | `/api/accounting/bills/{id}/expenses` | Record charge/expense against bill |

### Expenses

| Method | Endpoint | Action |
| --- | --- | --- |
| `GET` | `/api/accounting/expenses` | List expenses |
| `POST` | `/api/accounting/expenses` | Create expense |
| `GET` | `/api/accounting/expenses/{id}` | Get expense |
| `DELETE` | `/api/accounting/expenses/{id}` | Delete expense |
| `POST` | `/api/accounting/expenses/{id}/post` | Post expense to GL |
| `POST` | `/api/accounting/expenses/{id}/payments` | Record payment |

### Customers

| Method | Endpoint | Action |
| --- | --- | --- |
| `GET` | `/api/accounting/customers` | List customers |
| `POST` | `/api/accounting/customers` | Create customer |
| `GET` | `/api/accounting/customers/{id}` | Get customer |
| `PUT` | `/api/accounting/customers/{id}` | Update customer |
| `DELETE` | `/api/accounting/customers/{id}` | Delete customer |

### Vendors

| Method | Endpoint | Action |
| --- | --- | --- |
| `GET` | `/api/accounting/vendors` | List vendors |
| `POST` | `/api/accounting/vendors` | Create vendor |
| `GET` | `/api/accounting/vendors/{id}` | Get vendor |
| `PUT` | `/api/accounting/vendors/{id}` | Update vendor |
| `DELETE` | `/api/accounting/vendors/{id}` | Delete vendor |

### Budgets

| Method | Endpoint | Action |
| --- | --- | --- |
| `GET` | `/api/accounting/budgets` | List budgets |
| `POST` | `/api/accounting/budgets` | Create budget |
| `GET` | `/api/accounting/budgets/{id}` | Get budget |
| `PUT` | `/api/accounting/budgets/{id}` | Update budget |
| `DELETE` | `/api/accounting/budgets/{id}` | Delete budget |
| `POST` | `/api/accounting/budgets/{id}/approve` | Approve budget |
| `GET` | `/api/accounting/budgets/{id}/vs-actual` | Budget vs actual comparison |

### Tax Rates

| Method | Endpoint | Action |
| --- | --- | --- |
| `GET` | `/api/accounting/tax-rates` | List tax rates (`?search=&active=`) |
| `POST` | `/api/accounting/tax-rates` | Create tax rate |
| `GET` | `/api/accounting/tax-rates/{id}` | Get tax rate |
| `PUT` | `/api/accounting/tax-rates/{id}` | Update tax rate |
| `DELETE` | `/api/accounting/tax-rates/{id}` | Delete tax rate (422 if referenced by an invoice/bill line — deactivate instead) |

### Bank Reconciliation

| Method | Endpoint | Action |
| --- | --- | --- |
| `GET` | `/api/accounting/bank-reconciliations` | List reconciliations (`?account_id=`) |
| `POST` | `/api/accounting/bank-reconciliations` | Start a reconciliation |
| `GET` | `/api/accounting/bank-reconciliations/{id}` | Get reconciliation with statement lines |
| `POST` | `/api/accounting/bank-reconciliations/{id}/statement-lines` | Import statement lines (`rows: [...]`) |
| `POST` | `/api/accounting/bank-reconciliations/{id}/match` | Match a statement line to a GL line |
| `POST` | `/api/accounting/bank-reconciliations/{id}/unmatch` | Unmatch a statement line |
| `POST` | `/api/accounting/bank-reconciliations/{id}/complete` | Complete the reconciliation (balance check) |

### Reports

| Method | Endpoint | Action |
| --- | --- | --- |
| `GET` | `/api/accounting/reports/trial-balance` | Trial balance (`?start=&end=&sbu=`) |
| `GET` | `/api/accounting/reports/balance-sheet` | Balance sheet (`?date=&sbu=`) |
| `GET` | `/api/accounting/reports/income-statement` | P&L (`?start=&end=&sbu=`) |
| `GET` | `/api/accounting/reports/cash-flow` | Cash flow (`?start=&end=&sbu=`) |
| `GET` | `/api/accounting/reports/general-ledger` | General ledger (`?account_id=&start=&end=&sbu=`) |
| `GET` | `/api/accounting/reports/ar-aging` | A/R aging (`?as_of_date=&sbu_code=`) |
| `GET` | `/api/accounting/reports/ap-aging` | A/P aging (`?as_of_date=&sbu_code=`) |
| `GET` | `/api/accounting/reports/sales-tax-liability` | Sales tax liability (`?start_date=&end_date=&sbu_code=`) |

---

## Artisan Commands

### Demo data

```bash
# Seed a full multi-entity demo dataset (invoices, bills, expenses, journal entries, budgets)
php artisan accounting:demo
```

### Report generation

```bash
# Print a report to the terminal
php artisan accounting:report income-statement --start=2026-01-01 --end=2026-04-30 --format=table
php artisan accounting:report balance-sheet    --date=2026-04-30  --format=table
php artisan accounting:report trial-balance    --start=2026-01-01 --end=2026-04-30 --format=json

# Export to file
php artisan accounting:report all --start=2026-01-01 --end=2026-12-31 --format=csv --output=reports/fy2026.csv

# Sales tax liability (requires --start/--end, same as income-statement/cash-flow)
php artisan accounting:report sales-tax-liability --start=2026-04-01 --end=2026-04-30
```

Available types: `all` (default) | `trial-balance` | `balance-sheet` | `income-statement` | `cash-flow` | `sales-tax-liability`

Available formats: `table` | `csv` | `json`

### QBO sync

```bash
# Push all entities to QuickBooks Online
php artisan accounting:qbo-sync

# Push specific entities only
php artisan accounting:qbo-sync --entity=accounts --entity=customers --entity=invoices

# Push with a date filter (only records modified since this date)
php artisan accounting:qbo-sync --entity=invoices --since=2026-05-01

# Target a specific QBO company (overrides QBO_REALM_ID)
php artisan accounting:qbo-sync --realm=123456789

# Pull a named report from QBO and dump JSON
php artisan accounting:qbo-sync --pull=profit-and-loss --start=2026-01-01 --end=2026-04-30
php artisan accounting:qbo-sync --pull=balance-sheet   --start=2026-04-30
php artisan accounting:qbo-sync --pull=aged-receivables
```

Available `--pull` slugs: `profit-and-loss`, `balance-sheet`, `cash-flow`, `trial-balance`, `aged-receivables`, `aged-payables`, `general-ledger`, `transaction-list`

---

## QuickBooks Online Integration

Two-way sync with QuickBooks Online via the v3 REST API and OAuth 2.0.

**Push** your local data to QBO — Chart of Accounts, Customers, Vendors, Invoices, Bills, Journal Entries.

**Pull** QBO-native reports back into your app.

**Format** your local reports (P&L, Balance Sheet, Cash Flow, Trial Balance, A/R Aging, A/P Aging) in QBO-compatible structure using `QuickBooksReportFormatter`.

```php
use Centrex\Accounting\QuickBooks\{QuickBooksSyncService, QuickBooksReportFormatter};

// Push all accounts to QBO
$result = app(QuickBooksSyncService::class)->syncAccounts(config('accounting.quickbooks.default_realm_id'));
// ['created' => 5, 'updated' => 12, 'skipped' => 3, 'errors' => []]

// Get local P&L in QBO section structure
use Centrex\Accounting\Facades\Accounting;
$pl     = Accounting::getIncomeStatement('2026-01-01', '2026-04-30');
$qboFmt = app(QuickBooksReportFormatter::class)->profitAndLoss($pl);
// ['income' => [...], 'cost_of_goods_sold' => [...], 'gross_profit' => x, 'expenses' => [...], 'net_income' => x]
```

See [docs/quickbooks.md](docs/quickbooks.md) for the full setup guide, OAuth flow, account type mapping reference, and webhook documentation.

---

## Testing

```bash
composer test          # full suite: rector dry-run, pint check, phpstan, pest
composer test:unit     # pest only
composer test:types    # phpstan static analysis
composer test:lint     # pint style check
composer lint          # apply pint formatting
composer refacto       # apply rector refactors

# Single test
vendor/bin/pest tests/Feature/JournalEntryTest.php
vendor/bin/pest --filter "journal entry must balance"
```

---

## Changelog

Please see [CHANGELOG](CHANGELOG.md) for more information on what has changed recently.

## Credits

- [centrex](https://github.com/centrex)
- [All Contributors](../../contributors)

## License

The MIT License (MIT). Please see [License File](LICENSE) for more information.
