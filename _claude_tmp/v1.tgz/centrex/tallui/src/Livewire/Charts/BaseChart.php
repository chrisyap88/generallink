<?php

declare(strict_types = 1);

namespace Centrex\TallUi\Livewire\Charts;

use Centrex\TallUi\Concerns\CachesData;
use Centrex\TallUi\Contracts\ChartDataProvider;
use Illuminate\Contracts\View\View;
use Livewire\Attributes\Computed;
use Livewire\Component;

abstract class BaseChart extends Component
{
    use CachesData;

    public string $title = '';

    public string $subtitle = '';

    public int $height = 0;

    public int $poll = 0;

    public string $theme = '';

    /** FQCN implementing ChartDataProvider */
    public ?string $dataProvider = null;

    /** Inline series — takes priority over dataProvider when non-empty. */
    public array $series = [];

    /** Inline categories — used alongside $series for inline data. */
    public array $categories = [];

    abstract protected function chartType(): string;

    /** @return array<string, mixed> */
    abstract protected function defaultOptions(): array;

    /**
     * Override in a subclass to provide inline data.
     *
     * @return array{series: array<int, array<string, mixed>>, categories: array<int, mixed>}
     */
    protected function data(): array
    {
        return ['series' => [], 'categories' => []];
    }

    /**
     * Resolve data from inline props, dataProvider, or the overridable data() method.
     * Priority: inline $series/$categories > dataProvider > data()
     *
     * @return array{series: array<int, array<string, mixed>>, categories: array<int, mixed>}
     */
    protected function resolveData(): array
    {
        if ($this->series !== []) {
            return ['series' => $this->series, 'categories' => $this->categories];
        }

        if ($this->dataProvider !== null && class_exists($this->dataProvider)) {
            /** @var ChartDataProvider $provider */
            $provider = app($this->dataProvider);

            return $provider->getData();
        }

        return $this->data();
    }

    /**
     * Chart data — cached when $cacheTtl > 0, memoized within the request by #[Computed].
     *
     * @return array{series: array<int, array<string, mixed>>, categories: array<int, mixed>}
     */
    #[Computed]
    public function chartData(): array
    {
        return $this->rememberCacheTracked(
            $this->chartCacheKey(),
            fn (): array => $this->resolveData(),
        );
    }

    /**
     * Cache key for this chart's data.
     * Chart data is not per-user/per-request-state so the key only encodes
     * the component class and data provider.
     */
    protected function chartCacheKey(): string
    {
        return $this->cacheKey(
            'chart',
            md5(static::class . ($this->dataProvider ?? '')),
        );
    }

    public function mount(): void
    {
        if ($this->height === 0) {
            $this->height = (int) config('tallui.charts.default_height', 350);
        }

        if ($this->poll === 0) {
            $this->poll = (int) config('tallui.charts.default_poll', 0);
        }

        if ($this->theme === '') {
            $this->theme = (string) config('tallui.charts.theme', 'light');
        }

        if ($this->cacheTtl === 0) {
            $this->cacheTtl = (int) config('tallui.charts.cache_ttl', 0);
        }

        // 'chart-updated' is a browser (window) event, not a scoped Livewire listener —
        // every chart instance on the page hears every other chart's dispatch. Tagging
        // it with this component's own id lets _chart.blade.php's listener ignore
        // updates meant for a different chart instance instead of misapplying them.
        $this->dispatch('chart-updated', id: $this->getId(), options: $this->buildOptions());
    }

    /** @return array<string, mixed> */
    public function buildOptions(): array
    {
        $data = $this->chartData;

        return array_merge_recursive($this->defaultOptions(), [
            'chart' => [
                'type'       => $this->chartType(),
                'height'     => $this->height,
                'theme'      => ['mode' => $this->theme],
                'toolbar'    => ['show' => true],
                'animations' => ['enabled' => true],
            ],
            'xaxis' => [
                'categories' => $data['categories'] ?? [],
            ],
            'series' => $data['series'] ?? [],
            'title'  => [
                'text'  => $this->title ?? '',
                'align' => 'left',
                'style' => [
                    'fontSize' => '14px',
                ],
            ],

            'subtitle' => [
                'text'  => $this->subtitle ?? '',
                'align' => 'left',
                'style' => [],
            ],
        ]);
    }

    public function updated(string $property): void
    {
        // 'chart-updated' is a browser (window) event, not a scoped Livewire listener —
        // every chart instance on the page hears every other chart's dispatch. Tagging
        // it with this component's own id lets _chart.blade.php's listener ignore
        // updates meant for a different chart instance instead of misapplying them.
        $this->dispatch('chart-updated', id: $this->getId(), options: $this->buildOptions());
    }

    public function render(): View
    {
        return view('tallui::livewire.charts.' . $this->chartType());
    }
}
