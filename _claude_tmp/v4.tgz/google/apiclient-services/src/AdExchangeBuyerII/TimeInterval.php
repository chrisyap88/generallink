<?php
/*
 * Copyright 2014 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */

namespace Google\Service\AdExchangeBuyerII;

class TimeInterval extends \Google\Model
{
  /**
   * The timestamp marking the end of the range (exclusive) for which data is
   * included.
   *
   * @var string
   */
  public $endTime;
  /**
   * The timestamp marking the start of the range (inclusive) for which data is
   * included.
   *
   * @var string
   */
  public $startTime;

  /**
   * The timestamp marking the end of the range (exclusive) for which data is
   * included.
   *
   * @param string $endTime
   */
  public function setEndTime($endTime)
  {
    $this->endTime = $endTime;
  }
  /**
   * @return string
   */
  public function getEndTime()
  {
    return $this->endTime;
  }
  /**
   * The timestamp marking the start of the range (inclusive) for which data is
   * included.
   *
   * @param string $startTime
   */
  public function setStartTime($startTime)
  {
    $this->startTime = $startTime;
  }
  /**
   * @return string
   */
  public function getStartTime()
  {
    return $this->startTime;
  }
}

// Adding a class alias for backwards compatibility with the previous class name.
class_alias(TimeInterval::class, 'Google_Service_AdExchangeBuyerII_TimeInterval');
