<?php
/*
 * Copyright 2014 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */

namespace Google\Service\AdMob;

class AppManualAppInfo extends \Google\Model
{
  /**
   * The display name of the app as shown in the AdMob UI, which is provided by
   * the user. The maximum length allowed is 80 characters.
   *
   * @var string
   */
  public $displayName;

  /**
   * The display name of the app as shown in the AdMob UI, which is provided by
   * the user. The maximum length allowed is 80 characters.
   *
   * @param string $displayName
   */
  public function setDisplayName($displayName)
  {
    $this->displayName = $displayName;
  }
  /**
   * @return string
   */
  public function getDisplayName()
  {
    return $this->displayName;
  }
}

// Adding a class alias for backwards compatibility with the previous class name.
class_alias(AppManualAppInfo::class, 'Google_Service_AdMob_AppManualAppInfo');
