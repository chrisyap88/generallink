<?php
/*
 * Copyright 2014 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */

namespace Google\Service\AccessContextManager;

class MethodSelector extends \Google\Model
{
  /**
   * A valid method name for the corresponding `service_name` in ApiOperation.
   * If `*` is used as the value for the `method`, then ALL methods and
   * permissions are allowed.
   *
   * @var string
   */
  public $method;
  /**
   * A valid Cloud IAM permission for the corresponding `service_name` in
   * ApiOperation.
   *
   * @var string
   */
  public $permission;

  /**
   * A valid method name for the corresponding `service_name` in ApiOperation.
   * If `*` is used as the value for the `method`, then ALL methods and
   * permissions are allowed.
   *
   * @param string $method
   */
  public function setMethod($method)
  {
    $this->method = $method;
  }
  /**
   * @return string
   */
  public function getMethod()
  {
    return $this->method;
  }
  /**
   * A valid Cloud IAM permission for the corresponding `service_name` in
   * ApiOperation.
   *
   * @param string $permission
   */
  public function setPermission($permission)
  {
    $this->permission = $permission;
  }
  /**
   * @return string
   */
  public function getPermission()
  {
    return $this->permission;
  }
}

// Adding a class alias for backwards compatibility with the previous class name.
class_alias(MethodSelector::class, 'Google_Service_AccessContextManager_MethodSelector');
